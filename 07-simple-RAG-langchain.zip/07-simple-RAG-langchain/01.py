"""
LangChain을 이용한 초간단 RAG 시스템
RAG-KB 폴더의 문서를 기반으로 질문에 답변하는 시스템
GPU 서버의 Qwen3 모델 사용 (FastAPI Wrapper)
"""

import os
import requests
import numpy as np
from typing import List, Optional, Any
from langchain_community.document_loaders import DirectoryLoader, TextLoader
from langchain_community.vectorstores import FAISS
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings.base import Embeddings
from langchain.chains import RetrievalQA
from langchain.llms.base import LLM
from langchain.callbacks.manager import CallbackManagerForLLMRun

# 설정 파일 임포트 (config.py가 있으면 사용, 없으면 기본값)
try:
    from config import (
        API_URL, API_KEY, HEADERS,
        EMBEDDING_MODEL, LLM_MODEL,
        CHUNK_SIZE, CHUNK_OVERLAP, TOP_K, TEMPERATURE,
        KB_PATH
    )
except ImportError:
    # 기본 설정
    API_URL = "http://server-ip:8000"
    API_KEY = "LDfvFBuAzG6P8DM7NFD4u2FGN7BeFSe8d47JqDGwu1I"
    HEADERS = {
        "X-API-Key": API_KEY,
        "Content-Type": "application/json"
    }
    EMBEDDING_MODEL = "qwen3-embedding:8b"
    LLM_MODEL = "qwen3:8b"
    CHUNK_SIZE = 500
    CHUNK_OVERLAP = 50
    TOP_K = 3
    TEMPERATURE = 0.7
    KB_PATH = "./RAG-KB"


class Qwen3Embeddings(Embeddings):
    """Qwen3 임베딩 모델 (GPU 서버 API 사용)"""
    
    def __init__(self, api_url: str, api_key: str, model: str = "qwen3-embedding:8b"):
        self.api_url = api_url
        self.api_key = api_key
        self.model = model
    
    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """여러 문서 임베딩"""
        embeddings = []
        for text in texts:
            embedding = self._embed_single(text)
            embeddings.append(embedding)
        return embeddings
    
    def embed_query(self, text: str) -> List[float]:
        """단일 쿼리 임베딩"""
        return self._embed_single(text)
    
    def _embed_single(self, text: str) -> List[float]:
        """단일 텍스트 임베딩"""
        payload = {
            "input": text,
            "model": self.model
        }
        
        headers = {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json"
        }
        
        response = requests.post(
            f"{self.api_url}/api/embed",
            headers=headers,
            json=payload,
            timeout=30
        )
        
        if response.status_code != 200:
            raise Exception(f"임베딩 API 오류: {response.status_code} - {response.text}")
        
        return response.json()["embeddings"][0]


class Qwen3LLM(LLM):
    """Qwen3 LLM (GPU 서버 API 사용)"""
    
    api_url: str
    api_key: str
    model: str = "qwen3:8b"
    temperature: float = 0.7
    
    @property
    def _llm_type(self) -> str:
        return "qwen3"
    
    def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> str:
        """LLM 호출"""
        payload = {
            "prompt": prompt,
            "model": self.model,
            "stream": False,
            "temperature": self.temperature
        }
        
        headers = {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json"
        }
        
        response = requests.post(
            f"{self.api_url}/api/generate",
            headers=headers,
            json=payload,
            timeout=60
        )
        
        if response.status_code != 200:
            raise Exception(f"생성 API 오류: {response.status_code} - {response.text}")
        
        return response.json()["response"]


def check_server_health():
    """서버 헬스 체크"""
    try:
        response = requests.get(f"{API_URL}/health", timeout=5)
        if response.status_code == 200:
            print(f"✅ GPU 서버 연결 성공: {response.json()['status']}")
            return True
        else:
            print(f"❌ 서버 응답 오류: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ 서버 연결 실패: {e}")
        return False


def load_documents(directory_path):
    """문서 로드"""
    print(f"📁 문서 로딩 중: {directory_path}")
    
    # 텍스트 파일 로더
    txt_loader = DirectoryLoader(
        directory_path,
        glob="**/*.txt",
        loader_cls=TextLoader,
        loader_kwargs={'encoding': 'utf-8'}
    )
    
    # 마크다운 파일 로더
    md_loader = DirectoryLoader(
        directory_path,
        glob="**/*.md",
        loader_cls=TextLoader,
        loader_kwargs={'encoding': 'utf-8'}
    )
    
    txt_docs = txt_loader.load()
    md_docs = md_loader.load()
    
    all_docs = txt_docs + md_docs
    print(f"✅ {len(all_docs)}개 문서 로드 완료")
    
    return all_docs


def split_documents(documents):
    """문서 청킹"""
    print(f"✂️  문서 분할 중 (청크 크기: {CHUNK_SIZE}, 오버랩: {CHUNK_OVERLAP})...")
    
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        separators=["\n\n", "\n", ". ", " ", ""]
    )
    
    splits = text_splitter.split_documents(documents)
    print(f"✅ {len(splits)}개 청크 생성 완료")
    
    return splits


def create_vectorstore(documents):
    """벡터 스토어 생성 (GPU 서버 Qwen3 임베딩 사용)"""
    print(f"🔢 임베딩 및 벡터스토어 생성 중 ({EMBEDDING_MODEL}, 4096차원)...")
    
    # Qwen3 임베딩 모델 (GPU 서버)
    embeddings = Qwen3Embeddings(
        api_url=API_URL,
        api_key=API_KEY,
        model=EMBEDDING_MODEL
    )
    
    print(f"📊 {len(documents)}개 문서 임베딩 중...")
    vectorstore = FAISS.from_documents(documents, embeddings)
    print("✅ 벡터스토어 생성 완료")
    
    return vectorstore


def create_qa_chain(vectorstore):
    """QA 체인 생성 (GPU 서버 Qwen3 LLM 사용)"""
    print(f"🔗 QA 체인 생성 중 ({LLM_MODEL}, Temperature: {TEMPERATURE})...")
    
    # Qwen3 LLM (GPU 서버)
    llm = Qwen3LLM(
        api_url=API_URL,
        api_key=API_KEY,
        model=LLM_MODEL,
        temperature=TEMPERATURE
    )
    
    # RetrievalQA 체인
    qa_chain = RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff",
        retriever=vectorstore.as_retriever(search_kwargs={"k": TOP_K}),
        return_source_documents=True
    )
    
    print(f"✅ QA 체인 생성 완료 (Top-{TOP_K} 검색)")
    return qa_chain


def main():
    """메인 실행"""
    print("=" * 60)
    print("🚀 LangChain RAG 시스템 시작 (GPU 서버)")
    print("=" * 60)
    
    # 0. 서버 헬스 체크
    print("\n🔍 GPU 서버 상태 확인 중...")
    if not check_server_health():
        print("\n⚠️  서버에 연결할 수 없습니다. 다음을 확인하세요:")
        print(f"   - GPU 서버가 실행 중인지 확인: {API_URL}")
        print("   - FastAPI 서버가 8000 포트에서 실행 중인지 확인")
        print("   - API Key가 올바른지 확인")
        return
    
    # 1. 문서 로드
    documents = load_documents(KB_PATH)
    
    if not documents:
        print("❌ 로드할 문서가 없습니다.")
        return
    
    # 2. 문서 분할
    splits = split_documents(documents)
    
    # 3. 벡터스토어 생성
    vectorstore = create_vectorstore(splits)
    
    # 4. QA 체인 생성
    qa_chain = create_qa_chain(vectorstore)
    
    print("\n" + "=" * 60)
    print("💬 질문을 입력하세요 (종료: 'quit', 'exit', 'q')")
    print("=" * 60 + "\n")
    
    # 5. 대화 루프
    while True:
        question = input("👤 질문: ").strip()
        
        if question.lower() in ['quit', 'exit', 'q', '종료']:
            print("👋 프로그램을 종료합니다.")
            break
        
        if not question:
            continue
        
        print("\n🤖 답변 생성 중...\n")
        
        try:
            # 질문 처리
            result = qa_chain.invoke({"query": question})
            
            # 답변 출력
            print(f"💡 답변: {result['result']}\n")
            
            # 참조 문서 출력
            if result.get('source_documents'):
                print("📚 참조 문서:")
                for i, doc in enumerate(result['source_documents'], 1):
                    source = doc.metadata.get('source', 'Unknown')
                    content_preview = doc.page_content[:100].replace('\n', ' ')
                    print(f"  {i}. {source}")
                    print(f"     {content_preview}...")
            
            print("\n" + "-" * 60 + "\n")
            
        except Exception as e:
            print(f"❌ 오류 발생: {e}\n")


if __name__ == "__main__":
    main()
