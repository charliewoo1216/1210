"""
LangGraph RAG 시스템 + 시각화
State Machine을 Mermaid 다이어그램으로 시각화하고
웹 인터페이스로 그래프 구조를 확인 및 수정 가능
GPU 서버의 Qwen3 모델 사용 (FastAPI Wrapper)
"""

import os
import requests
import json
from datetime import datetime
from typing import List, Optional, Any, TypedDict, Annotated
from langchain_community.document_loaders import DirectoryLoader, TextLoader
from langchain_community.vectorstores import FAISS
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings.base import Embeddings
from langchain.llms.base import LLM
from langchain.callbacks.manager import CallbackManagerForLLMRun
from langchain_core.documents import Document

# LangGraph 관련
from langgraph.graph import StateGraph, END
import operator

# 설정 파일 임포트 (config.py가 있으면 사용, 없으면 기본값)
try:
    from config import (
        API_URL, API_KEY, HEADERS,
        EMBEDDING_MODEL, LLM_MODEL,
        CHUNK_SIZE, CHUNK_OVERLAP, TOP_K, TEMPERATURE,
        KB_PATH
    )
except ImportError:
    # 기본 설정
    API_URL = "http://server-ip:8000"
    API_KEY = "LDfvFBuAzG6P8DM7NFD4u2FGN7BeFSe8d47JqDGwu1I"
    HEADERS = {
        "X-API-Key": API_KEY,
        "Content-Type": "application/json"
    }
    EMBEDDING_MODEL = "qwen3-embedding:8b"
    LLM_MODEL = "qwen3:8b"
    CHUNK_SIZE = 500
    CHUNK_OVERLAP = 50
    TOP_K = 3
    TEMPERATURE = 0.7
    KB_PATH = "./RAG-KB"


# ================================
# State 정의
# ================================

class GraphState(TypedDict):
    """RAG 워크플로우의 상태"""
    question: str                          # 사용자 질문
    retrieved_documents: List[Document]    # 검색된 문서
    context: str                           # 최종 컨텍스트
    answer: str                            # 생성된 답변
    steps: Annotated[List[str], operator.add]  # 실행 단계 추적
    execution_time: dict                   # 각 단계별 실행 시간


# ================================
# Qwen3 API 클래스
# ================================

class Qwen3Embeddings(Embeddings):
    """Qwen3 임베딩 모델 (GPU 서버 API 사용)"""
    
    def __init__(self, api_url: str, api_key: str, model: str = "qwen3-embedding:8b"):
        self.api_url = api_url
        self.api_key = api_key
        self.model = model
    
    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """여러 문서 임베딩"""
        embeddings = []
        for text in texts:
            embedding = self._embed_single(text)
            embeddings.append(embedding)
        return embeddings
    
    def embed_query(self, text: str) -> List[float]:
        """단일 쿼리 임베딩"""
        return self._embed_single(text)
    
    def _embed_single(self, text: str) -> List[float]:
        """단일 텍스트 임베딩"""
        payload = {
            "input": text,
            "model": self.model
        }
        
        headers = {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json"
        }
        
        response = requests.post(
            f"{self.api_url}/api/embed",
            headers=headers,
            json=payload,
            timeout=30
        )
        
        if response.status_code != 200:
            raise Exception(f"임베딩 API 오류: {response.status_code} - {response.text}")
        
        return response.json()["embeddings"][0]


class Qwen3LLM(LLM):
    """Qwen3 LLM (GPU 서버 API 사용)"""
    
    api_url: str
    api_key: str
    model: str = "qwen3:8b"
    temperature: float = 0.7
    
    @property
    def _llm_type(self) -> str:
        return "qwen3"
    
    def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> str:
        """LLM 호출"""
        payload = {
            "prompt": prompt,
            "model": self.model,
            "stream": False,
            "temperature": self.temperature
        }
        
        headers = {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json"
        }
        
        response = requests.post(
            f"{self.api_url}/api/generate",
            headers=headers,
            json=payload,
            timeout=60
        )
        
        if response.status_code != 200:
            raise Exception(f"생성 API 오류: {response.status_code} - {response.text}")
        
        return response.json()["response"]


def check_server_health():
    """서버 헬스 체크"""
    try:
        response = requests.get(f"{API_URL}/health", timeout=5)
        if response.status_code == 200:
            print(f"✅ GPU 서버 연결 성공: {response.json()['status']}")
            return True
        else:
            print(f"❌ 서버 응답 오류: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ 서버 연결 실패: {e}")
        return False


def load_documents(directory_path):
    """문서 로드"""
    print(f"📁 문서 로딩 중: {directory_path}")
    
    # 텍스트 파일 로더
    txt_loader = DirectoryLoader(
        directory_path,
        glob="**/*.txt",
        loader_cls=TextLoader,
        loader_kwargs={'encoding': 'utf-8'}
    )
    
    # 마크다운 파일 로더
    md_loader = DirectoryLoader(
        directory_path,
        glob="**/*.md",
        loader_cls=TextLoader,
        loader_kwargs={'encoding': 'utf-8'}
    )
    
    txt_docs = txt_loader.load()
    md_docs = md_loader.load()
    
    all_docs = txt_docs + md_docs
    print(f"✅ {len(all_docs)}개 문서 로드 완료")
    
    return all_docs


def split_documents(documents):
    """문서 청킹"""
    print(f"✂️  문서 분할 중 (청크 크기: {CHUNK_SIZE}, 오버랩: {CHUNK_OVERLAP})...")
    
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        separators=["\n\n", "\n", ". ", " ", ""]
    )
    
    splits = text_splitter.split_documents(documents)
    print(f"✅ {len(splits)}개 청크 생성 완료")
    
    return splits


def create_vectorstore(documents):
    """벡터 스토어 생성 (GPU 서버 Qwen3 임베딩 사용)"""
    print(f"🔢 임베딩 및 벡터스토어 생성 중 ({EMBEDDING_MODEL}, 4096차원)...")
    
    # Qwen3 임베딩 모델 (GPU 서버)
    embeddings = Qwen3Embeddings(
        api_url=API_URL,
        api_key=API_KEY,
        model=EMBEDDING_MODEL
    )
    
    print(f"📊 {len(documents)}개 문서 임베딩 중...")
    vectorstore = FAISS.from_documents(documents, embeddings)
    print("✅ 벡터스토어 생성 완료")
    
    return vectorstore


# ================================
# LangGraph 노드 함수들
# ================================

def retrieve_documents(state: GraphState) -> GraphState:
    """노드 1: 문서 검색"""
    import time
    start_time = time.time()
    
    print(f"\n🔍 [STEP 1] 문서 검색 중... (Top-{TOP_K})")
    
    question = state["question"]
    retriever = vectorstore.as_retriever(search_kwargs={"k": TOP_K})
    retrieved_docs = retriever.get_relevant_documents(question)
    
    execution_time = time.time() - start_time
    print(f"   ✅ {len(retrieved_docs)}개 문서 검색 완료 ({execution_time:.2f}초)")
    
    exec_times = state.get("execution_time", {})
    exec_times["retrieve"] = execution_time
    
    return {
        **state,
        "retrieved_documents": retrieved_docs,
        "steps": ["문서 검색 완료"],
        "execution_time": exec_times
    }


def evaluate_documents(state: GraphState) -> GraphState:
    """노드 2: 문서 평가"""
    import time
    start_time = time.time()
    
    print(f"\n📊 [STEP 2] 문서 평가 중...")
    
    retrieved_docs = state["retrieved_documents"]
    evaluated_docs = []
    
    for doc in retrieved_docs:
        if len(doc.page_content.strip()) > 20:
            evaluated_docs.append(doc)
    
    execution_time = time.time() - start_time
    print(f"   ✅ {len(evaluated_docs)}개 문서 평가 통과 ({execution_time:.2f}초)")
    
    exec_times = state.get("execution_time", {})
    exec_times["evaluate"] = execution_time
    
    return {
        **state,
        "retrieved_documents": evaluated_docs,
        "steps": ["문서 평가 완료"],
        "execution_time": exec_times
    }


def build_context(state: GraphState) -> GraphState:
    """노드 3: 컨텍스트 구성"""
    import time
    start_time = time.time()
    
    print(f"\n📝 [STEP 3] 컨텍스트 구성 중...")
    
    retrieved_docs = state["retrieved_documents"]
    context_parts = []
    
    for i, doc in enumerate(retrieved_docs, 1):
        source = doc.metadata.get('source', 'Unknown')
        content = doc.page_content.strip()
        context_parts.append(f"[문서 {i}] {source}\n{content}")
    
    context = "\n\n".join(context_parts)
    
    execution_time = time.time() - start_time
    print(f"   ✅ 컨텍스트 구성 완료 ({len(context)} 글자, {execution_time:.2f}초)")
    
    exec_times = state.get("execution_time", {})
    exec_times["build_context"] = execution_time
    
    return {
        **state,
        "context": context,
        "steps": ["컨텍스트 구성 완료"],
        "execution_time": exec_times
    }


def generate_answer(state: GraphState) -> GraphState:
    """노드 4: 답변 생성"""
    import time
    start_time = time.time()
    
    print(f"\n🤖 [STEP 4] 답변 생성 중...")
    
    question = state["question"]
    context = state["context"]
    
    prompt = f"""다음 문서들을 참고하여 질문에 답변해주세요.

참고 문서:
{context}

질문: {question}

답변:"""
    
    llm = Qwen3LLM(
        api_url=API_URL,
        api_key=API_KEY,
        model=LLM_MODEL,
        temperature=TEMPERATURE
    )
    
    answer = llm._call(prompt)
    
    execution_time = time.time() - start_time
    print(f"   ✅ 답변 생성 완료 ({len(answer)} 글자, {execution_time:.2f}초)")
    
    exec_times = state.get("execution_time", {})
    exec_times["generate"] = execution_time
    
    return {
        **state,
        "answer": answer,
        "steps": ["답변 생성 완료"],
        "execution_time": exec_times
    }


# ================================
# 시각화 함수
# ================================

def get_graph_structure() -> dict:
    """현재 그래프 구조를 딕셔너리로 반환"""
    return {
        "nodes": {
            "START": {
                "label": "시작",
                "description": "질문 입력",
                "type": "start"
            },
            "retrieve": {
                "label": "문서 검색",
                "description": f"Top-{TOP_K} 벡터 검색",
                "type": "process"
            },
            "evaluate": {
                "label": "문서 평가",
                "description": "품질 필터링",
                "type": "process"
            },
            "build_context": {
                "label": "컨텍스트 구성",
                "description": "문서 결합",
                "type": "process"
            },
            "generate": {
                "label": "답변 생성",
                "description": f"{LLM_MODEL}",
                "type": "process"
            },
            "END": {
                "label": "종료",
                "description": "답변 반환",
                "type": "end"
            }
        },
        "edges": [
            {"from": "START", "to": "retrieve", "label": ""},
            {"from": "retrieve", "to": "evaluate", "label": ""},
            {"from": "evaluate", "to": "build_context", "label": ""},
            {"from": "build_context", "to": "generate", "label": ""},
            {"from": "generate", "to": "END", "label": ""}
        ]
    }


def generate_mermaid_diagram(graph_structure: dict) -> str:
    """LangGraph를 Mermaid 다이어그램으로 변환"""
    mermaid = ["graph TD"]
    
    # 노드 정의
    for node_id, node_info in graph_structure["nodes"].items():
        label = node_info["label"]
        description = node_info.get("description", "")
        mermaid.append(f'    {node_id}["{label}<br/>{description}"]')
    
    # 엣지 정의
    for edge in graph_structure["edges"]:
        from_node = edge["from"]
        to_node = edge["to"]
        label = f" [{edge['label']}]" if edge.get('label') else ""
        if label:
            mermaid.append(f"    {from_node} -->|{label}| {to_node}")
        else:
            mermaid.append(f"    {from_node} --> {to_node}")
    
    # 스타일 정의
    mermaid.append("")
    mermaid.append("    classDef startNode fill:#90EE90,stroke:#006400,stroke-width:2px")
    mermaid.append("    classDef processNode fill:#87CEEB,stroke:#00008B,stroke-width:2px")
    mermaid.append("    classDef endNode fill:#FFB6C1,stroke:#8B0000,stroke-width:2px")
    
    return "\n".join(mermaid)


def save_graph_visualization(filename: str = "graph_visualization.html"):
    """그래프를 HTML 파일로 저장 (Mermaid.js 사용)"""
    graph_structure = get_graph_structure()
    mermaid_code = generate_mermaid_diagram(graph_structure)
    
    html_content = f"""<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LangGraph RAG 워크플로우 시각화</title>
    <script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }}
        .container {{
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            overflow: hidden;
        }}
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }}
        .header h1 {{
            margin: 0;
            font-size: 2.5em;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }}
        .header p {{
            margin: 10px 0 0 0;
            font-size: 1.1em;
            opacity: 0.9;
        }}
        .content {{
            padding: 40px;
        }}
        .diagram-container {{
            background: #f8f9fa;
            border-radius: 8px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }}
        .info-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }}
        .info-card {{
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            border-left: 4px solid #667eea;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        .info-card h3 {{
            margin: 0 0 10px 0;
            color: #667eea;
            font-size: 1.2em;
        }}
        .info-card p {{
            margin: 5px 0;
            color: #666;
            line-height: 1.6;
        }}
        .node-list {{
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
        }}
        .node-item {{
            background: white;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 5px;
            border-left: 4px solid #87CEEB;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }}
        .node-item h4 {{
            margin: 0 0 5px 0;
            color: #333;
        }}
        .node-item p {{
            margin: 0;
            color: #666;
            font-size: 0.9em;
        }}
        .controls {{
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
            text-align: center;
        }}
        .btn {{
            background: #667eea;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
            margin: 5px;
            transition: all 0.3s;
        }}
        .btn:hover {{
            background: #5568d3;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }}
        .timestamp {{
            text-align: center;
            color: #999;
            margin-top: 20px;
            font-size: 0.9em;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔄 LangGraph RAG 워크플로우</h1>
            <p>State Machine 기반 문서 검색 및 답변 생성 시스템</p>
        </div>
        
        <div class="content">
            <div class="diagram-container">
                <h2 style="margin-top: 0;">📊 워크플로우 다이어그램</h2>
                <div class="mermaid">
{mermaid_code}
                </div>
            </div>
            
            <div class="info-grid">
                <div class="info-card">
                    <h3>⚙️ 설정</h3>
                    <p><strong>임베딩 모델:</strong> {EMBEDDING_MODEL}</p>
                    <p><strong>LLM 모델:</strong> {LLM_MODEL}</p>
                    <p><strong>청크 크기:</strong> {CHUNK_SIZE}</p>
                    <p><strong>검색 문서 수:</strong> Top-{TOP_K}</p>
                    <p><strong>Temperature:</strong> {TEMPERATURE}</p>
                </div>
                
                <div class="info-card">
                    <h3>🎯 특징</h3>
                    <p>✅ 단계별 실행 추적</p>
                    <p>✅ 명시적 State 관리</p>
                    <p>✅ 디버깅 용이</p>
                    <p>✅ 확장 가능한 구조</p>
                    <p>✅ 성능 모니터링</p>
                </div>
                
                <div class="info-card">
                    <h3>🚀 성능</h3>
                    <p><strong>GPU:</strong> RTX 4090 24GB</p>
                    <p><strong>임베딩 차원:</strong> 4096</p>
                    <p><strong>처리 속도:</strong> ~2-5초</p>
                    <p><strong>동시 처리:</strong> 1-2개</p>
                </div>
            </div>
            
            <div class="node-list">
                <h2>📋 노드 상세 정보</h2>
"""
    
    for node_id, node_info in graph_structure["nodes"].items():
        if node_id not in ["START", "END"]:
            html_content += f"""
                <div class="node-item">
                    <h4>{node_info["label"]}</h4>
                    <p>{node_info["description"]}</p>
                </div>
"""
    
    html_content += f"""
            </div>
            
            <div class="controls">
                <h2>🔧 제어</h2>
                <button class="btn" onclick="location.reload()">🔄 새로고침</button>
                <button class="btn" onclick="window.print()">🖨️ 인쇄</button>
                <button class="btn" onclick="exportGraph()">💾 내보내기</button>
            </div>
            
            <div class="timestamp">
                생성 시간: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
            </div>
        </div>
    </div>
    
    <script>
        mermaid.initialize({{ startOnLoad: true, theme: 'default' }});
        
        function exportGraph() {{
            const graphData = {json.dumps(graph_structure, ensure_ascii=False, indent=2)};
            const blob = new Blob([JSON.stringify(graphData, null, 2)], {{type: 'application/json'}});
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'graph_structure.json';
            a.click();
        }}
    </script>
</body>
</html>"""
    
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    return filename


def print_graph_structure():
    """콘솔에 그래프 구조를 출력"""
    graph_structure = get_graph_structure()
    
    print("\n" + "=" * 60)
    print("📊 LangGraph 구조")
    print("=" * 60)
    
    print("\n🔹 노드:")
    for node_id, node_info in graph_structure["nodes"].items():
        print(f"  • {node_id}: {node_info['label']}")
        print(f"    설명: {node_info['description']}")
    
    print("\n🔹 엣지 (흐름):")
    for edge in graph_structure["edges"]:
        label = f" [{edge['label']}]" if edge.get('label') else ""
        print(f"  • {edge['from']} → {edge['to']}{label}")
    
    print("\n" + "=" * 60)


# ================================
# LangGraph 구성
# ================================

def create_rag_graph():
    """RAG 워크플로우 그래프 생성"""
    workflow = StateGraph(GraphState)
    
    # 노드 추가
    workflow.add_node("retrieve", retrieve_documents)
    workflow.add_node("evaluate", evaluate_documents)
    workflow.add_node("build_context", build_context)
    workflow.add_node("generate", generate_answer)
    
    # 엣지 정의 (워크플로우 흐름)
    workflow.set_entry_point("retrieve")
    workflow.add_edge("retrieve", "evaluate")
    workflow.add_edge("evaluate", "build_context")
    workflow.add_edge("build_context", "generate")
    workflow.add_edge("generate", END)
    
    # 그래프 컴파일
    app = workflow.compile()
    
    return app


def main():
    """메인 실행"""
    print("=" * 60)
    print("🚀 LangGraph RAG 시스템 + 시각화 (GPU 서버)")
    print("=" * 60)
    
    # 0. 서버 헬스 체크
    print("\n🔍 GPU 서버 상태 확인 중...")
    if not check_server_health():
        print("\n⚠️  서버에 연결할 수 없습니다. 다음을 확인하세요:")
        print(f"   - GPU 서버가 실행 중인지 확인: {API_URL}")
        print("   - FastAPI 서버가 8000 포트에서 실행 중인지 확인")
        print("   - API Key가 올바른지 확인")
        return
    
    # 그래프 구조 출력
    print_graph_structure()
    
    # 시각화 파일 생성
    print("\n🎨 시각화 파일 생성 중...")
    html_file = save_graph_visualization("graph_visualization.html")
    print(f"✅ 시각화 파일 저장: {html_file}")
    print(f"   브라우저에서 열기: file:///{os.path.abspath(html_file)}")
    
    # 1. 문서 로드
    documents = load_documents(KB_PATH)
    
    if not documents:
        print("❌ 로드할 문서가 없습니다.")
        return
    
    # 2. 문서 분할
    splits = split_documents(documents)
    
    # 3. 벡터스토어 생성 (전역 변수로 설정)
    global vectorstore
    vectorstore = create_vectorstore(splits)
    
    # 4. LangGraph 생성
    print("\n🔗 LangGraph 워크플로우 생성 중...")
    rag_app = create_rag_graph()
    print("✅ 워크플로우 생성 완료")
    
    print("\n" + "=" * 60)
    print("💬 명령어:")
    print("  - 질문 입력: 일반 텍스트")
    print("  - 그래프 보기: 'graph', 'show'")
    print("  - 시각화 열기: 'viz', 'visual'")
    print("  - 종료: 'quit', 'exit', 'q'")
    print("=" * 60 + "\n")
    
    # 5. 대화 루프
    while True:
        user_input = input("👤 입력: ").strip()
        
        if user_input.lower() in ['quit', 'exit', 'q', '종료']:
            print("👋 프로그램을 종료합니다.")
            break
        
        if user_input.lower() in ['graph', 'show', '그래프']:
            print_graph_structure()
            continue
        
        if user_input.lower() in ['viz', 'visual', '시각화']:
            html_file = save_graph_visualization("graph_visualization.html")
            print(f"\n✅ 시각화 파일 업데이트: {html_file}")
            print(f"   브라우저에서 열기: file:///{os.path.abspath(html_file)}")
            
            # 자동으로 브라우저 열기 시도
            try:
                import webbrowser
                webbrowser.open(f"file:///{os.path.abspath(html_file)}")
                print("   🌐 브라우저에서 자동으로 열었습니다.")
            except:
                print("   ⚠️  브라우저를 수동으로 열어주세요.")
            continue
        
        if not user_input:
            continue
        
        question = user_input
        
        print("\n" + "=" * 60)
        print("🔄 워크플로우 실행 중...")
        print("=" * 60)
        
        try:
            # 초기 상태 설정
            initial_state = {
                "question": question,
                "retrieved_documents": [],
                "context": "",
                "answer": "",
                "steps": [],
                "execution_time": {}
            }
            
            # 그래프 실행
            result = rag_app.invoke(initial_state)
            
            # 결과 출력
            print("\n" + "=" * 60)
            print("📋 실행 결과")
            print("=" * 60)
            
            print(f"\n💡 답변:\n{result['answer']}\n")
            
            # 참조 문서 출력
            if result.get('retrieved_documents'):
                print("📚 참조 문서:")
                for i, doc in enumerate(result['retrieved_documents'], 1):
                    source = doc.metadata.get('source', 'Unknown')
                    content_preview = doc.page_content[:100].replace('\n', ' ')
                    print(f"  {i}. {source}")
                    print(f"     {content_preview}...")
            
            # 실행 단계 및 시간 출력
            print(f"\n🔄 실행 단계: {' → '.join(result['steps'])}")
            
            if result.get('execution_time'):
                print("\n⏱️  실행 시간:")
                total_time = 0
                for step, time_taken in result['execution_time'].items():
                    print(f"  • {step}: {time_taken:.2f}초")
                    total_time += time_taken
                print(f"  📊 총 실행 시간: {total_time:.2f}초")
            
            print("\n" + "-" * 60 + "\n")
            
        except Exception as e:
            print(f"❌ 오류 발생: {e}\n")


if __name__ == "__main__":
    main()
