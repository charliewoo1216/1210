"""
GPU 서버 API 테스트 스크립트
"""

import requests
import json

# GPU 서버 설정
API_URL = "http://server-ip:8000"
API_KEY = "LDfvFBuAzG6P8DM7NFD4u2FGN7BeFSe8d47JqDGwu1I"

headers = {
    "X-API-Key": API_KEY,
    "Content-Type": "application/json"
}


def test_health():
    """헬스체크 테스트"""
    print("\n1️⃣  헬스체크 테스트...")
    try:
        response = requests.get(f"{API_URL}/health", timeout=5)
        print(f"   ✅ 상태: {response.status_code}")
        print(f"   응답: {response.json()}")
        return True
    except Exception as e:
        print(f"   ❌ 오류: {e}")
        return False


def test_embedding():
    """임베딩 API 테스트"""
    print("\n2️⃣  임베딩 API 테스트...")
    try:
        payload = {
            "input": "로그 분석 챗봇 테스트",
            "model": "qwen3-embedding:8b"
        }
        response = requests.post(
            f"{API_URL}/api/embed",
            headers=headers,
            json=payload,
            timeout=30
        )
        print(f"   ✅ 상태: {response.status_code}")
        embeddings = response.json()["embeddings"][0]
        print(f"   임베딩 차원: {len(embeddings)}")
        print(f"   첫 5개 값: {embeddings[:5]}")
        return True
    except Exception as e:
        print(f"   ❌ 오류: {e}")
        return False


def test_generate():
    """생성 API 테스트"""
    print("\n3️⃣  생성 API 테스트...")
    try:
        payload = {
            "prompt": "안녕하세요. 간단히 자기소개 해주세요.",
            "model": "qwen3:8b",
            "stream": False,
            "temperature": 0.7
        }
        response = requests.post(
            f"{API_URL}/api/generate",
            headers=headers,
            json=payload,
            timeout=60
        )
        print(f"   ✅ 상태: {response.status_code}")
        result = response.json()
        print(f"   모델: {result.get('model')}")
        print(f"   응답: {result.get('response')[:200]}...")
        return True
    except Exception as e:
        print(f"   ❌ 오류: {e}")
        return False


def test_rerank():
    """리랭킹 API 테스트"""
    print("\n4️⃣  리랭킹 API 테스트...")
    try:
        payload = {
            "query": "데이터베이스 연결 에러",
            "passages": [
                "[2025-11-16] INFO: 시스템 정상 작동",
                "[2025-11-16] ERROR: 데이터베이스 연결 실패",
                "[2025-11-16] WARNING: 메모리 사용량 높음"
            ],
            "model": "dengcao/Qwen3-Reranker-8B:Q8_0"
        }
        response = requests.post(
            f"{API_URL}/api/rerank",
            headers=headers,
            json=payload,
            timeout=30
        )
        print(f"   ✅ 상태: {response.status_code}")
        results = response.json()["results"]
        print(f"   정렬된 결과:")
        for i, result in enumerate(results, 1):
            print(f"      {i}. [Score: {result['score']:.3f}] {result['passage'][:50]}...")
        return True
    except Exception as e:
        print(f"   ❌ 오류: {e}")
        return False


def test_models():
    """모델 목록 조회 테스트"""
    print("\n5️⃣  모델 목록 조회 테스트...")
    try:
        response = requests.get(
            f"{API_URL}/api/models",
            headers=headers,
            timeout=10
        )
        print(f"   ✅ 상태: {response.status_code}")
        models = response.json()["models"]
        print(f"   설치된 모델: {len(models)}개")
        for model in models:
            size_gb = model['size'] / (1024**3)
            print(f"      - {model['name']} ({size_gb:.2f}GB)")
        return True
    except Exception as e:
        print(f"   ❌ 오류: {e}")
        return False


def main():
    """전체 테스트 실행"""
    print("=" * 60)
    print("🧪 GPU 서버 API 테스트 시작")
    print("=" * 60)
    print(f"API URL: {API_URL}")
    
    tests = [
        ("헬스체크", test_health),
        ("임베딩", test_embedding),
        ("생성", test_generate),
        ("리랭킹", test_rerank),
        ("모델 목록", test_models)
    ]
    
    results = {}
    for name, test_func in tests:
        results[name] = test_func()
    
    print("\n" + "=" * 60)
    print("📊 테스트 결과 요약")
    print("=" * 60)
    for name, success in results.items():
        status = "✅ 성공" if success else "❌ 실패"
        print(f"{name}: {status}")
    
    total = len(results)
    passed = sum(results.values())
    print(f"\n총 {total}개 중 {passed}개 테스트 통과")


if __name__ == "__main__":
    main()
