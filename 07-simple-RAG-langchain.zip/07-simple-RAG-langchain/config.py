"""
설정 파일
환경 변수 또는 기본값 사용
"""

import os
from dotenv import load_dotenv

# .env 파일 로드 (있는 경우)
load_dotenv()

# GPU 서버 설정
API_URL = os.getenv("API_URL", "http://server-ip:8000")
API_KEY = os.getenv("API_KEY", "LDfvFBuAzG6P8DM7NFD4u2FGN7BeFSe8d47JqDGwu1I")

# 모델 설정
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "qwen3-embedding:8b")
LLM_MODEL = os.getenv("LLM_MODEL", "qwen3:8b")
RERANK_MODEL = os.getenv("RERANK_MODEL", "dengcao/Qwen3-Reranker-8B:Q8_0")

# RAG 설정
CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", "500"))
CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", "50"))
TOP_K = int(os.getenv("TOP_K", "3"))
TEMPERATURE = float(os.getenv("TEMPERATURE", "0.7"))

# 문서 경로
KB_PATH = os.getenv("KB_PATH", "./RAG-KB")

# API 헤더
HEADERS = {
    "X-API-Key": API_KEY,
    "Content-Type": "application/json"
}

# 출력
if __name__ == "__main__":
    print("현재 설정:")
    print(f"  API_URL: {API_URL}")
    print(f"  EMBEDDING_MODEL: {EMBEDDING_MODEL}")
    print(f"  LLM_MODEL: {LLM_MODEL}")
    print(f"  CHUNK_SIZE: {CHUNK_SIZE}")
    print(f"  TOP_K: {TOP_K}")
