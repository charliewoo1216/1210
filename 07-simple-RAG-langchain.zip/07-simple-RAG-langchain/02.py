"""
LangGraph를 이용한 RAG 시스템
State Machine 기반 워크플로우로 문서 검색 및 답변 생성
GPU 서버의 Qwen3 모델 사용 (FastAPI Wrapper)
"""

import os
import requests
from typing import List, Optional, Any, TypedDict, Annotated
from langchain_community.document_loaders import DirectoryLoader, TextLoader
from langchain_community.vectorstores import FAISS
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings.base import Embeddings
from langchain.llms.base import LLM
from langchain.callbacks.manager import CallbackManagerForLLMRun
from langchain_core.documents import Document

# LangGraph 관련
from langgraph.graph import StateGraph, END
import operator

# 설정 파일 임포트 (config.py가 있으면 사용, 없으면 기본값)
try:
    from config import (
        API_URL, API_KEY, HEADERS,
        EMBEDDING_MODEL, LLM_MODEL,
        CHUNK_SIZE, CHUNK_OVERLAP, TOP_K, TEMPERATURE,
        KB_PATH
    )
except ImportError:
    # 기본 설정
    API_URL = "http://server-ip:8000"
    API_KEY = "LDfvFBuAzG6P8DM7NFD4u2FGN7BeFSe8d47JqDGwu1I"
    HEADERS = {
        "X-API-Key": API_KEY,
        "Content-Type": "application/json"
    }
    EMBEDDING_MODEL = "qwen3-embedding:8b"
    LLM_MODEL = "qwen3:8b"
    CHUNK_SIZE = 500
    CHUNK_OVERLAP = 50
    TOP_K = 3
    TEMPERATURE = 0.7
    KB_PATH = "./RAG-KB"


# ================================
# State 정의
# ================================

class GraphState(TypedDict):
    """
    RAG 워크플로우의 상태
    """
    question: str                          # 사용자 질문
    retrieved_documents: List[Document]    # 검색된 문서
    context: str                           # 최종 컨텍스트
    answer: str                            # 생성된 답변
    steps: Annotated[List[str], operator.add]  # 실행 단계 추적


# ================================
# Qwen3 API 클래스
# ================================

class Qwen3Embeddings(Embeddings):
    """Qwen3 임베딩 모델 (GPU 서버 API 사용)"""
    
    def __init__(self, api_url: str, api_key: str, model: str = "qwen3-embedding:8b"):
        self.api_url = api_url
        self.api_key = api_key
        self.model = model
    
    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """여러 문서 임베딩"""
        embeddings = []
        for text in texts:
            embedding = self._embed_single(text)
            embeddings.append(embedding)
        return embeddings
    
    def embed_query(self, text: str) -> List[float]:
        """단일 쿼리 임베딩"""
        return self._embed_single(text)
    
    def _embed_single(self, text: str) -> List[float]:
        """단일 텍스트 임베딩"""
        payload = {
            "input": text,
            "model": self.model
        }
        
        headers = {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json"
        }
        
        response = requests.post(
            f"{self.api_url}/api/embed",
            headers=headers,
            json=payload,
            timeout=30
        )
        
        if response.status_code != 200:
            raise Exception(f"임베딩 API 오류: {response.status_code} - {response.text}")
        
        return response.json()["embeddings"][0]


class Qwen3LLM(LLM):
    """Qwen3 LLM (GPU 서버 API 사용)"""
    
    api_url: str
    api_key: str
    model: str = "qwen3:8b"
    temperature: float = 0.7
    
    @property
    def _llm_type(self) -> str:
        return "qwen3"
    
    def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> str:
        """LLM 호출"""
        payload = {
            "prompt": prompt,
            "model": self.model,
            "stream": False,
            "temperature": self.temperature
        }
        
        headers = {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json"
        }
        
        response = requests.post(
            f"{self.api_url}/api/generate",
            headers=headers,
            json=payload,
            timeout=60
        )
        
        if response.status_code != 200:
            raise Exception(f"생성 API 오류: {response.status_code} - {response.text}")
        
        return response.json()["response"]


def check_server_health():
    """서버 헬스 체크"""
    try:
        response = requests.get(f"{API_URL}/health", timeout=5)
        if response.status_code == 200:
            print(f"✅ GPU 서버 연결 성공: {response.json()['status']}")
            return True
        else:
            print(f"❌ 서버 응답 오류: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ 서버 연결 실패: {e}")
        return False


def load_documents(directory_path):
    """문서 로드"""
    print(f"📁 문서 로딩 중: {directory_path}")
    
    # 텍스트 파일 로더
    txt_loader = DirectoryLoader(
        directory_path,
        glob="**/*.txt",
        loader_cls=TextLoader,
        loader_kwargs={'encoding': 'utf-8'}
    )
    
    # 마크다운 파일 로더
    md_loader = DirectoryLoader(
        directory_path,
        glob="**/*.md",
        loader_cls=TextLoader,
        loader_kwargs={'encoding': 'utf-8'}
    )
    
    txt_docs = txt_loader.load()
    md_docs = md_loader.load()
    
    all_docs = txt_docs + md_docs
    print(f"✅ {len(all_docs)}개 문서 로드 완료")
    
    return all_docs


def split_documents(documents):
    """문서 청킹"""
    print(f"✂️  문서 분할 중 (청크 크기: {CHUNK_SIZE}, 오버랩: {CHUNK_OVERLAP})...")
    
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        separators=["\n\n", "\n", ". ", " ", ""]
    )
    
    splits = text_splitter.split_documents(documents)
    print(f"✅ {len(splits)}개 청크 생성 완료")
    
    return splits


def create_vectorstore(documents):
    """벡터 스토어 생성 (GPU 서버 Qwen3 임베딩 사용)"""
    print(f"🔢 임베딩 및 벡터스토어 생성 중 ({EMBEDDING_MODEL}, 4096차원)...")
    
    # Qwen3 임베딩 모델 (GPU 서버)
    embeddings = Qwen3Embeddings(
        api_url=API_URL,
        api_key=API_KEY,
        model=EMBEDDING_MODEL
    )
    
    print(f"📊 {len(documents)}개 문서 임베딩 중...")
    vectorstore = FAISS.from_documents(documents, embeddings)
    print("✅ 벡터스토어 생성 완료")
    
    return vectorstore


# ================================
# LangGraph 노드 함수들
# ================================

def retrieve_documents(state: GraphState) -> GraphState:
    """
    노드 1: 문서 검색
    질문과 관련된 문서를 벡터 스토어에서 검색
    """
    print(f"\n🔍 [STEP 1] 문서 검색 중... (Top-{TOP_K})")
    
    question = state["question"]
    
    # 벡터 스토어에서 유사 문서 검색
    retriever = vectorstore.as_retriever(search_kwargs={"k": TOP_K})
    retrieved_docs = retriever.get_relevant_documents(question)
    
    print(f"   ✅ {len(retrieved_docs)}개 문서 검색 완료")
    
    return {
        **state,
        "retrieved_documents": retrieved_docs,
        "steps": ["문서 검색 완료"]
    }


def evaluate_documents(state: GraphState) -> GraphState:
    """
    노드 2: 문서 평가
    검색된 문서의 관련성 평가 및 필터링
    """
    print(f"\n📊 [STEP 2] 문서 평가 중...")
    
    retrieved_docs = state["retrieved_documents"]
    
    # 간단한 평가: 문서 길이와 키워드 확인
    # 실제로는 더 정교한 평가 로직을 추가할 수 있음
    evaluated_docs = []
    for doc in retrieved_docs:
        # 문서가 너무 짧지 않은지 확인
        if len(doc.page_content.strip()) > 20:
            evaluated_docs.append(doc)
    
    print(f"   ✅ {len(evaluated_docs)}개 문서 평가 통과")
    
    return {
        **state,
        "retrieved_documents": evaluated_docs,
        "steps": ["문서 평가 완료"]
    }


def build_context(state: GraphState) -> GraphState:
    """
    노드 3: 컨텍스트 구성
    검색된 문서들을 하나의 컨텍스트로 조합
    """
    print(f"\n📝 [STEP 3] 컨텍스트 구성 중...")
    
    retrieved_docs = state["retrieved_documents"]
    
    # 문서들을 하나의 컨텍스트로 결합
    context_parts = []
    for i, doc in enumerate(retrieved_docs, 1):
        source = doc.metadata.get('source', 'Unknown')
        content = doc.page_content.strip()
        context_parts.append(f"[문서 {i}] {source}\n{content}")
    
    context = "\n\n".join(context_parts)
    
    print(f"   ✅ 컨텍스트 구성 완료 ({len(context)} 글자)")
    
    return {
        **state,
        "context": context,
        "steps": ["컨텍스트 구성 완료"]
    }


def generate_answer(state: GraphState) -> GraphState:
    """
    노드 4: 답변 생성
    컨텍스트와 질문을 바탕으로 LLM이 답변 생성
    """
    print(f"\n🤖 [STEP 4] 답변 생성 중...")
    
    question = state["question"]
    context = state["context"]
    
    # 프롬프트 구성
    prompt = f"""다음 문서들을 참고하여 질문에 답변해주세요.

참고 문서:
{context}

질문: {question}

답변:"""
    
    # LLM 호출
    llm = Qwen3LLM(
        api_url=API_URL,
        api_key=API_KEY,
        model=LLM_MODEL,
        temperature=TEMPERATURE
    )
    
    answer = llm._call(prompt)
    
    print(f"   ✅ 답변 생성 완료 ({len(answer)} 글자)")
    
    return {
        **state,
        "answer": answer,
        "steps": ["답변 생성 완료"]
    }


# ================================
# LangGraph 구성
# ================================

def create_rag_graph():
    """
    RAG 워크플로우 그래프 생성
    """
    workflow = StateGraph(GraphState)
    
    # 노드 추가
    workflow.add_node("retrieve", retrieve_documents)
    workflow.add_node("evaluate", evaluate_documents)
    workflow.add_node("build_context", build_context)
    workflow.add_node("generate", generate_answer)
    
    # 엣지 정의 (워크플로우 흐름)
    workflow.set_entry_point("retrieve")
    workflow.add_edge("retrieve", "evaluate")
    workflow.add_edge("evaluate", "build_context")
    workflow.add_edge("build_context", "generate")
    workflow.add_edge("generate", END)
    
    # 그래프 컴파일
    app = workflow.compile()
    
    return app


def main():
    """메인 실행"""
    print("=" * 60)
    print("🚀 LangGraph RAG 시스템 시작 (GPU 서버)")
    print("=" * 60)
    
    # 0. 서버 헬스 체크
    print("\n🔍 GPU 서버 상태 확인 중...")
    if not check_server_health():
        print("\n⚠️  서버에 연결할 수 없습니다. 다음을 확인하세요:")
        print(f"   - GPU 서버가 실행 중인지 확인: {API_URL}")
        print("   - FastAPI 서버가 8000 포트에서 실행 중인지 확인")
        print("   - API Key가 올바른지 확인")
        return
    
    # 1. 문서 로드
    documents = load_documents(KB_PATH)
    
    if not documents:
        print("❌ 로드할 문서가 없습니다.")
        return
    
    # 2. 문서 분할
    splits = split_documents(documents)
    
    # 3. 벡터스토어 생성 (전역 변수로 설정)
    global vectorstore
    vectorstore = create_vectorstore(splits)
    
    # 4. LangGraph 생성
    print("\n🔗 LangGraph 워크플로우 생성 중...")
    rag_app = create_rag_graph()
    print("✅ 워크플로우 생성 완료")
    
    print("\n" + "=" * 60)
    print("💬 질문을 입력하세요 (종료: 'quit', 'exit', 'q')")
    print("=" * 60 + "\n")
    
    # 5. 대화 루프
    while True:
        question = input("👤 질문: ").strip()
        
        if question.lower() in ['quit', 'exit', 'q', '종료']:
            print("👋 프로그램을 종료합니다.")
            break
        
        if not question:
            continue
        
        print("\n" + "=" * 60)
        print("🔄 워크플로우 실행 중...")
        print("=" * 60)
        
        try:
            # 초기 상태 설정
            initial_state = {
                "question": question,
                "retrieved_documents": [],
                "context": "",
                "answer": "",
                "steps": []
            }
            
            # 그래프 실행
            result = rag_app.invoke(initial_state)
            
            # 결과 출력
            print("\n" + "=" * 60)
            print("📋 실행 결과")
            print("=" * 60)
            
            print(f"\n💡 답변:\n{result['answer']}\n")
            
            # 참조 문서 출력
            if result.get('retrieved_documents'):
                print("📚 참조 문서:")
                for i, doc in enumerate(result['retrieved_documents'], 1):
                    source = doc.metadata.get('source', 'Unknown')
                    content_preview = doc.page_content[:100].replace('\n', ' ')
                    print(f"  {i}. {source}")
                    print(f"     {content_preview}...")
            
            # 실행 단계 출력
            print(f"\n🔄 실행 단계: {' → '.join(result['steps'])}")
            
            print("\n" + "-" * 60 + "\n")
            
        except Exception as e:
            print(f"❌ 오류 발생: {e}\n")


if __name__ == "__main__":
    main()
