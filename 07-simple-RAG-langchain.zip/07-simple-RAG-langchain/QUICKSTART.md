# 빠른 시작 가이드

## ⚡ 3단계로 시작하기

### 1️⃣ 패키지 설치

```bash
pip install -r requirements.txt
```

설치되는 주요 패키지:
- `langchain` - LangChain 코어
- `langgraph` - 상태 기반 워크플로우
- `faiss-cpu` - 벡터 검색
- `requests` - API 통신

### 2️⃣ GPU 서버 테스트

```bash
python test_api.py
```

예상 출력:
```
🧪 GPU 서버 API 테스트 시작
============================================================
API URL: http://server-ip:8000

1️⃣  헬스체크 테스트...
   ✅ 상태: 200
   응답: {'status': 'healthy', ...}

2️⃣  임베딩 API 테스트...
   ✅ 상태: 200
   임베딩 차원: 4096

3️⃣  생성 API 테스트...
   ✅ 상태: 200
   모델: qwen3:8b

4️⃣  리랭킹 API 테스트...
   ✅ 상태: 200

5️⃣  모델 목록 조회 테스트...
   ✅ 상태: 200
   설치된 모델: 3개

============================================================
📊 테스트 결과 요약
============================================================
헬스체크: ✅ 성공
임베딩: ✅ 성공
생성: ✅ 성공
리랭킹: ✅ 성공
모델 목록: ✅ 성공

총 5개 중 5개 테스트 통과
```

### 3️⃣ RAG 실행

#### 옵션 A: LangChain 버전 (추천: 초보자)

```bash
python 01.py
```

**특징:**
- ✅ 간단하고 빠름
- ✅ 코드 이해하기 쉬움
- ✅ 즉시 사용 가능

#### 옵션 B: LangGraph 버전 (추천: 고급 사용자)

```bash
python 02.py
```

**특징:**
- ✅ 단계별 실행 추적
- ✅ 디버깅 용이
- ✅ 확장 가능한 구조

## 💬 사용 예시

### 질문하기

```
👤 질문: GPU 서버의 사양은?
```

### 01.py 출력 (LangChain)

```
🤖 답변 생성 중...

💡 답변: GPU 서버는 NVIDIA GeForce RTX 4090을 사용하며, 
VRAM은 24GB입니다. CUDA 버전은 12.9를 사용합니다.

📚 참조 문서:
  1. RAG-KB/10-GPU-api명세.txt
     GPU 환경 lsi-ai@lsi-ai-MS-7E25:~/temp$ nvidia-smi...
```

### 02.py 출력 (LangGraph)

```
============================================================
🔄 워크플로우 실행 중...
============================================================

🔍 [STEP 1] 문서 검색 중... (Top-3)
   ✅ 3개 문서 검색 완료

📊 [STEP 2] 문서 평가 중...
   ✅ 3개 문서 평가 통과

📝 [STEP 3] 컨텍스트 구성 중...
   ✅ 컨텍스트 구성 완료 (1523 글자)

🤖 [STEP 4] 답변 생성 중...
   ✅ 답변 생성 완료 (156 글자)

============================================================
📋 실행 결과
============================================================

💡 답변:
GPU 서버는 NVIDIA GeForce RTX 4090을 사용하며, 
VRAM은 24GB입니다. CUDA 버전은 12.9를 사용합니다.

📚 참조 문서:
  1. RAG-KB/10-GPU-api명세.txt
     GPU 환경 lsi-ai@lsi-ai-MS-7E25:~/temp$ nvidia-smi...

🔄 실행 단계: 문서 검색 완료 → 문서 평가 완료 → 컨텍스트 구성 완료 → 답변 생성 완료
```

## ⚙️ 설정 변경

### config.py 수정

```python
# config.py
API_URL = "http://your-server:8000"  # 서버 주소 변경
CHUNK_SIZE = 1000                     # 청크 크기 변경
TOP_K = 5                             # 검색 문서 수 변경
TEMPERATURE = 0.7                     # 생성 온도 변경
```

### 환경 변수 사용

```bash
# .env.example을 .env로 복사
cp .env.example .env

# .env 편집
API_URL=http://your-server:8000
CHUNK_SIZE=1000
TOP_K=5
```

## 🐛 문제 해결

### 서버 연결 실패

```
❌ 서버 연결 실패: [Errno 111] Connection refused
```

**해결:**
1. GPU 서버 실행 확인
2. IP 주소/포트 확인
3. 방화벽 설정 확인

```bash
# 서버 연결 테스트
curl http://server-ip:8000/health
```

### 임베딩 오류

```
❌ 임베딩 API 오류: 500 Internal Server Error
```

**해결:**
1. GPU 서버 메모리 확인
2. Ollama 서비스 상태 확인
3. 모델 설치 확인

```bash
# GPU 서버에서 확인
ollama list
```

### Import 오류

```
ModuleNotFoundError: No module named 'langgraph'
```

**해결:**
```bash
pip install -r requirements.txt --upgrade
```

## 📚 다음 단계

1. **[LANGGRAPH.md](LANGGRAPH.md)** - LangGraph 상세 설명
2. **[COMPARISON.md](COMPARISON.md)** - 01.py vs 02.py 비교
3. **[USAGE.md](USAGE.md)** - 고급 사용법
4. **실제 문서로 테스트** - RAG-KB 폴더에 문서 추가

## 💡 팁

### 빠른 답변을 원한다면
- `TEMPERATURE = 0.3` (더 일관된 답변)
- `TOP_K = 3` (적은 문서 검색)
- `CHUNK_SIZE = 500` (작은 청크)

### 정확한 답변을 원한다면
- `TEMPERATURE = 0.7` (균형잡힌 설정)
- `TOP_K = 5` (더 많은 문서 검색)
- `CHUNK_SIZE = 800` (큰 청크)

### 창의적 답변을 원한다면
- `TEMPERATURE = 0.9` (더 다양한 답변)
- `TOP_K = 5`
- `CHUNK_SIZE = 1000`

## 🎯 추천 시나리오

| 시나리오 | 추천 파일 | 이유 |
|---------|----------|------|
| 첫 사용 | 01.py | 간단하고 빠름 |
| 학습용 | 02.py | 내부 동작 이해 |
| 프로덕션 | 02.py | 디버깅 용이 |
| 프로토타입 | 01.py | 빠른 개발 |
| 복잡한 로직 | 02.py | 확장 가능 |

---

**준비 완료!** 이제 질문을 시작해보세요! 🚀
