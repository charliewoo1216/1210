# RAG 시스템 (LangChain + LangGraph + GPU 서버)

LangChain과 LangGraph를 사용하여 구현한 RAG(Retrieval-Augmented Generation) 시스템입니다.
GPU 서버의 Qwen3 모델을 활용합니다.

## 📦 세 가지 버전

| 파일 | 기술 | 난이도 | 추천 용도 |
|------|------|--------|-----------|
| **01.py** | LangChain | ⭐⭐ | 간단한 RAG, 프로토타입 |
| **02.py** | LangGraph | ⭐⭐⭐ | 복잡한 워크플로우, 프로덕션 |
| **03.py** | LangGraph + 시각화 | ⭐⭐⭐⭐ | 디버깅, 분석, 프레젠테이션 |

자세한 비교는 [COMPARISON.md](COMPARISON.md)를 참고하세요.  
시각화 가이드는 [VISUALIZATION.md](VISUALIZATION.md)를 참고하세요.

## 🎯 주요 기능

- **문서 로딩**: RAG-KB 폴더의 txt, md 파일 자동 로드
- **임베딩**: GPU 서버의 Qwen3-Embedding-8B (4096차원)
- **벡터 검색**: FAISS를 이용한 빠른 유사도 검색
- **질의응답**: GPU 서버의 Qwen3:8B LLM 기반 답변 생성
- **보안**: API Key 인증을 통한 안전한 통신

## 📦 설치

```bash
pip install -r requirements.txt
```

## 🚀 실행

### LangChain 버전 (간단)
```bash
python 01.py
```

### LangGraph 버전 (고급)
```bash
python 02.py
```

### LangGraph + 시각화 (프로페셔널)
```bash
python 03.py
```

**차이점:**
- `01.py`: 빠르고 간단, 블랙박스 처리
- `02.py`: 단계별 실행 추적, 디버깅 용이, 확장 가능
- `03.py`: 02.py + 실행 시간 측정, HTML 시각화, 인터랙티브 그래프

## 💡 사용 방법

1. 프로그램 실행 시 자동으로 RAG-KB 폴더의 문서를 로드합니다
2. 질문을 입력하면 관련 문서를 검색하여 답변을 생성합니다
3. 답변과 함께 참조한 문서 정보도 표시됩니다
4. 종료하려면 'quit', 'exit', 'q' 입력

## 🔧 설정

- **GPU 서버**: http://server-ip:8000
- **임베딩 모델**: Qwen3-Embedding-8B (4096차원, 다국어 지원)
- **LLM**: Qwen3:8B (답변 생성)
- **청크 크기**: 500자
- **청크 오버랩**: 50자
- **검색 문서 수**: 3개
- **인증**: X-API-Key 헤더 (FastAPI Wrapper)

## 📁 폴더 구조

```
07-simple-RAG-langchain/
├── 01.py                    # LangChain 버전 (간단)
├── 02.py                    # LangGraph 버전 (고급)
├── 03.py                    # LangGraph + 시각화 (프로)
├── config.py                # 설정 파일
├── test_api.py              # API 테스트
├── requirements.txt         # 의존성
├── README.md                # 프로젝트 개요
├── LANGGRAPH.md            # LangGraph 설명
├── COMPARISON.md           # 버전 비교
├── VISUALIZATION.md        # 시각화 가이드
├── USAGE.md                # 사용 가이드
├── QUICKSTART.md           # 빠른 시작
├── .env.example            # 환경 변수 템플릿
├── graph_visualization.html # 생성된 시각화 (03.py 실행 시)
└── RAG-KB/                 # 지식베이스 문서들
```

## ⚙️ 필수 요구사항

- Python 3.8+
- GPU 서버 실행 중 (FastAPI Wrapper + Ollama)
  - FastAPI: http://server-ip:8000
  - Ollama: http://localhost:11434
- 네트워크 연결 (LAN 환경 권장)
- API Key: `LDfvFBuAzG6P8DM7NFD4u2FGN7BeFSe8d47JqDGwu1I`

## 📝 코드 구조

1. **Qwen3Embeddings**: GPU 서버 임베딩 API 연동
2. **Qwen3LLM**: GPU 서버 생성 API 연동
3. **check_server_health()**: 서버 상태 확인
4. **load_documents()**: 문서 로딩
5. **split_documents()**: 문서 청킹
6. **create_vectorstore()**: 벡터스토어 생성
7. **create_qa_chain()**: QA 체인 생성
8. **main()**: 대화 루프 실행

## 🔐 보안 설정

API Key는 코드에 하드코딩되어 있습니다. 프로덕션 환경에서는 환경 변수 사용을 권장합니다:

```python
import os
API_KEY = os.getenv("QWEN3_API_KEY")
```

## 🚀 GPU 서버 구성

서버에 다음 모델이 설치되어 있어야 합니다:
- `qwen3-embedding:8b` (임베딩, 4096차원)
- `qwen3:8b` (답변 생성)
- `dengcao/Qwen3-Reranker-8B:Q8_0` (선택적)

## 📊 성능

- **임베딩**: 100 토큰 ~50ms
- **생성**: 토큰당 ~30ms (RTX 4090)
- **메모리**: GPU 서버 측에서 ~14GB 사용
- **정확도**: MTEB 다국어 리더보드 1위 (70.58)
