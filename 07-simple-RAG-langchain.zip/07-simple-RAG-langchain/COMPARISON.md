# 파일 비교: 01.py vs 02.py

## 📁 파일 개요

| 파일 | 기술 | 라인 수 | 복잡도 | 용도 |
|------|------|---------|--------|------|
| **01.py** | LangChain | ~210줄 | ⭐⭐ | 간단한 RAG |
| **02.py** | LangGraph | ~280줄 | ⭐⭐⭐ | 복잡한 워크플로우 |

## 🔄 주요 차이점

### 1. 아키텍처

**01.py (Chain 방식)**
```python
# 단일 체인으로 모든 것을 처리
qa_chain = RetrievalQA.from_chain_type(
    llm=llm,
    retriever=retriever,
    return_source_documents=True
)

# 실행
result = qa_chain.invoke({"query": question})
```

**02.py (Graph 방식)**
```python
# 각 단계를 노드로 분리
workflow.add_node("retrieve", retrieve_documents)
workflow.add_node("evaluate", evaluate_documents)
workflow.add_node("build_context", build_context)
workflow.add_node("generate", generate_answer)

# 워크플로우 정의
workflow.add_edge("retrieve", "evaluate")
workflow.add_edge("evaluate", "build_context")
# ...

# 실행
result = rag_app.invoke(initial_state)
```

### 2. State 관리

**01.py**
- State가 암묵적으로 체인 내부에서 관리됨
- 중간 결과에 접근하기 어려움

**02.py**
- State가 명시적으로 TypedDict로 정의됨
```python
class GraphState(TypedDict):
    question: str
    retrieved_documents: List[Document]
    context: str
    answer: str
    steps: List[str]
```
- 모든 중간 결과에 접근 가능

### 3. 디버깅

**01.py**
```python
# 결과만 확인 가능
print(result['result'])
print(result['source_documents'])
```

**02.py**
```python
# 각 단계별 진행 상황 확인
🔍 [STEP 1] 문서 검색 중...
📊 [STEP 2] 문서 평가 중...
📝 [STEP 3] 컨텍스트 구성 중...
🤖 [STEP 4] 답변 생성 중...

# 실행 단계 추적
print(result['steps'])
# ["문서 검색 완료", "문서 평가 완료", ...]
```

### 4. 확장성

**01.py**
```python
# 새로운 기능 추가가 어려움
# 체인을 다시 정의해야 함
```

**02.py**
```python
# 새로운 노드를 쉽게 추가
workflow.add_node("rerank", rerank_documents)
workflow.add_edge("evaluate", "rerank")
workflow.add_edge("rerank", "build_context")
```

### 5. 실행 흐름

**01.py**
```
질문 → [Chain 블랙박스] → 답변
```

**02.py**
```
질문 → 검색 → 평가 → 컨텍스트 구성 → 답변 생성 → 답변
       (각 단계 명시적)
```

## 💻 코드 비교

### 문서 검색

**01.py**
```python
# RetrievalQA 체인 내부에서 자동 처리
qa_chain = RetrievalQA.from_chain_type(
    llm=llm,
    retriever=vectorstore.as_retriever(search_kwargs={"k": 3}),
    return_source_documents=True
)
```

**02.py**
```python
def retrieve_documents(state: GraphState) -> GraphState:
    print(f"\n🔍 [STEP 1] 문서 검색 중... (Top-{TOP_K})")
    
    question = state["question"]
    retriever = vectorstore.as_retriever(search_kwargs={"k": TOP_K})
    retrieved_docs = retriever.get_relevant_documents(question)
    
    print(f"   ✅ {len(retrieved_docs)}개 문서 검색 완료")
    
    return {
        **state,
        "retrieved_documents": retrieved_docs,
        "steps": ["문서 검색 완료"]
    }
```

### 답변 생성

**01.py**
```python
# RetrievalQA가 내부적으로 처리
result = qa_chain.invoke({"query": question})
answer = result['result']
```

**02.py**
```python
def generate_answer(state: GraphState) -> GraphState:
    print(f"\n🤖 [STEP 4] 답변 생성 중...")
    
    question = state["question"]
    context = state["context"]
    
    prompt = f"""다음 문서들을 참고하여 질문에 답변해주세요.

참고 문서:
{context}

질문: {question}

답변:"""
    
    llm = Qwen3LLM(...)
    answer = llm._call(prompt)
    
    print(f"   ✅ 답변 생성 완료 ({len(answer)} 글자)")
    
    return {
        **state,
        "answer": answer,
        "steps": ["답변 생성 완료"]
    }
```

## 📊 성능 비교

| 측면 | 01.py | 02.py |
|------|-------|-------|
| 초기화 시간 | 빠름 | 약간 느림 |
| 실행 속도 | 빠름 | 거의 동일 |
| 메모리 사용 | 낮음 | 약간 높음 |
| 디버깅 시간 | 느림 | 빠름 |
| 유지보수 | 어려움 | 쉬움 |

## 🎯 선택 가이드

### 01.py를 선택하는 경우
- ✅ 빠른 프로토타입이 필요할 때
- ✅ 단순한 질의응답만 필요할 때
- ✅ 코드 간결성이 중요할 때
- ✅ LangChain에 익숙할 때

### 02.py를 선택하는 경우
- ✅ 프로덕션 환경에서 사용할 때
- ✅ 복잡한 워크플로우가 필요할 때
- ✅ 디버깅이 중요할 때
- ✅ 기능 확장이 예상될 때
- ✅ 단계별 모니터링이 필요할 때
- ✅ 조건부 분기가 필요할 때

## 🔧 실용적 예시

### 시나리오 1: 간단한 FAQ 봇
→ **01.py 추천**
- 단순 질의응답
- 빠른 구현
- 복잡한 로직 불필요

### 시나리오 2: 기업용 문서 검색 시스템
→ **02.py 추천**
- 문서 품질 검증 필요
- 리랭킹 적용
- 답변 검증 로직
- 로깅 및 모니터링

### 시나리오 3: 로그 분석 챗봇
→ **02.py 추천**
- 로그 필터링
- 패턴 분석
- 다단계 추론
- 결과 검증

## 🚀 마이그레이션

01.py → 02.py로 전환하기:

1. **State 정의**
```python
class GraphState(TypedDict):
    # 필요한 상태 변수 정의
    pass
```

2. **노드 함수 작성**
```python
def my_node(state: GraphState) -> GraphState:
    # 처리 로직
    return updated_state
```

3. **그래프 구성**
```python
workflow = StateGraph(GraphState)
workflow.add_node("step1", my_node)
# ...
app = workflow.compile()
```

4. **실행**
```python
result = app.invoke(initial_state)
```

## 📝 결론

- **학습/프로토타입**: 01.py로 시작
- **프로덕션**: 02.py로 전환
- **복잡한 요구사항**: 처음부터 02.py 사용

두 파일 모두 동일한 GPU 서버 API를 사용하므로, 필요에 따라 선택하거나 병행 사용 가능합니다.
