# LangGraph RAG 시스템 설명

## 🔄 LangGraph란?

LangGraph는 LangChain의 상태 기반 워크플로우 라이브러리로, 복잡한 AI 애플리케이션을 **State Machine** 방식으로 구성할 수 있게 합니다.

### 기존 LangChain vs LangGraph

| 특징 | LangChain (01.py) | LangGraph (02.py) |
|------|------------------|------------------|
| 구조 | 체인(Chain) 방식 | 그래프(Graph) 방식 |
| 흐름 제어 | 선형적 | 조건부 분기 가능 |
| 상태 관리 | 암묵적 | 명시적 (TypedDict) |
| 디버깅 | 어려움 | 쉬움 (단계별 추적) |
| 확장성 | 제한적 | 높음 |

## 📊 02.py 워크플로우

```
[사용자 질문]
     ↓
┌─────────────────────────────────────┐
│  STEP 1: retrieve_documents         │
│  - 벡터 검색 (Top-K)                │
│  - 유사 문서 찾기                    │
└─────────────────────────────────────┘
     ↓
┌─────────────────────────────────────┐
│  STEP 2: evaluate_documents         │
│  - 문서 품질 평가                    │
│  - 짧은 문서 필터링                  │
└─────────────────────────────────────┘
     ↓
┌─────────────────────────────────────┐
│  STEP 3: build_context              │
│  - 문서들을 하나로 결합              │
│  - 프롬프트 형식 구성                │
└─────────────────────────────────────┘
     ↓
┌─────────────────────────────────────┐
│  STEP 4: generate_answer            │
│  - LLM 호출                         │
│  - 최종 답변 생성                    │
└─────────────────────────────────────┘
     ↓
  [답변 반환]
```

## 🎯 State 구조

```python
class GraphState(TypedDict):
    question: str                    # 사용자 질문
    retrieved_documents: List[Doc]   # 검색된 문서
    context: str                     # 결합된 컨텍스트
    answer: str                      # 최종 답변
    steps: List[str]                 # 실행 단계 추적
```

각 노드는 State를 받아서 처리한 후, 업데이트된 State를 반환합니다.

## 🔧 주요 구성 요소

### 1. 노드 (Nodes)
- **retrieve_documents**: 문서 검색
- **evaluate_documents**: 문서 평가
- **build_context**: 컨텍스트 구성
- **generate_answer**: 답변 생성

### 2. 엣지 (Edges)
노드 간의 연결을 정의:
```python
retrieve → evaluate → build_context → generate → END
```

### 3. State 관리
모든 노드가 공유하는 중앙 집중식 상태 관리

## 💡 LangGraph의 장점

### 1. **명시적 흐름 제어**
각 단계가 명확하게 정의되어 있어 이해하기 쉽습니다.

### 2. **디버깅 용이**
```python
steps: ["문서 검색 완료", "문서 평가 완료", "컨텍스트 구성 완료", "답변 생성 완료"]
```
실행 단계를 추적하여 어디서 문제가 발생했는지 쉽게 파악 가능합니다.

### 3. **확장 가능**
새로운 노드를 추가하거나 조건부 분기를 쉽게 구현할 수 있습니다:

```python
# 예: 리랭킹 노드 추가
workflow.add_node("rerank", rerank_documents)
workflow.add_edge("evaluate", "rerank")
workflow.add_edge("rerank", "build_context")
```

### 4. **조건부 분기**
상황에 따라 다른 경로로 진행할 수 있습니다:

```python
def should_rerank(state):
    if len(state["retrieved_documents"]) > 5:
        return "rerank"
    return "build_context"

workflow.add_conditional_edges(
    "evaluate",
    should_rerank,
    {
        "rerank": "rerank",
        "build_context": "build_context"
    }
)
```

### 5. **병렬 처리**
여러 노드를 동시에 실행할 수 있습니다.

## 🚀 실행 예시

```bash
python 02.py
```

출력:
```
🚀 LangGraph RAG 시스템 시작 (GPU 서버)
✅ GPU 서버 연결 성공: healthy
📁 문서 로딩 중: ./RAG-KB
✅ 9개 문서 로드 완료
✂️  문서 분할 중 (청크 크기: 500, 오버랩: 50)...
✅ 45개 청크 생성 완료
🔢 임베딩 및 벡터스토어 생성 중 (qwen3-embedding:8b, 4096차원)...
✅ 벡터스토어 생성 완료
🔗 LangGraph 워크플로우 생성 중...
✅ 워크플로우 생성 완료

💬 질문을 입력하세요 (종료: 'quit', 'exit', 'q')

👤 질문: GPU 서버의 메모리는?

============================================================
🔄 워크플로우 실행 중...
============================================================

🔍 [STEP 1] 문서 검색 중... (Top-3)
   ✅ 3개 문서 검색 완료

📊 [STEP 2] 문서 평가 중...
   ✅ 3개 문서 평가 통과

📝 [STEP 3] 컨텍스트 구성 중...
   ✅ 컨텍스트 구성 완료 (1523 글자)

🤖 [STEP 4] 답변 생성 중...
   ✅ 답변 생성 완료 (156 글자)

============================================================
📋 실행 결과
============================================================

💡 답변:
GPU 서버는 NVIDIA GeForce RTX 4090을 사용하며, 
VRAM은 24,564MB (약 24GB)입니다...

📚 참조 문서:
  1. RAG-KB/10-GPU-api명세.txt
     GPU 환경 lsi-ai@lsi-ai-MS-7E25...

🔄 실행 단계: 문서 검색 완료 → 문서 평가 완료 → 컨텍스트 구성 완료 → 답변 생성 완료
```

## 🔍 01.py vs 02.py 비교

### 01.py (LangChain)
- **장점**: 간단하고 빠르게 구현 가능
- **단점**: 흐름이 블랙박스화, 디버깅 어려움
- **추천**: 프로토타입, 간단한 RAG

### 02.py (LangGraph)
- **장점**: 명시적 흐름, 디버깅 용이, 확장 가능
- **단점**: 코드가 조금 더 복잡
- **추천**: 프로덕션, 복잡한 워크플로우

## 📈 확장 아이디어

### 1. 리랭킹 추가
```python
def rerank_documents(state: GraphState) -> GraphState:
    # GPU 서버 리랭킹 API 호출
    payload = {
        "query": state["question"],
        "passages": [doc.page_content for doc in state["retrieved_documents"]],
        "model": "dengcao/Qwen3-Reranker-8B:Q8_0"
    }
    # ...
```

### 2. 답변 품질 검증
```python
def validate_answer(state: GraphState) -> GraphState:
    # 답변이 질문에 적절한지 검증
    # 부적절하면 재생성
    pass
```

### 3. 대화 히스토리
```python
class GraphState(TypedDict):
    # ...
    chat_history: List[Dict[str, str]]  # 대화 기록
```

### 4. 다중 소스 검색
```python
workflow.add_node("search_web", search_web)
workflow.add_node("search_db", search_database)
# 두 결과를 병합
```

## 📚 참고 자료

- [LangGraph 공식 문서](https://langchain-ai.github.io/langgraph/)
- [LangGraph GitHub](https://github.com/langchain-ai/langgraph)
- [LangGraph 튜토리얼](https://python.langchain.com/docs/langgraph)
