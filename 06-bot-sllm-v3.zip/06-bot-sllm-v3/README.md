# 📊 로그 분석 챗봇 (Ollama + Qwen3)

로컬 GPU 서버의 Ollama API를 활용한 로그 파일 분석 챗봇입니다.

## 🎯 주요 기능

- **Ollama API 기반**: GPU 서버의 Qwen3 모델 사용
- **벡터 검색**: FAISS를 이용한 고속 유사도 검색
- **RAG 기반 답변**: 검색된 로그를 기반으로 정확한 답변 생성
- **리랭킹 (옵션)**: 검색 결과의 정확도를 높이는 재정렬 기능
- **Streamlit UI**: 직관적인 웹 인터페이스

## 🔧 시스템 구성

```
┌─────────────────┐         ┌──────────────────┐
│   로컬 PC       │         │   GPU 서버       │
│                 │         │                  │
│  Streamlit UI   │ ──────> │  Ollama API      │
│  FAISS VectorDB │  HTTP   │  - Qwen3:8b      │
│  app.py         │         │  - Embedding     │
│                 │         │  - Reranker      │
└─────────────────┘         └──────────────────┘
```

## 📦 설치

### 1. Python 패키지 설치

```bash
pip install -r requirements.txt
```

### 2. 필수 패키지
- `streamlit==1.28.1` - 웹 UI
- `requests==2.31.0` - API 통신
- `faiss-cpu==1.7.4` - 벡터 데이터베이스
- `numpy==1.24.3` - 수치 계산
- `pandas==2.0.3` - 데이터 처리

## ⚙️ 설정

### config.json / log_config.json

```json
{
    "ollama_api_url": "http://server-ip:8000",
    "ollama_api_key": "YOUR_API_KEY",
    "llm_model": "qwen3:8b",
    "embedding_model": "qwen3-embedding:8b",
    "rerank_model": "dengcao/Qwen3-Reranker-8B:Q8_0",
    "temperature": 0.7,
    "max_search_results": 5,
    "chunk_size": 5,
    "use_rerank": false
}
```

## 🚀 실행

```bash
streamlit run app.py
```

브라우저가 자동으로 열립니다: `http://localhost:8501`

## 📖 사용 방법

### 1. 설정 페이지
1. 사이드바에서 "🔧 설정" 선택
2. Ollama API URL과 API Key 입력
3. "🔍 서버 상태 확인" 버튼으로 연결 확인
4. 모델 및 검색 옵션 설정
5. "💾 설정 저장" 클릭

### 2. 챗봇 페이지
1. 사이드바에서 "🤖 챗봇" 선택
2. 로그 파일(.txt) 업로드
3. "🔄 로그 임베딩 및 저장" 클릭
4. 채팅창에서 로그에 대해 질문

## 🎨 주요 기능 상세

### 로그 파싱 및 청킹
- 로그 파일을 의미 있는 라인으로 파싱
- 설정된 `chunk_size`만큼 연관된 로그를 그룹화
- 각 청크를 벡터로 변환하여 저장

### 벡터 검색
- 질문을 벡터로 변환
- FAISS를 이용한 유사도 검색
- 상위 N개 결과 반환 (설정 가능)

### 리랭킹 (선택 사항)
- 검색 결과를 재정렬하여 정확도 향상
- **Qwen3-Reranker-8B:Q8_0** 모델 사용
- 컨텍스트: 32K 토큰
- 다국어 지원: 100개 이상 언어
- Instruction Aware (사용자 정의 지침 지원)
- 성능: MTEB-R 69.02, CMTEB-R 77.45 (중국어 1위급)
- 설정에서 활성화 가능

### RAG 기반 답변
- 검색된 로그를 컨텍스트로 제공
- Qwen3:8b 모델이 답변 생성
- 로그에 기반한 정확한 분석 제공

## 🔍 API 엔드포인트

### 1. 헬스체크
```
GET /health
```

### 2. 임베딩 생성
```
POST /api/embed
Body: {
    "input": "텍스트",
    "model": "qwen3-embedding:8b"
}
```

### 3. 응답 생성
```
POST /api/generate
Body: {
    "prompt": "질문",
    "model": "qwen3:8b",
    "stream": false,
    "temperature": 0.7
}
```

### 4. 리랭킹
```
POST /api/rerank
Body: {
    "query": "데이터베이스 연결 에러",
    "passages": [
        "[2025-11-16] INFO: 시스템 정상 작동",
        "[2025-11-16] ERROR: 데이터베이스 연결 실패",
        "[2025-11-16] WARNING: 메모리 사용량 높음"
    ],
    "model": "dengcao/Qwen3-Reranker-8B:Q8_0"
}

응답: 관련성 높은 순으로 정렬된 결과 (index, score, passage)
```

## 📊 벡터 DB 구조

```
log_vector_store/
├── index.faiss      # FAISS 인덱스 (1024차원)
└── meta.pkl         # 메타데이터 (원본 텍스트)
```

- **차원**: 1024 (Qwen3 embedding)
- **인덱스**: FlatL2 (정확한 유사도 검색)
- **메타데이터**: 원본 로그 텍스트

## 🔐 보안

- API Key는 HTTP 헤더 `X-API-Key`로 전송
- 설정 파일의 API Key는 암호화되지 않음 (주의 필요)
- GPU 서버는 방화벽으로 보호

## ⚠️ 주의사항

1. **GPU 서버 필수**: Ollama API 서버가 실행 중이어야 함
2. **네트워크 연결**: GPU 서버와 통신 가능해야 함
3. **메모리 사용량**: 대용량 로그 파일은 분할 처리 권장
4. **응답 시간**: 모델 크기에 따라 5-30초 소요 가능

## 🆚 OpenAI 버전과의 차이점

| 항목 | OpenAI 버전 | Ollama 버전 |
|------|------------|------------|
| API | OpenAI API | 로컬 Ollama API |
| 모델 | GPT-3.5/4 | Qwen3:8b |
| 임베딩 | text-embedding-3-small (1536차원) | qwen3-embedding:8b (4096차원) |
| 비용 | 유료 (토큰당 과금) | 무료 (자체 서버) |
| 속도 | 빠름 (1-3초) | 중간 (5-30초) |
| 리랭킹 | 없음 | Qwen3-Reranker-8B (8B 파라미터, 100개 언어) |
| 데이터 보안 | 외부 전송 | 내부 처리 |
| 다국어 성능 | 우수 | 매우 우수 (중국어/한국어/일본어 특화) |

## 🔄 마이그레이션 가이드

### OpenAI → Ollama 전환 시 변경사항

1. **의존성 변경**
   ```bash
   # 제거
   pip uninstall openai
   
   # 추가
   pip install requests
   ```

2. **설정 파일**
   - `openai_api_key` → `ollama_api_key`
   - `gpt_model` → `llm_model`
   - `embedding_model` 변경 (차원 1536 → 4096)

3. **VectorDB 재생성 필요**
   - 임베딩 차원이 변경되어 기존 DB 사용 불가 (1536 → 4096)
   - 로그 파일을 다시 업로드하여 임베딩 수행

## 🛠️ 트러블슈팅

### 서버 연결 실패
```
❌ Ollama 서버에 연결할 수 없습니다
```
- GPU 서버가 실행 중인지 확인
- API URL이 올바른지 확인
- 방화벽/네트워크 설정 확인

### 임베딩 실패
```
❌ 임베딩 실패: HTTP 403
```
- API Key가 올바른지 확인
- 서버의 인증 설정 확인

### 응답 생성 시간 초과
- `timeout` 값 증가 (현재 120초)
- 더 작은 모델 사용 고려
- GPU 서버 리소스 확인

### 리랭킹 속도 느림
- 양자화 버전 변경: Q8_0 → Q5_K_M 또는 Q4_K_M
- 리랭킹 비활성화 (설정에서 `use_rerank: false`)
- Top-K 결과 개수 줄이기

## 🎯 모델 선택 가이드

### Qwen3-Reranker 양자화 버전
| 버전 | 크기 | 품질 | 속도 | 권장 용도 |
|------|------|------|------|----------|
| F16 | 16GB | ⭐⭐⭐⭐⭐ | ❌ 매우 느림 | 비권장 |
| Q8_0 | 8.7GB | ⭐⭐⭐⭐⭐ | ⚠️ 느림 | 고정밀 검색 |
| **Q5_K_M** | 5.8GB | ⭐⭐⭐⭐ | ✅ 보통 | **권장 (균형)** |
| Q4_K_M | 5.0GB | ⭐⭐⭐ | ✅ 빠름 | 메모리 절약 |
| Q3_K_M | 4.1GB | ⭐⭐ | ⚡ 매우 빠름 | 최소 사양 |

현재 구현: **Q8_0** (최고 품질)

### 시나리오별 권장 설정

#### 고정밀 로그 분석 (현재 설정)
```json
{
    "embedding_model": "qwen3-embedding:8b",
    "rerank_model": "dengcao/Qwen3-Reranker-8B:Q8_0",
    "use_rerank": true,
    "max_search_results": 5
}
```

#### 빠른 응답 우선
```json
{
    "embedding_model": "qwen3-embedding:8b",
    "rerank_model": "dengcao/Qwen3-Reranker-8B:Q4_K_M",
    "use_rerank": false,
    "max_search_results": 3
}
```

## 📝 개발 히스토리

- **v1.0**: OpenAI API 기반 구현
- **v2.0**: Ollama API로 완전 전환
  - Qwen3 모델 사용
  - 리랭킹 기능 추가
  - 로컬 GPU 서버 연동

## 👥 참고 파일

- `app.py` - 메인 애플리케이션
- `api_test.py` - API 테스트 코드
- `config.json` - 설정 파일
- `requirements.txt` - 패키지 목록

## 📞 문의

문제 발생 시 GPU 서버 관리자에게 문의하세요.
