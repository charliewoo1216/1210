"""
Ollama API 서버 클라이언트 테스트 코드
로컬 PC에서 실행하여 GPU 서버의 FastAPI 서버에 접근
"""

import requests
import json

# GPU 서버 설정
API_URL = "http://server-ip:8000"
API_KEY = "key"  # .env 파일의 API_KEY와 동일

# 헤더 설정
headers = {
    "X-API-Key": API_KEY,
    "Content-Type": "application/json"
}

def test_health():
    """헬스체크 (API Key 불필요)"""
    print("=" * 60)
    print("1. 헬스체크")
    print("=" * 60)
    
    try:
        response = requests.get(f"{API_URL}/health", timeout=5)
        
        if response.status_code == 200:
            data = response.json()
            print(f"✅ 서버 상태: {data['status']}")
            print(f"📡 Ollama 호스트: {data['ollama_host']}")
            print(f"🕐 타임스탬프: {data['timestamp']}")
            return True
        else:
            print(f"❌ 실패: HTTP {response.status_code}")
            return False
            
    except Exception as e:
        print(f"❌ 연결 실패: {e}")
        return False

def test_embed():
    """임베딩 테스트"""
    print("\n" + "=" * 60)
    print("2. 임베딩 API 테스트")
    print("=" * 60)
    
    payload = {
        "input": "로그 분석 챗봇 테스트",
        "model": "qwen3-embedding:8b"
    }
    
    try:
        response = requests.post(
            f"{API_URL}/api/embed",
            headers=headers,
            json=payload,
            timeout=30
        )
        
        if response.status_code == 200:
            data = response.json()
            embeddings = data.get("embeddings", [[]])[0]
            
            print(f"✅ 임베딩 생성 성공!")
            print(f"📊 차원: {len(embeddings)}차원")
            print(f"🔢 샘플 벡터: {embeddings[:5]}")
            return True
        else:
            print(f"❌ 실패: HTTP {response.status_code}")
            print(f"응답: {response.text}")
            return False
            
    except Exception as e:
        print(f"❌ 오류: {e}")
        return False

def test_generate():
    """생성 API 테스트"""
    print("\n" + "=" * 60)
    print("3. 생성 API 테스트")
    print("=" * 60)
    
    payload = {
        "prompt": "안녕하세요. 간단히 자기소개를 해주세요.",
        "model": "qwen3:8b",
        "stream": False,
        "temperature": 0.7
    }
    
    try:
        response = requests.post(
            f"{API_URL}/api/generate",
            headers=headers,
            json=payload,
            timeout=60
        )
        
        if response.status_code == 200:
            data = response.json()
            answer = data.get("response", "")
            
            print(f"✅ 답변 생성 성공!")
            print(f"📝 답변:\n{answer}")
            
            if "eval_count" in data:
                print(f"\n📊 생성 토큰: {data.get('eval_count', 0)}개")
                print(f"📊 입력 토큰: {data.get('prompt_eval_count', 0)}개")
            
            return True
        else:
            print(f"❌ 실패: HTTP {response.status_code}")
            print(f"응답: {response.text}")
            return False
            
    except Exception as e:
        print(f"❌ 오류: {e}")
        return False

def test_rerank():
    """리랭킹 API 테스트"""
    print("\n" + "=" * 60)
    print("4. 리랭킹 API 테스트")
    print("=" * 60)
    
    payload = {
        "query": "데이터베이스 연결 에러",
        "passages": [
            "[2025-11-16] INFO: 시스템 정상 작동",
            "[2025-11-16] ERROR: 데이터베이스 연결 실패",
            "[2025-11-16] WARNING: 메모리 사용량 높음"
        ],
        "model": "dengcao/Qwen3-Reranker-8B:Q8_0"
    }
    
    try:
        response = requests.post(
            f"{API_URL}/api/rerank",
            headers=headers,
            json=payload,
            timeout=60
        )
        
        if response.status_code == 200:
            data = response.json()
            
            print(f"✅ 리랭킹 성공!")
            print(f"🔍 쿼리: {data['query']}")
            print(f"\n📊 결과 (관련성 순):")
            
            for result in data['results']:
                print(f"   [{result['index']}] 점수: {result['score']:.3f}")
                print(f"       {result['passage'][:60]}...")
            
            return True
        else:
            print(f"❌ 실패: HTTP {response.status_code}")
            print(f"응답: {response.text}")
            return False
            
    except Exception as e:
        print(f"❌ 오류: {e}")
        return False

def test_models():
    """모델 목록 조회"""
    print("\n" + "=" * 60)
    print("5. 모델 목록 조회")
    print("=" * 60)
    
    try:
        response = requests.get(
            f"{API_URL}/api/models",
            headers=headers,
            timeout=10
        )
        
        if response.status_code == 200:
            data = response.json()
            models = data.get("models", [])
            
            print(f"✅ 모델 조회 성공!")
            print(f"📦 설치된 모델: {len(models)}개")
            
            for model in models:
                print(f"   - {model['name']}")
                print(f"     크기: {model['size'] / 1024**3:.2f} GB")
            
            return True
        else:
            print(f"❌ 실패: HTTP {response.status_code}")
            print(f"응답: {response.text}")
            return False
            
    except Exception as e:
        print(f"❌ 오류: {e}")
        return False

def test_invalid_key():
    """잘못된 API Key 테스트"""
    print("\n" + "=" * 60)
    print("6. 보안 테스트 (잘못된 API Key)")
    print("=" * 60)
    
    invalid_headers = {
        "X-API-Key": "invalid-key-12345",
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.get(
            f"{API_URL}/api/models",
            headers=invalid_headers,
            timeout=5
        )
        
        if response.status_code == 403:
            print(f"✅ 보안 정상 작동! (403 Forbidden)")
            print(f"📝 응답: {response.json()}")
            return True
        else:
            print(f"⚠️  예상과 다른 응답: HTTP {response.status_code}")
            return False
            
    except Exception as e:
        print(f"❌ 오류: {e}")
        return False

def main():
    """전체 테스트 실행"""
    print("\n🚀 Ollama API 서버 클라이언트 테스트")
    print(f"🌐 서버: {API_URL}")
    print("\n")
    
    results = []
    
    # 테스트 실행
    results.append(("헬스체크", test_health()))
    results.append(("임베딩", test_embed()))
    results.append(("생성", test_generate()))
    results.append(("리랭킹", test_rerank()))
    results.append(("모델 목록", test_models()))
    results.append(("보안 테스트", test_invalid_key()))
    
    # 결과 요약
    print("\n" + "=" * 60)
    print("📊 테스트 결과 요약")
    print("=" * 60)
    
    for name, success in results:
        status = "✅ 성공" if success else "❌ 실패"
        print(f"{name:15s} : {status}")
    
    total = len(results)
    passed = sum(1 for _, s in results if s)
    
    print("\n" + "=" * 60)
    print(f"🎯 총 {passed}/{total}개 테스트 통과")
    print("=" * 60)

if __name__ == "__main__":
    main()