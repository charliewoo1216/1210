# main.py
import sys
import ast
import os
import json
import requests
import difflib
import tiktoken
import faiss
import numpy as np
from pathlib import Path
from typing import Optional, Tuple, List, Dict
from sentence_transformers import SentenceTransformer
import pickle
from dotenv import load_dotenv

# API 설정 로드
load_dotenv()
API_URL = os.getenv('API_URL', '121.128.243.214')
API_KEY = os.getenv('YOUR_API_KEY', 'LDfvFBuAzG6P8DM7NFD4u2FGN7BeFSe8d47JqDGwu1I')
API_BASE_URL = f"http://{API_URL}:8000/api"

from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QTextEdit, QSplitter, QStatusBar, QLabel, QMessageBox,
    QComboBox, QListWidget, QListWidgetItem, QTabWidget, QLineEdit,
    QFileDialog, QTreeWidget, QTreeWidgetItem, QInputDialog, QCheckBox,
    QProgressBar
)
from PySide6.QtCore import Qt, QThread, Signal, QTimer
from PySide6.QtGui import QFont, QColor, QTextCursor, QIcon, QDragEnterEvent, QDropEvent, QSyntaxHighlighter, QTextCharFormat
from PySide6.QtWidgets import QPlainTextEdit
import re


class TokenCounter:
    """토큰 카운터"""
    
    def __init__(self, model="gpt-4"):
        try:
            self.encoding = tiktoken.encoding_for_model(model)
        except:
            self.encoding = tiktoken.get_encoding("cl100k_base")
    
    def count_tokens(self, text: str) -> int:
        """텍스트의 토큰 수 계산"""
        return len(self.encoding.encode(text))
    
    def check_limit(self, text: str, max_tokens: int = 4000) -> Tuple[bool, int]:
        """토큰 제한 체크"""
        token_count = self.count_tokens(text)
        return token_count <= max_tokens, token_count


class RAGSystem:
    """RAG 시스템 - FAISS 기반 벡터 저장소"""
    
    def __init__(self, storage_dir: str = "./rag_docs"):
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        
        # API 임베딩 설정
        self.embed_url = f"{API_BASE_URL}/embed"
        self.embed_model = "qwen3-embedding:8b"
        self.dimension = 768  # qwen3-embedding:8b의 임베딩 차원
        
        # FAISS 인덱스
        self.index = None
        self.documents = []  # 원본 문서 청크
        self.metadata = []  # 메타데이터 (파일명, 청크 번호 등)
        
        # 기존 인덱스 로드
        self.load_index()
    
    def chunk_text(self, text: str, chunk_size: int = 500, overlap: int = 50) -> List[str]:
        """텍스트를 청크로 분할"""
        chunks = []
        start = 0
        text_length = len(text)
        
        while start < text_length:
            end = start + chunk_size
            chunk = text[start:end]
            
            # 문장 경계에서 자르기
            if end < text_length:
                last_period = chunk.rfind('.')
                last_newline = chunk.rfind('\n')
                split_point = max(last_period, last_newline)
                
                if split_point > chunk_size // 2:
                    chunk = chunk[:split_point + 1]
                    end = start + split_point + 1
            
            chunks.append(chunk.strip())
            start = end - overlap
        
        return chunks
    
    def add_document(self, filename: str, content: str) -> int:
        """문서를 벡터 저장소에 추가"""
        # 청크 생성
        chunks = self.chunk_text(content)
        
        if not chunks:
            return 0
        
        # 임베딩 생성 (API 호출)
        embeddings = self._get_embeddings(chunks)
        
        # FAISS 인덱스가 없으면 생성
        if self.index is None:
            self.index = faiss.IndexFlatL2(self.dimension)
        
        # 인덱스에 추가
        self.index.add(embeddings.astype('float32'))
        
        # 메타데이터 저장
        for i, chunk in enumerate(chunks):
            self.documents.append(chunk)
            self.metadata.append({
                'filename': filename,
                'chunk_id': i,
                'total_chunks': len(chunks)
            })
        
        # 저장
        self.save_index()
        
        return len(chunks)
    
    def search(self, query: str, top_k: int = 3) -> List[Dict]:
        """유사한 문서 청크 검색"""
        if self.index is None or len(self.documents) == 0:
            return []
        
        # 쿼리 임베딩 (API 호출)
        query_embedding = self._get_embeddings([query])
        
        # 검색
        distances, indices = self.index.search(query_embedding.astype('float32'), top_k)
        
        # 결과 구성
        results = []
        for i, idx in enumerate(indices[0]):
            if idx < len(self.documents):
                results.append({
                    'content': self.documents[idx],
                    'metadata': self.metadata[idx],
                    'score': float(distances[0][i])
                })
        
        return results
    
    def get_context_for_query(self, query: str, max_tokens: int = 2000) -> str:
        """쿼리에 대한 컨텍스트 생성"""
        results = self.search(query, top_k=5)
        
        if not results:
            return ""
        
        # 토큰 제한 내에서 컨텍스트 구성
        token_counter = TokenCounter()
        context_parts = []
        current_tokens = 0
        
        for result in results:
            content = result['content']
            filename = result['metadata']['filename']
            
            chunk_text = f"[출처: {filename}]\n{content}\n"
            chunk_tokens = token_counter.count_tokens(chunk_text)
            
            if current_tokens + chunk_tokens > max_tokens:
                break
            
            context_parts.append(chunk_text)
            current_tokens += chunk_tokens
        
        return "\n---\n".join(context_parts)
    
    def save_index(self):
        """인덱스를 디스크에 저장"""
        if self.index is not None:
            # FAISS 인덱스 저장
            faiss.write_index(self.index, str(self.storage_dir / "faiss.index"))
            
            # 문서 및 메타데이터 저장
            with open(self.storage_dir / "documents.pkl", 'wb') as f:
                pickle.dump({
                    'documents': self.documents,
                    'metadata': self.metadata
                }, f)
    
    def load_index(self):
        """인덱스를 디스크에서 로드"""
        index_path = self.storage_dir / "faiss.index"
        docs_path = self.storage_dir / "documents.pkl"
        
        if index_path.exists() and docs_path.exists():
            try:
                # FAISS 인덱스 로드
                self.index = faiss.read_index(str(index_path))
                
                # 문서 및 메타데이터 로드
                with open(docs_path, 'rb') as f:
                    data = pickle.load(f)
                    self.documents = data['documents']
                    self.metadata = data['metadata']
                
                return True
            except Exception as e:
                print(f"인덱스 로드 실패: {e}")
                return False
        
        return False
    
    def clear_index(self):
        """모든 인덱스 삭제"""
        self.index = None
        self.documents = []
        self.metadata = []
        
        # 파일 삭제
        index_path = self.storage_dir / "faiss.index"
        docs_path = self.storage_dir / "documents.pkl"
        
        if index_path.exists():
            index_path.unlink()
        if docs_path.exists():
            docs_path.unlink()
    
    def get_all_files(self) -> List[str]:
        """저장된 모든 파일명 반환"""
        filenames = set()
        for meta in self.metadata:
            filenames.add(meta['filename'])
        return sorted(list(filenames))
    
    def get_stats(self) -> Dict:
        """통계 정보 반환"""
        return {
            'total_chunks': len(self.documents),
            'total_files': len(self.get_all_files()),
            'files': self.get_all_files()
        }
    
    def _get_embeddings(self, texts: List[str]) -> np.ndarray:
        """API를 통해 임베딩 생성"""
        try:
            all_embeddings = []
            # 배치 처리 (한 번에 너무 많이 보내지 않기 위해)
            batch_size = 10
            for i in range(0, len(texts), batch_size):
                batch = texts[i:i + batch_size]
                for text in batch:
                    response = requests.post(
                        self.embed_url,
                        headers={
                            "X-API-Key": API_KEY,
                            "Content-Type": "application/json"
                        },
                        json={
                            "input": text,
                            "model": self.embed_model
                        },
                        timeout=30
                    )
                    
                    if response.status_code == 200:
                        result = response.json()
                        embedding = result.get('embedding', [])
                        all_embeddings.append(embedding)
                    else:
                        raise Exception(f"Embedding API 오류: {response.status_code}")
            
            return np.array(all_embeddings, dtype='float32')
        except Exception as e:
            print(f"임베딩 생성 실패: {e}")
            # 폴백: 랜덤 임베딩 (테스트용)
            return np.random.randn(len(texts), self.dimension).astype('float32')


class CodeAnalyzer:
    """Python 코드 분석기 (AST 기반)"""
    
    @staticmethod
    def get_function_at_line(code: str, line_number: int) -> Optional[str]:
        """특정 줄에 있는 함수/메서드 추출"""
        try:
            tree = ast.parse(code)
            lines = code.split('\n')
            
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    start_line = node.lineno - 1
                    end_line = node.end_lineno
                    
                    if start_line <= line_number < end_line:
                        function_lines = lines[start_line:end_line]
                        return '\n'.join(function_lines)
            
            return None
        except:
            return None
    
    @staticmethod
    def get_class_at_line(code: str, line_number: int) -> Optional[str]:
        """특정 줄에 있는 클래스 추출"""
        try:
            tree = ast.parse(code)
            lines = code.split('\n')
            
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    start_line = node.lineno - 1
                    end_line = node.end_lineno
                    
                    if start_line <= line_number < end_line:
                        class_lines = lines[start_line:end_line]
                        return '\n'.join(class_lines)
            
            return None
        except:
            return None
    
    @staticmethod
    def extract_imports(code: str) -> str:
        """import 문들만 추출"""
        try:
            tree = ast.parse(code)
            lines = code.split('\n')
            import_lines = []
            
            for node in ast.walk(tree):
                if isinstance(node, (ast.Import, ast.ImportFrom)):
                    if hasattr(node, 'lineno'):
                        import_lines.append(lines[node.lineno - 1])
            
            return '\n'.join(import_lines)
        except:
            return ""
    
    @staticmethod
    def get_smart_context(code: str, cursor_line: int, max_lines: int = 100) -> str:
        """커서 위치 기반 스마트 컨텍스트 추출"""
        function_code = CodeAnalyzer.get_function_at_line(code, cursor_line)
        if function_code:
            imports = CodeAnalyzer.extract_imports(code)
            return f"{imports}\n\n{function_code}" if imports else function_code
        
        class_code = CodeAnalyzer.get_class_at_line(code, cursor_line)
        if class_code:
            imports = CodeAnalyzer.extract_imports(code)
            return f"{imports}\n\n{class_code}" if imports else class_code
        
        lines = code.split('\n')
        start = max(0, cursor_line - max_lines // 2)
        end = min(len(lines), cursor_line + max_lines // 2)
        return '\n'.join(lines[start:end])


class RAGCodingWorker(QThread):
    """RAG 기반 코딩 워커"""
    finished = Signal(str)
    error = Signal(str)
    progress = Signal(str)
    
    def __init__(self, code: str, prompt: str, rag_context: str, model: str = "qwen3:8b"):
        super().__init__()
        self.code = code
        self.prompt = prompt
        self.rag_context = rag_context
        self.model = model
        self.api_url = f"{API_BASE_URL}/generate"
    
    def run(self):
        """RAG 컨텍스트를 포함한 코드 생성"""
        try:
            self.progress.emit("RAG 컨텍스트와 함께 코드 생성 중...")
            
            system_prompt = """당신은 코드 작성 전문가입니다.
제공된 참고 문서를 기반으로 코드를 작성하거나 개선하세요.
참고 문서의 가이드라인, 패턴, 베스트 프랙티스를 따르세요.
응답은 순수 코드만 포함하고, 설명이나 마크다운 없이 작성하세요."""

            full_prompt = f"{system_prompt}\n\n"
            
            if self.rag_context:
                full_prompt += f"=== 참고 문서 ===\n{self.rag_context}\n\n"
            
            if self.code:
                full_prompt += f"=== 현재 코드 ===\n```python\n{self.code}\n```\n\n"
            
            full_prompt += f"=== 요청사항 ===\n{self.prompt}\n\n수정된 코드:"
            
            payload = {
                "model": self.model,
                "prompt": full_prompt,
                "stream": False,
                "temperature": 0.3
            }
            
            self.progress.emit("AI 응답 대기 중...")
            
            response = requests.post(
                self.api_url,
                headers={
                    "X-API-Key": API_KEY,
                    "Content-Type": "application/json"
                },
                json=payload,
                timeout=180
            )
            
            if response.status_code == 200:
                result = response.json()
                suggested_code = result.get("response", "").strip()
                
                # 마크다운 제거
                suggested_code = self._clean_code_block(suggested_code)
                
                self.progress.emit("코드 생성 완료")
                self.finished.emit(suggested_code)
            else:
                self.error.emit(f"API 오류: {response.status_code}")
                
        except Exception as e:
            self.error.emit(f"오류 발생: {str(e)}")
    
    def _clean_code_block(self, text: str) -> str:
        """마크다운 코드 블록 제거"""
        text = text.strip()
        
        if text.startswith("```"):
            lines = text.split("\n")
            if len(lines) > 2:
                if lines[-1].strip() == "```":
                    text = "\n".join(lines[1:-1])
                else:
                    text = "\n".join(lines[1:])
        
        return text.strip()


class VibeCodingWorker(QThread):
    """바이브 코딩 워커 - 프로젝트 전체 생성"""
    finished = Signal(dict)
    error = Signal(str)
    progress = Signal(str)
    
    def __init__(self, prompt: str, model: str = "qwen3:8b", context: str = ""):
        super().__init__()
        self.prompt = prompt
        self.model = model
        self.context = context
        self.api_url = f"{API_BASE_URL}/generate"
    
    def run(self):
        """프로젝트 생성"""
        try:
            self.progress.emit("프로젝트 구조 분석 중...")
            
            system_prompt = """당신은 전문 소프트웨어 아키텍트입니다.
사용자의 요구사항을 분석하고, 완전한 프로젝트를 생성합니다.

응답 형식은 반드시 다음 JSON 구조를 따라야 합니다:
{
  "files": [
    {
      "filename": "main.py",
      "content": "파일의 전체 내용"
    },
    {
      "filename": "utils.py",
      "content": "파일의 전체 내용"
    }
  ],
  "description": "프로젝트 설명"
}

각 파일은 완전하고 실행 가능해야 하며, 적절한 주석을 포함해야 합니다.
JSON 형식만 출력하고, 다른 설명은 포함하지 마세요."""

            full_prompt = f"{system_prompt}\n\n"
            if self.context:
                full_prompt += f"기존 컨텍스트:\n{self.context}\n\n"
            full_prompt += f"요구사항:\n{self.prompt}\n\n프로젝트를 JSON 형식으로 생성하세요:"
            
            payload = {
                "model": self.model,
                "prompt": full_prompt,
                "stream": False,
                "temperature": 0.4
            }
            
            self.progress.emit("AI가 프로젝트를 생성하는 중...")
            
            response = requests.post(
                self.api_url,
                headers={
                    "X-API-Key": API_KEY,
                    "Content-Type": "application/json"
                },
                json=payload,
                timeout=180
            )
            
            if response.status_code == 200:
                result = response.json()
                response_text = result.get("response", "").strip()
                
                project_data = self._extract_json(response_text)
                
                if not project_data:
                    self.error.emit("JSON 형식의 응답을 받지 못했습니다.")
                    return
                
                files = {}
                if "files" in project_data:
                    for file_info in project_data["files"]:
                        filename = file_info.get("filename", "")
                        content = file_info.get("content", "")
                        if filename and content:
                            files[filename] = content
                
                if not files:
                    self.error.emit("생성된 파일이 없습니다.")
                    return
                
                self.progress.emit(f"{len(files)}개 파일 생성 완료")
                self.finished.emit(files)
            else:
                self.error.emit(f"API 오류: {response.status_code}")
                
        except Exception as e:
            self.error.emit(f"오류 발생: {str(e)}")
    
    def _extract_json(self, text: str) -> Optional[dict]:
        """텍스트에서 JSON 추출"""
        text = text.strip()
        if "```json" in text:
            start = text.find("```json") + 7
            end = text.find("```", start)
            text = text[start:end].strip()
        elif "```" in text:
            start = text.find("```") + 3
            end = text.find("```", start)
            text = text[start:end].strip()
        
        try:
            json_start = text.find("{")
            if json_start != -1:
                json_end = text.rfind("}") + 1
                if json_end > json_start:
                    json_text = text[json_start:json_end]
                    return json.loads(json_text)
        except:
            pass
        
        return None


class OllamaWorker(QThread):
    """일반 코드 개선 워커"""
    finished = Signal(str)
    error = Signal(str)
    progress = Signal(str)
    
    def __init__(self, code, prompt, model="qwen3:8b", timeout=120):
        super().__init__()
        self.code = code
        self.prompt = prompt
        self.model = model
        self.timeout = timeout
        self.api_url = f"{API_BASE_URL}/generate"
    
    def run(self):
        """Ollama API 호출"""
        try:
            self.progress.emit("API 요청 전송 중...")
            
            system_prompt = """당신은 코드 개선 전문가입니다. 
주어진 코드를 분석하고 개선된 버전을 제공하세요.
응답은 오직 수정된 코드만 포함해야 하며, 설명이나 마크다운 포맷 없이 순수 코드만 출력하세요.
코드의 들여쓰기와 구조를 정확히 유지하세요."""

            full_prompt = f"{system_prompt}\n\n원본 코드:\n```python\n{self.code}\n```\n\n요청사항: {self.prompt}\n\n수정된 코드:"
            
            payload = {
                "model": self.model,
                "prompt": full_prompt,
                "stream": False,
                "temperature": 0.3
            }
            
            self.progress.emit("응답 대기 중...")
            
            response = requests.post(
                self.api_url,
                headers={
                    "X-API-Key": API_KEY,
                    "Content-Type": "application/json"
                },
                json=payload,
                timeout=self.timeout
            )
            
            if response.status_code == 200:
                result = response.json()
                suggested_code = result.get("response", "").strip()
                
                suggested_code = self._clean_code_block(suggested_code)
                
                if not self._validate_code(suggested_code):
                    self.error.emit("생성된 코드가 불완전합니다. 다시 시도해주세요.")
                    return
                
                self.progress.emit("코드 생성 완료")
                self.finished.emit(suggested_code)
            else:
                self.error.emit(f"API 오류: {response.status_code}")
                
        except requests.exceptions.Timeout:
            self.error.emit(f"요청 시간 초과 ({self.timeout}초). 코드가 너무 길거나 서버가 느립니다.")
        except requests.exceptions.ConnectionError:
            self.error.emit(f"API 서버에 연결할 수 없습니다.\n{API_BASE_URL}에서 실행 중인지 확인하세요.")
        except Exception as e:
            self.error.emit(f"오류 발생: {str(e)}")
    
    def _clean_code_block(self, text: str) -> str:
        """마크다운 코드 블록 제거"""
        text = text.strip()
        
        if text.startswith("```"):
            lines = text.split("\n")
            if len(lines) > 2:
                if lines[-1].strip() == "```":
                    text = "\n".join(lines[1:-1])
                else:
                    text = "\n".join(lines[1:])
        
        return text.strip()
    
    def _validate_code(self, code: str) -> bool:
        """생성된 코드가 완전한지 검증"""
        if not code or len(code) < 10:
            return False
        
        stack = []
        pairs = {'(': ')', '[': ']', '{': '}'}
        
        for char in code:
            if char in pairs:
                stack.append(char)
            elif char in pairs.values():
                if not stack:
                    return False
                if pairs[stack[-1]] != char:
                    return False
                stack.pop()
        
        return len(stack) == 0


class PythonHighlighter(QSyntaxHighlighter):
    """Python syntax highlighter - Dark Mode"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # Define formats for dark mode
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569cd6"))  # VS Code blue
        keyword_format.setFontWeight(QFont.Weight.Bold)
        
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#ce9178"))  # VS Code orange
        
        comment_format = QTextCharFormat()
        comment_format.setForeground(QColor("#6a9955"))  # VS Code green
        comment_format.setFontItalic(True)
        
        function_format = QTextCharFormat()
        function_format.setForeground(QColor("#dcdcaa"))  # VS Code yellow
        
        # Define rules
        self.rules = []
        
        # Keywords
        keywords = [
            'and', 'as', 'assert', 'break', 'class', 'continue', 'def',
            'del', 'elif', 'else', 'except', 'False', 'finally', 'for',
            'from', 'global', 'if', 'import', 'in', 'is', 'lambda', 'None',
            'nonlocal', 'not', 'or', 'pass', 'raise', 'return', 'True',
            'try', 'while', 'with', 'yield', 'async', 'await'
        ]
        
        for word in keywords:
            pattern = f'\\b{word}\\b'
            self.rules.append((re.compile(pattern), keyword_format))
        
        # Strings
        self.rules.append((re.compile(r'"[^"\\]*(\\.[^"\\]*)*"'), string_format))
        self.rules.append((re.compile(r"'[^'\\]*(\\.[^'\\]*)*'"), string_format))
        
        # Comments
        self.rules.append((re.compile(r'#[^\n]*'), comment_format))
        
        # Functions
        self.rules.append((re.compile(r'\bdef\s+(\w+)'), function_format))
    
    def highlightBlock(self, text):
        """Apply syntax highlighting to the given block of text"""
        for pattern, fmt in self.rules:
            for match in pattern.finditer(text):
                start = match.start()
                length = match.end() - start
                self.setFormat(start, length, fmt)


class CodeEditor(QPlainTextEdit):
    """Code editor widget"""
    
    def __init__(self):
        super().__init__()
        self.setup_editor()
        self.highlighter = PythonHighlighter(self.document())
    
    def setup_editor(self):
        """Editor setup"""
        font = QFont("Consolas", 11)
        self.setFont(font)
        
        # Tab settings
        self.setTabStopDistance(40)  # 4 spaces
        
        # Line wrap
        self.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
    
    def get_current_line(self) -> int:
        """Get current cursor line number (0-based)"""
        return self.textCursor().blockNumber()


class DiffViewer(QTextEdit):
    """Diff 표시 위젯"""
    
    def __init__(self):
        super().__init__()
        self.setReadOnly(True)
        font = QFont("Consolas", 10)
        self.setFont(font)
    
    def show_diff(self, original, modified):
        """두 코드의 차이점을 표시 - Dark Mode"""
        self.clear()
        
        original_lines = original.splitlines()
        modified_lines = modified.splitlines()
        
        diff = difflib.unified_diff(
            original_lines,
            modified_lines,
            lineterm='',
            fromfile='원본',
            tofile='수정본'
        )
        
        html = "<pre style='font-family: Consolas; font-size: 10pt; color: #d4d4d4; background-color: #1e1e1e;'>"
        
        for line in diff:
            if line.startswith('+++') or line.startswith('---'):
                html += f"<span style='color: #858585; font-weight: bold;'>{self._escape_html(line)}</span>\n"
            elif line.startswith('+'):
                html += f"<span style='background-color: #1a5c1a; color: #4ec9b0;'>{self._escape_html(line)}</span>\n"
            elif line.startswith('-'):
                html += f"<span style='background-color: #5c1a1a; color: #f48771;'>{self._escape_html(line)}</span>\n"
            elif line.startswith('@@'):
                html += f"<span style='color: #569cd6; font-weight: bold;'>{self._escape_html(line)}</span>\n"
            else:
                html += f"<span style='color: #d4d4d4;'>{self._escape_html(line)}</span>\n"
        
        html += "</pre>"
        self.setHtml(html)
    
    def _escape_html(self, text):
        """HTML 특수문자 이스케이프"""
        return text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


class FileTreeWidget(QTreeWidget):
    """파일 트리 위젯"""
    
    file_selected = Signal(str)
    
    def __init__(self):
        super().__init__()
        self.setHeaderLabel("프로젝트 파일")
        self.itemClicked.connect(self._on_item_clicked)
        self.files_data = {}
    
    def load_files(self, files: Dict[str, str]):
        """파일 목록 로드"""
        self.clear()
        self.files_data = files
        
        for filename in sorted(files.keys()):
            item = QTreeWidgetItem([filename])
            item.setData(0, Qt.ItemDataRole.UserRole, filename)
            self.addTopLevelItem(item)
    
    def _on_item_clicked(self, item, column):
        """파일 클릭 시"""
        filename = item.data(0, Qt.ItemDataRole.UserRole)
        if filename:
            self.file_selected.emit(filename)
    
    def get_file_content(self, filename: str) -> str:
        """파일 내용 가져오기"""
        return self.files_data.get(filename, "")
    
    def update_file_content(self, filename: str, content: str):
        """파일 내용 업데이트"""
        self.files_data[filename] = content


class RAGPanel(QWidget):
    """RAG 기반 코딩 패널"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_window = parent
        self.rag_system = RAGSystem()
        self.init_ui()
        
        # 드래그 앤 드롭 활성화
        self.setAcceptDrops(True)
    
    def init_ui(self):
        """UI 초기화"""
        layout = QVBoxLayout(self)
        
        # === 상단: 문서 관리 섹션 ===
        doc_section = QWidget()
        doc_layout = QVBoxLayout(doc_section)
        
        doc_header = QLabel("📚 참고 문서 관리")
        doc_header.setStyleSheet("font-size: 14pt; font-weight: bold; color: #d4d4d4;")
        doc_layout.addWidget(doc_header)
        
        # 문서 업로드 영역
        upload_layout = QHBoxLayout()
        
        self.upload_button = QPushButton("📁 문서 업로드 (TXT, MD, PDF)")
        self.upload_button.setStyleSheet("""
            QPushButton {
                background-color: #3498db;
                color: white;
                padding: 10px;
                font-size: 12px;
                border: none;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
        """)
        self.upload_button.clicked.connect(self.upload_documents)
        
        self.clear_button = QPushButton("🗑️ 전체 삭제")
        self.clear_button.setStyleSheet("""
            QPushButton {
                background-color: #e74c3c;
                color: white;
                padding: 10px;
                font-size: 12px;
                border: none;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #c0392b;
            }
        """)
        self.clear_button.clicked.connect(self.clear_all_documents)
        
        upload_layout.addWidget(self.upload_button)
        upload_layout.addWidget(self.clear_button)
        upload_layout.addStretch()
        
        doc_layout.addLayout(upload_layout)
        
        # 문서 목록
        self.doc_list = QListWidget()
        self.doc_list.setMaximumHeight(150)
        doc_layout.addWidget(QLabel("업로드된 문서:"))
        doc_layout.addWidget(self.doc_list)
        
        # 통계 정보
        self.stats_label = QLabel("총 0개 문서, 0개 청크")
        self.stats_label.setStyleSheet("color: #858585; font-size: 10pt;")
        doc_layout.addWidget(self.stats_label)
        
        layout.addWidget(doc_section)
        
        # 구분선
        line = QWidget()
        line.setFixedHeight(2)
        line.setStyleSheet("background-color: #3c3c3c;")
        layout.addWidget(line)
        
        # === 중단: 코딩 섹션 ===
        coding_header = QLabel("💻 RAG 기반 코딩")
        coding_header.setStyleSheet("font-size: 14pt; font-weight: bold; color: #d4d4d4;")
        layout.addWidget(coding_header)
        
        # 스플리터
        splitter = QSplitter(Qt.Orientation.Horizontal)
        
        # 왼쪽: 에디터
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        
        left_layout.addWidget(QLabel("코드 에디터:"))
        self.editor = CodeEditor()
        self.editor.setPlainText("# RAG 참고 문서를 기반으로 코드를 작성하세요\n")
        left_layout.addWidget(self.editor)
        
        # 오른쪽: 컨텍스트 뷰어
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        
        right_layout.addWidget(QLabel("참고 컨텍스트:"))
        self.context_viewer = QTextEdit()
        self.context_viewer.setReadOnly(True)
        self.context_viewer.setPlaceholderText("코드 생성 시 관련 문서 내용이 여기 표시됩니다...")
        right_layout.addWidget(self.context_viewer)
        
        splitter.addWidget(left_panel)
        splitter.addWidget(right_panel)
        splitter.setSizes([600, 400])
        
        layout.addWidget(splitter)
        
        # === 하단: 프롬프트 및 버튼 ===
        prompt_layout = QVBoxLayout()
        
        prompt_layout.addWidget(QLabel("코딩 요청:"))
        self.prompt_input = QTextEdit()
        self.prompt_input.setMaximumHeight(80)
        self.prompt_input.setPlaceholderText(
            "예: 업로드한 코딩 가이드를 참고하여 FastAPI로 사용자 인증 API를 작성해주세요."
        )
        prompt_layout.addWidget(self.prompt_input)
        
        # 버튼 레이아웃
        button_layout = QHBoxLayout()
        
        self.generate_button = QPushButton("🚀 RAG 기반 코드 생성")
        self.generate_button.setStyleSheet("""
            QPushButton {
                background-color: #27ae60;
                color: white;
                padding: 12px;
                font-size: 14px;
                border: none;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #229954;
            }
        """)
        self.generate_button.clicked.connect(self.generate_code_with_rag)
        
        self.improve_button = QPushButton("✨ 현재 코드 개선")
        self.improve_button.setStyleSheet("""
            QPushButton {
                background-color: #f39c12;
                color: white;
                padding: 12px;
                font-size: 14px;
                border: none;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #e67e22;
            }
        """)
        self.improve_button.clicked.connect(self.improve_code_with_rag)
        
        button_layout.addWidget(self.generate_button)
        button_layout.addWidget(self.improve_button)
        
        prompt_layout.addLayout(button_layout)
        layout.addLayout(prompt_layout)
        
        # 초기 통계 업데이트
        self.update_stats()
    
    def dragEnterEvent(self, event: QDragEnterEvent):
        """드래그 엔터 이벤트"""
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
    
    def dropEvent(self, event: QDropEvent):
        """드롭 이벤트 - 파일 드래그 앤 드롭"""
        files = [url.toLocalFile() for url in event.mimeData().urls()]
        self.process_files(files)
    
    def upload_documents(self):
        """문서 업로드"""
        files, _ = QFileDialog.getOpenFileNames(
            self,
            "참고 문서 선택",
            "",
            "Documents (*.txt *.md *.pdf);;All Files (*)"
        )
        
        if files:
            self.process_files(files)
    
    def process_files(self, files: List[str]):
        """파일 처리"""
        total_chunks = 0
        
        for file_path in files:
            try:
                file_path_obj = Path(file_path)
                filename = file_path_obj.name
                
                # 파일 읽기
                if file_path_obj.suffix.lower() == '.pdf':
                    content = self.read_pdf(file_path)
                else:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                
                # RAG 시스템에 추가
                chunks = self.rag_system.add_document(filename, content)
                total_chunks += chunks
                
                self.main_window.status_bar.showMessage(
                    f"✓ {filename} 추가됨 ({chunks}개 청크)"
                )
                
            except Exception as e:
                QMessageBox.critical(
                    self,
                    "오류",
                    f"파일 처리 중 오류:\n{file_path}\n{str(e)}"
                )
        
        if total_chunks > 0:
            self.update_stats()
            QMessageBox.information(
                self,
                "완료",
                f"{len(files)}개 문서가 추가되었습니다.\n총 {total_chunks}개 청크가 생성되었습니다."
            )
    
    def read_pdf(self, file_path: str) -> str:
        """PDF 파일 읽기"""
        try:
            import PyPDF2
            
            with open(file_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                text = ""
                for page in pdf_reader.pages:
                    text += page.extract_text()
                return text
        except Exception as e:
            raise Exception(f"PDF 읽기 실패: {str(e)}")
    
    def update_stats(self):
        """통계 업데이트"""
        stats = self.rag_system.get_stats()
        
        self.doc_list.clear()
        for filename in stats['files']:
            self.doc_list.addItem(filename)
        
        self.stats_label.setText(
            f"총 {stats['total_files']}개 문서, {stats['total_chunks']}개 청크"
        )
    
    def clear_all_documents(self):
        """모든 문서 삭제"""
        reply = QMessageBox.question(
            self,
            "확인",
            "모든 문서를 삭제하시겠습니까?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            self.rag_system.clear_index()
            self.update_stats()
            self.main_window.status_bar.showMessage("✓ 모든 문서가 삭제되었습니다.")
    
    def generate_code_with_rag(self):
        """RAG 기반 코드 생성"""
        prompt = self.prompt_input.toPlainText().strip()
        
        if not prompt:
            QMessageBox.warning(self, "경고", "코딩 요청을 입력해주세요.")
            return
        
        stats = self.rag_system.get_stats()
        if stats['total_chunks'] == 0:
            QMessageBox.warning(
                self,
                "경고",
                "참고 문서가 없습니다.\n먼저 문서를 업로드해주세요."
            )
            return
        
        # RAG 컨텍스트 검색
        self.main_window.status_bar.showMessage("🔍 관련 문서 검색 중...")
        rag_context = self.rag_system.get_context_for_query(prompt, max_tokens=2000)
        
        # 컨텍스트 표시
        self.context_viewer.setPlainText(rag_context)
        
        # 현재 코드
        current_code = self.editor.text()
        
        # 워커 시작
        self.generate_button.setEnabled(False)
        self.improve_button.setEnabled(False)
        
        model = self.main_window.model_combo.currentText()
        
        self.worker = RAGCodingWorker(
            code=current_code,
            prompt=prompt,
            rag_context=rag_context,
            model=model
        )
        self.worker.finished.connect(self.on_code_generated)
        self.worker.error.connect(self.on_error)
        self.worker.progress.connect(self.on_progress)
        self.worker.start()
    
    def improve_code_with_rag(self):
        """RAG 기반 코드 개선"""
        current_code = self.editor.toPlainText().strip()
        
        if not current_code:
            QMessageBox.warning(self, "경고", "개선할 코드를 먼저 작성해주세요.")
            return
        
        stats = self.rag_system.get_stats()
        if stats['total_chunks'] == 0:
            QMessageBox.warning(
                self,
                "경고",
                "참고 문서가 없습니다.\n먼저 문서를 업로드해주세요."
            )
            return
        
        # RAG 컨텍스트 검색
        self.main_window.status_bar.showMessage("🔍 관련 가이드 검색 중...")
        rag_context = self.rag_system.get_context_for_query(
            f"코드 개선 가이드: {current_code[:200]}",
            max_tokens=2000
        )
        
        # 컨텍스트 표시
        self.context_viewer.setPlainText(rag_context)
        
        # 워커 시작
        self.generate_button.setEnabled(False)
        self.improve_button.setEnabled(False)
        
        model = self.main_window.model_combo.currentText()
        
        self.worker = RAGCodingWorker(
            code=current_code,
            prompt="참고 문서의 가이드라인에 따라 이 코드를 개선해주세요. 코드 품질, 구조, 주석을 개선하고 베스트 프랙티스를 적용하세요.",
            rag_context=rag_context,
            model=model
        )
        self.worker.finished.connect(self.on_code_generated)
        self.worker.error.connect(self.on_error)
        self.worker.progress.connect(self.on_progress)
        self.worker.start()
    
    def on_code_generated(self, code: str):
        """코드 생성 완료"""
        self.editor.setPlainText(code)
        self.generate_button.setEnabled(True)
        self.improve_button.setEnabled(True)
        self.main_window.status_bar.showMessage("✓ RAG 기반 코드 생성 완료")
    
    def on_error(self, error_msg: str):
        """에러 발생"""
        self.generate_button.setEnabled(True)
        self.improve_button.setEnabled(True)
        self.main_window.status_bar.showMessage(f"❌ {error_msg}")
        QMessageBox.critical(self, "오류", error_msg)
    
    def on_progress(self, message: str):
        """진행 상황"""
        self.main_window.status_bar.showMessage(f"🤖 {message}")


class VibecodingPanel(QWidget):
    """바이브 코딩 패널"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_window = parent
        self.current_file = None
        self.init_ui()
    
    def init_ui(self):
        """UI 초기화"""
        layout = QVBoxLayout(self)
        
        # 상단: 프롬프트 입력
        prompt_layout = QVBoxLayout()
        prompt_label = QLabel("프로젝트 생성 프롬프트:")
        self.prompt_input = QTextEdit()
        self.prompt_input.setMaximumHeight(100)
        self.prompt_input.setPlaceholderText(
            "예: Flask로 간단한 TODO 앱을 만들어주세요. SQLite 데이터베이스를 사용하고, "
            "RESTful API와 간단한 HTML 프론트엔드를 포함해주세요."
        )
        
        generate_btn = QPushButton("🚀 프로젝트 생성")
        generate_btn.setStyleSheet("""
            QPushButton {
                background-color: #6f42c1;
                color: white;
                padding: 10px;
                font-size: 14px;
                border: none;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #5a32a3;
            }
        """)
        generate_btn.clicked.connect(self.generate_project)
        
        prompt_layout.addWidget(prompt_label)
        prompt_layout.addWidget(self.prompt_input)
        prompt_layout.addWidget(generate_btn)
        
        layout.addLayout(prompt_layout)
        
        # 중단: 스플리터
        splitter = QSplitter(Qt.Orientation.Horizontal)
        
        # 왼쪽: 파일 트리
        self.file_tree = FileTreeWidget()
        self.file_tree.file_selected.connect(self.load_file)
        self.file_tree.setMaximumWidth(250)
        
        # 오른쪽: 에디터
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        
        self.file_label = QLabel("파일을 선택하세요")
        self.file_label.setStyleSheet("font-weight: bold; font-size: 12pt;")
        
        self.editor = CodeEditor()
        
        # 버튼
        button_layout = QHBoxLayout()
        
        save_btn = QPushButton("💾 파일 저장")
        save_btn.clicked.connect(self.save_file)
        
        improve_btn = QPushButton("✨ 이 파일 개선")
        improve_btn.clicked.connect(self.improve_current_file)
        
        export_btn = QPushButton("📦 전체 프로젝트 내보내기")
        export_btn.clicked.connect(self.export_project)
        
        button_layout.addWidget(save_btn)
        button_layout.addWidget(improve_btn)
        button_layout.addWidget(export_btn)
        
        right_layout.addWidget(self.file_label)
        right_layout.addWidget(self.editor)
        right_layout.addLayout(button_layout)
        
        splitter.addWidget(self.file_tree)
        splitter.addWidget(right_widget)
        splitter.setSizes([250, 750])
        
        layout.addWidget(splitter)
    
    def generate_project(self):
        """프로젝트 생성"""
        prompt = self.prompt_input.toPlainText().strip()
        
        if not prompt:
            QMessageBox.warning(self, "경고", "프롬프트를 입력해주세요.")
            return
        
        self.setEnabled(False)
        self.main_window.status_bar.showMessage("🚀 프로젝트 생성 중...")
        
        model = self.main_window.model_combo.currentText()
        self.worker = VibeCodingWorker(prompt, model)
        self.worker.finished.connect(self.on_project_generated)
        self.worker.error.connect(self.on_error)
        self.worker.progress.connect(self.on_progress)
        self.worker.start()
    
    def on_project_generated(self, files: Dict[str, str]):
        """프로젝트 생성 완료"""
        self.file_tree.load_files(files)
        self.setEnabled(True)
        self.main_window.status_bar.showMessage(f"✓ {len(files)}개 파일 생성 완료")
        
        QMessageBox.information(
            self,
            "성공",
            f"프로젝트가 생성되었습니다!\n\n생성된 파일: {len(files)}개\n"
            f"파일 목록: {', '.join(files.keys())}"
        )
    
    def on_error(self, error_msg: str):
        """에러 발생"""
        self.setEnabled(True)
        self.main_window.status_bar.showMessage(f"❌ {error_msg}")
        QMessageBox.critical(self, "오류", error_msg)
    
    def on_progress(self, message: str):
        """진행 상황"""
        self.main_window.status_bar.showMessage(f"🚀 {message}")
    
    def load_file(self, filename: str):
        """파일 로드"""
        self.current_file = filename
        content = self.file_tree.get_file_content(filename)
        self.editor.setPlainText(content)
        self.file_label.setText(f"📄 {filename}")
    
    def save_file(self):
        """현재 파일 저장"""
        if not self.current_file:
            QMessageBox.warning(self, "경고", "선택된 파일이 없습니다.")
            return
        
        content = self.editor.toPlainText()
        self.file_tree.update_file_content(self.current_file, content)
        self.main_window.status_bar.showMessage(f"💾 {self.current_file} 저장됨")
    
    def improve_current_file(self):
        """현재 파일 개선"""
        if not self.current_file:
            QMessageBox.warning(self, "경고", "선택된 파일이 없습니다.")
            return
        
        code = self.editor.toPlainText()
        
        if not code.strip():
            QMessageBox.warning(self, "경고", "파일이 비어있습니다.")
            return
        
        self.main_window.improve_vibe_file(self.current_file, code)
    
    def export_project(self):
        """전체 프로젝트 내보내기"""
        if not self.file_tree.files_data:
            QMessageBox.warning(self, "경고", "생성된 프로젝트가 없습니다.")
            return
        
        directory = QFileDialog.getExistingDirectory(
            self,
            "프로젝트를 저장할 디렉토리 선택",
            str(Path.home())
        )
        
        if not directory:
            return
        
        try:
            for filename, content in self.file_tree.files_data.items():
                file_path = Path(directory) / filename
                file_path.parent.mkdir(parents=True, exist_ok=True)
                file_path.write_text(content, encoding='utf-8')
            
            QMessageBox.information(
                self,
                "성공",
                f"프로젝트가 저장되었습니다!\n\n위치: {directory}\n파일: {len(self.file_tree.files_data)}개"
            )
            self.main_window.status_bar.showMessage(f"✓ 프로젝트가 {directory}에 저장됨")
            
        except Exception as e:
            QMessageBox.critical(self, "오류", f"저장 중 오류 발생:\n{str(e)}")


class MainWindow(QMainWindow):
    """메인 윈도우"""
    
    def __init__(self):
        super().__init__()
        self.suggested_code = None
        self.original_code = None
        self.worker = None
        self.token_counter = TokenCounter()
        self.code_analyzer = CodeAnalyzer()
        self.chat_history = []  # 대화 히스토리
        self.init_ui()
    
    def init_ui(self):
        """UI 초기화"""
        self.setWindowTitle("AI Code Editor - Standard & Vibe & RAG Mode")
        self.setGeometry(100, 100, 1400, 850)
        
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QVBoxLayout(central_widget)
        
        # 탭 위젯
        self.tab_widget = QTabWidget()
        
        # 탭 1: 일반 코딩
        self.standard_tab = self.create_standard_tab()
        self.tab_widget.addTab(self.standard_tab, "📝 일반 코딩")
        
        # 탭 2: 바이브 코딩
        self.vibe_panel = VibecodingPanel(self)
        self.tab_widget.addTab(self.vibe_panel, "🚀 바이브 코딩")
        
        # 탭 3: RAG 기반 코딩
        self.rag_panel = RAGPanel(self)
        self.tab_widget.addTab(self.rag_panel, "📚 RAG 코딩")
        
        main_layout.addWidget(self.tab_widget)
        
        # 상태바
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("준비")
    
    def create_standard_tab(self) -> QWidget:
        """일반 코딩 탭 생성"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # 툴바
        toolbar_layout = QHBoxLayout()
        
        mode_label = QLabel("처리 모드:")
        self.mode_combo = QComboBox()
        self.mode_combo.addItems([
            "선택 영역 (선택한 부분만)",
            "현재 함수/클래스",
            "전체 파일",
            "스마트 컨텍스트 (커서 주변)"
        ])
        self.mode_combo.setCurrentIndex(1)
        
        model_label = QLabel("모델:")
        self.model_combo = QComboBox()
        self.model_combo.addItems([
            "qwen3:8b"
        ])
        
        toolbar_layout.addWidget(mode_label)
        toolbar_layout.addWidget(self.mode_combo)
        toolbar_layout.addWidget(model_label)
        toolbar_layout.addWidget(self.model_combo)
        toolbar_layout.addStretch()
        
        layout.addLayout(toolbar_layout)
        
        # 스플리터
        splitter = QSplitter(Qt.Orientation.Horizontal)
        
        # 에디터
        self.editor = CodeEditor()
        sample_code = '''# 여기에 Python 코드를 작성하세요
import math

def calculate_area(radius):
    """원의 넓이를 계산합니다."""
    return 3.14 * radius * radius

class Circle:
    def __init__(self, radius):
        self.radius = radius
    
    def area(self):
        return calculate_area(self.radius)
'''
        self.editor.setPlainText(sample_code)
        
        # Diff 패널
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        
        # 탭으로 Diff와 대화 히스토리 구분
        right_tabs = QTabWidget()
        
        # Diff 탭
        diff_tab = QWidget()
        diff_tab_layout = QVBoxLayout(diff_tab)
        
        self.info_label = QLabel("수정 제안:")
        diff_tab_layout.addWidget(self.info_label)
        
        self.diff_viewer = DiffViewer()
        diff_tab_layout.addWidget(self.diff_viewer)
        
        right_tabs.addTab(diff_tab, "📝 Diff")
        
        # 대화 히스토리 탭
        chat_tab = QWidget()
        chat_tab_layout = QVBoxLayout(chat_tab)
        
        self.chat_history_viewer = QTextEdit()
        self.chat_history_viewer.setReadOnly(True)
        self.chat_history_viewer.setPlaceholderText("대화 내역이 여기에 표시됩니다...")
        chat_tab_layout.addWidget(self.chat_history_viewer)
        
        # 대화 히스토리 초기화 버튼
        clear_chat_btn = QPushButton("🗑️ 대화 초기화")
        clear_chat_btn.clicked.connect(self.clear_chat_history)
        chat_tab_layout.addWidget(clear_chat_btn)
        
        right_tabs.addTab(chat_tab, "💬 대화")
        
        right_layout.addWidget(right_tabs)
        
        # 프롬프트 입력 (대화 모드)
        prompt_layout = QVBoxLayout()
        prompt_layout.addWidget(QLabel("AI와 대화 (코드 수정 요청):"))
        
        self.standard_prompt_input = QTextEdit()
        self.standard_prompt_input.setMaximumHeight(60)
        self.standard_prompt_input.setPlaceholderText("예: 이 함수에 에러 처리를 추가해주세요")
        prompt_layout.addWidget(self.standard_prompt_input)
        
        right_layout.addLayout(prompt_layout)
        
        # 버튼
        button_layout = QHBoxLayout()
        
        self.suggest_button = QPushButton("🤖 자동 개선 (Ctrl+Space)")
        self.suggest_button.setStyleSheet("""
            QPushButton {
                background-color: #007bff;
                color: white;
                padding: 10px;
                font-size: 14px;
                border: none;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #0056b3;
            }
        """)
        self.suggest_button.clicked.connect(self.request_suggestion)
        
        self.chat_button = QPushButton("💬 대화로 수정 (Ctrl+Enter)")
        self.chat_button.setStyleSheet("""
            QPushButton {
                background-color: #17a2b8;
                color: white;
                padding: 10px;
                font-size: 14px;
                border: none;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #138496;
            }
        """)
        self.chat_button.clicked.connect(self.request_chat_modification)
        
        self.accept_button = QPushButton("✓ Accept (Tab)")
        self.accept_button.setStyleSheet("""
            QPushButton {
                background-color: #28a745;
                color: white;
                padding: 10px;
                font-size: 14px;
                border: none;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #218838;
            }
            QPushButton:disabled {
                background-color: #cccccc;
            }
        """)
        self.accept_button.clicked.connect(self.accept_suggestion)
        self.accept_button.setEnabled(False)
        
        self.reject_button = QPushButton("✗ Reject (Esc)")
        self.reject_button.setStyleSheet("""
            QPushButton {
                background-color: #dc3545;
                color: white;
                padding: 10px;
                font-size: 14px;
                border: none;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #c82333;
            }
            QPushButton:disabled {
                background-color: #cccccc;
            }
        """)
        self.reject_button.clicked.connect(self.reject_suggestion)
        self.reject_button.setEnabled(False)
        
        button_layout.addWidget(self.suggest_button)
        button_layout.addWidget(self.chat_button)
        button_layout.addWidget(self.accept_button)
        button_layout.addWidget(self.reject_button)
        
        right_layout.addLayout(button_layout)
        
        splitter.addWidget(self.editor)
        splitter.addWidget(right_panel)
        splitter.setSizes([700, 700])
        
        layout.addWidget(splitter)
        
        self.setup_shortcuts()
        
        return tab
    
    def setup_shortcuts(self):
        """키보드 단축키"""
        from PySide6.QtGui import QShortcut, QKeySequence
        
        suggest_shortcut = QShortcut(QKeySequence("Ctrl+Space"), self)
        suggest_shortcut.activated.connect(self.request_suggestion)
        
        chat_shortcut = QShortcut(QKeySequence("Ctrl+Return"), self)
        chat_shortcut.activated.connect(self.request_chat_modification)
        
        accept_shortcut = QShortcut(QKeySequence(Qt.Key.Key_Tab), self)
        accept_shortcut.activated.connect(self.accept_if_enabled)
        
        reject_shortcut = QShortcut(QKeySequence(Qt.Key.Key_Escape), self)
        reject_shortcut.activated.connect(self.reject_suggestion)
    
    def accept_if_enabled(self):
        if self.accept_button.isEnabled():
            self.accept_suggestion()
    
    def get_code_to_process(self) -> Tuple[Optional[str], str]:
        """처리할 코드 추출"""
        mode = self.mode_combo.currentText()
        full_code = self.editor.toPlainText()
        
        cursor = self.editor.textCursor()
        if cursor.hasSelection():
            selected = cursor.selectedText()
            token_ok, token_count = self.token_counter.check_limit(selected, max_tokens=3000)
            
            if not token_ok:
                return None, f"선택한 코드가 너무 깁니다. (토큰: {token_count}/3000)"
            
            return selected, f"선택 영역 처리 중 (토큰: {token_count})"
        
        if "현재 함수" in mode:
            cursor_line = self.editor.get_current_line()
            context = self.code_analyzer.get_smart_context(full_code, cursor_line)
            
            if context:
                token_ok, token_count = self.token_counter.check_limit(context, max_tokens=3000)
                
                if not token_ok:
                    return None, f"현재 함수/클래스가 너무 깁니다. (토큰: {token_count}/3000)"
                
                return context, f"현재 함수/클래스 처리 중 (토큰: {token_count})"
            else:
                return None, "현재 커서 위치에서 함수/클래스를 찾을 수 없습니다."
        
        elif "스마트 컨텍스트" in mode:
            cursor_line = self.editor.get_current_line()
            context = self.code_analyzer.get_smart_context(full_code, cursor_line, max_lines=50)
            
            token_ok, token_count = self.token_counter.check_limit(context, max_tokens=3000)
            
            if not token_ok:
                return None, f"컨텍스트가 너무 깁니다. (토큰: {token_count}/3000)"
            
            return context, f"스마트 컨텍스트 처리 중 (토큰: {token_count})"
        
        elif "전체 파일" in mode:
            token_ok, token_count = self.token_counter.check_limit(full_code, max_tokens=6000)
            
            if not token_ok:
                return None, f"전체 파일이 너무 깁니다. (토큰: {token_count}/6000)\n다른 모드를 선택하거나 파일을 나눠주세요."
            
            return full_code, f"전체 파일 처리 중 (토큰: {token_count})"
        
        return None, "처리할 코드를 선택하거나 모드를 변경해주세요."
    
    def request_suggestion(self):
        """코드 개선 제안 요청"""
        if self.tab_widget.currentWidget() != self.standard_tab:
            return
        
        code_to_process, message = self.get_code_to_process()
        
        if not code_to_process:
            QMessageBox.warning(self, "경고", message)
            return
        
        self.original_code = code_to_process
        
        self.suggest_button.setEnabled(False)
        self.accept_button.setEnabled(False)
        self.reject_button.setEnabled(False)
        
        self.status_bar.showMessage(f"🤖 {message}")
        self.info_label.setText(f"수정 제안: {message}")
        
        selected_model = self.model_combo.currentText()
        
        self.worker = OllamaWorker(
            code=code_to_process,
            prompt="이 코드를 개선해주세요. 더 나은 구조, 명확한 변수명, 적절한 주석을 추가하고, Python 베스트 프랙티스를 따라주세요.",
            model=selected_model,
            timeout=120
        )
        self.worker.finished.connect(self.on_suggestion_received)
        self.worker.error.connect(self.on_error)
        self.worker.progress.connect(self.on_progress)
        self.worker.start()
    
    def improve_vibe_file(self, filename: str, code: str):
        """바이브 코딩 파일 개선"""
        self.original_code = code
        self.vibe_improving_file = filename
        
        self.status_bar.showMessage(f"🤖 {filename} 개선 중...")
        
        selected_model = self.model_combo.currentText()
        
        self.worker = OllamaWorker(
            code=code,
            prompt=f"이 파일({filename})을 개선해주세요. 코드 품질을 높이고, 더 나은 구조와 주석을 추가해주세요.",
            model=selected_model,
            timeout=120
        )
        self.worker.finished.connect(self.on_vibe_file_improved)
        self.worker.error.connect(self.on_error)
        self.worker.progress.connect(self.on_progress)
        self.worker.start()
    
    def on_vibe_file_improved(self, improved_code: str):
        """바이브 파일 개선 완료"""
        filename = getattr(self, 'vibe_improving_file', None)
        
        if not filename:
            return
        
        self.vibe_panel.editor.setPlainText(improved_code)
        self.vibe_panel.file_tree.update_file_content(filename, improved_code)
        
        self.status_bar.showMessage(f"✓ {filename} 개선 완료")
        
        QMessageBox.information(
            self,
            "완료",
            f"{filename} 파일이 개선되었습니다!"
        )
    
    def on_progress(self, message):
        """진행 상황"""
        self.status_bar.showMessage(f"🤖 {message}")
    
    def on_suggestion_received(self, suggested_code):
        """제안 받음 (자동 개선 모드)"""
        self.suggested_code = suggested_code
        
        self.diff_viewer.show_diff(self.original_code, suggested_code)
        
        self.suggest_button.setEnabled(True)
        self.chat_button.setEnabled(True)
        self.accept_button.setEnabled(True)
        self.reject_button.setEnabled(True)
        
        _, original_tokens = self.token_counter.check_limit(self.original_code)
        _, suggested_tokens = self.token_counter.check_limit(suggested_code)
        
        self.status_bar.showMessage(
            f"✓ 제안 완료 | 원본: {original_tokens} 토큰 → 수정본: {suggested_tokens} 토큰 | "
            f"Accept(Tab) 또는 Reject(Esc)"
        )
    
    def on_chat_suggestion_received(self, suggested_code):
        """제안 받음 (대화 모드)"""
        # AI 응답을 히스토리에 추가
        self.chat_history.append({
            'role': 'assistant',
            'content': f"코드 수정 완료 ({len(suggested_code)} 자)"
        })
        self.update_chat_history_display()
        
        # 기본 제안 받음 처리
        self.on_suggestion_received(suggested_code)
    
    def on_error(self, error_message):
        """에러 발생"""
        self.status_bar.showMessage(f"❌ 오류: {error_message}")
        self.suggest_button.setEnabled(True)
        self.chat_button.setEnabled(True)
        QMessageBox.critical(self, "오류", error_message)
    
    def accept_suggestion(self):
        """제안 수락"""
        if not self.suggested_code or not self.accept_button.isEnabled():
            return
        
        cursor = self.editor.textCursor()
        if cursor.hasSelection():
            cursor.insertText(self.suggested_code)
            self.status_bar.showMessage("✓ 선택 영역이 수정되었습니다.")
        else:
            mode = self.mode_combo.currentText()
            
            if "전체 파일" in mode:
                self.editor.setPlainText(self.suggested_code)
                self.status_bar.showMessage("✓ 전체 파일이 수정되었습니다.")
            else:
                self._apply_partial_change()
        
        self.clear_suggestion()
    
    def _apply_partial_change(self):
        """부분 변경"""
        full_code = self.editor.toPlainText()
        
        if self.original_code in full_code:
            new_code = full_code.replace(self.original_code, self.suggested_code, 1)
            self.editor.setPlainText(new_code)
            self.status_bar.showMessage("✓ 코드가 부분 수정되었습니다.")
        else:
            self.editor.setPlainText(self.suggested_code)
            self.status_bar.showMessage("✓ 코드가 수정되었습니다.")
    
    def reject_suggestion(self):
        """제안 거부"""
        if self.reject_button.isEnabled():
            self.status_bar.showMessage("제안이 거부되었습니다.")
            self.clear_suggestion()
    
    def clear_suggestion(self):
        """제안 초기화"""
        self.suggested_code = None
        self.original_code = None
        self.diff_viewer.clear()
        self.accept_button.setEnabled(False)
        self.reject_button.setEnabled(False)
        self.info_label.setText("수정 제안:")
    
    def request_chat_modification(self):
        """대화로 코드 수정 요청"""
        if self.tab_widget.currentWidget() != self.standard_tab:
            return
        
        prompt = self.standard_prompt_input.toPlainText().strip()
        
        if not prompt:
            QMessageBox.warning(self, "경고", "수정 요청을 입력해주세요.")
            return
        
        code_to_process, message = self.get_code_to_process()
        
        if not code_to_process:
            QMessageBox.warning(self, "경고", message)
            return
        
        # 대화 히스토리에 추가
        self.chat_history.append({
            'role': 'user',
            'content': prompt
        })
        self.update_chat_history_display()
        
        self.original_code = code_to_process
        
        self.suggest_button.setEnabled(False)
        self.chat_button.setEnabled(False)
        self.accept_button.setEnabled(False)
        self.reject_button.setEnabled(False)
        
        self.status_bar.showMessage(f"💬 대화로 수정 중... {message}")
        self.info_label.setText(f"대화 수정: {message}")
        
        selected_model = self.model_combo.currentText()
        
        # 대화 히스토리를 포함한 프롬프트 구성
        conversation = ""
        for msg in self.chat_history[:-1]:  # 현재 프롬프트 제외
            role = msg.get('role', 'user')
            content = msg.get('content', '')
            if role == 'user':
                conversation += f"사용자: {content}\n"
            else:
                conversation += f"AI: {content}\n"
        
        full_prompt = f"""당신은 코드 작성 전문가입니다.
사용자와 대화하면서 코드를 개선하거나 수정합니다.

{conversation}
사용자: {prompt}

응답은 수정된 코드만 출력하세요 (설명 없이)."""
        
        self.worker = OllamaWorker(
            code=code_to_process,
            prompt=full_prompt,
            model=selected_model,
            timeout=120
        )
        self.worker.finished.connect(self.on_chat_suggestion_received)
        self.worker.error.connect(self.on_error)
        self.worker.progress.connect(self.on_progress)
        self.worker.start()
        
        # 프롬프트 입력 초기화
        self.standard_prompt_input.clear()
    
    def on_chat_suggestion_received(self, suggested_code):
        """제안 받음 (대화 모드)"""
        # AI 응답을 히스토리에 추가
        self.chat_history.append({
            'role': 'assistant',
            'content': f"코드 수정 완료 ({len(suggested_code)} 자)"
        })
        self.update_chat_history_display()
        
        # 기본 제안 받음 처리
        self.on_suggestion_received(suggested_code)
        
        # 대화 버튼 재활성화
        self.chat_button.setEnabled(True)
    
    def clear_chat_history(self):
        """대화 히스토리 초기화"""
        self.chat_history = []
        self.chat_history_viewer.clear()
        self.status_bar.showMessage("✓ 대화 히스토리가 초기화되었습니다.")
    
    def update_chat_history_display(self):
        """대화 히스토리 표시 업데이트"""
        html = "<div style='font-family: Consolas; font-size: 10pt; color: #d4d4d4;'>"
        
        for msg in self.chat_history:
            role = msg.get('role', 'user')
            content = msg.get('content', '')
            
            if role == 'user':
                html += f"<p style='color: #4ec9b0;'><b>사용자:</b> {self._escape_html(content)}</p>"
            else:
                html += f"<p style='color: #569cd6;'><b>AI:</b> {self._escape_html(content)}</p>"
        
        html += "</div>"
        self.chat_history_viewer.setHtml(html)
        
        # 스크롤을 맨 아래로
        scrollbar = self.chat_history_viewer.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())
    
    def _escape_html(self, text):
        """HTML 특수문자 이스케이프"""
        return text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('\n', '<br>')


def main():
    app = QApplication(sys.argv)
    
    # 다크모드 스타일시트 적용
    dark_stylesheet = """
    QMainWindow, QWidget {
        background-color: #1e1e1e;
        color: #d4d4d4;
    }
    
    QTextEdit, QPlainTextEdit, QLineEdit {
        background-color: #252526;
        color: #d4d4d4;
        border: 1px solid #3c3c3c;
        selection-background-color: #264f78;
    }
    
    QListWidget, QTreeWidget {
        background-color: #252526;
        color: #d4d4d4;
        border: 1px solid #3c3c3c;
    }
    
    QListWidget::item:selected, QTreeWidget::item:selected {
        background-color: #094771;
    }
    
    QListWidget::item:hover, QTreeWidget::item:hover {
        background-color: #2a2d2e;
    }
    
    QLabel {
        color: #d4d4d4;
    }
    
    QComboBox {
        background-color: #3c3c3c;
        color: #d4d4d4;
        border: 1px solid #3c3c3c;
        padding: 5px;
    }
    
    QComboBox:hover {
        background-color: #505050;
    }
    
    QComboBox::drop-down {
        border: none;
    }
    
    QComboBox QAbstractItemView {
        background-color: #3c3c3c;
        color: #d4d4d4;
        selection-background-color: #094771;
    }
    
    QPushButton {
        background-color: #0e639c;
        color: white;
        border: none;
        padding: 8px;
        border-radius: 3px;
    }
    
    QPushButton:hover {
        background-color: #1177bb;
    }
    
    QPushButton:pressed {
        background-color: #0d5a8f;
    }
    
    QPushButton:disabled {
        background-color: #3c3c3c;
        color: #6e6e6e;
    }
    
    QStatusBar {
        background-color: #007acc;
        color: white;
    }
    
    QTabWidget::pane {
        border: 1px solid #3c3c3c;
        background-color: #1e1e1e;
    }
    
    QTabBar::tab {
        background-color: #2d2d30;
        color: #d4d4d4;
        padding: 8px 16px;
        border: 1px solid #3c3c3c;
    }
    
    QTabBar::tab:selected {
        background-color: #1e1e1e;
        border-bottom: 2px solid #007acc;
    }
    
    QTabBar::tab:hover {
        background-color: #3e3e42;
    }
    
    QSplitter::handle {
        background-color: #3c3c3c;
    }
    
    QScrollBar:vertical {
        background-color: #1e1e1e;
        width: 14px;
    }
    
    QScrollBar::handle:vertical {
        background-color: #424242;
        border-radius: 7px;
    }
    
    QScrollBar::handle:vertical:hover {
        background-color: #4e4e4e;
    }
    
    QScrollBar:horizontal {
        background-color: #1e1e1e;
        height: 14px;
    }
    
    QScrollBar::handle:horizontal {
        background-color: #424242;
        border-radius: 7px;
    }
    
    QScrollBar::handle:horizontal:hover {
        background-color: #4e4e4e;
    }
    
    QScrollBar::add-line, QScrollBar::sub-line {
        border: none;
        background: none;
    }
    
    QMessageBox {
        background-color: #1e1e1e;
    }
    
    QMessageBox QLabel {
        color: #d4d4d4;
    }
    """
    
    app.setStyleSheet(dark_stylesheet)
    
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
