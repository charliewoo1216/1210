# API 업데이트 문서

## 변경사항 요약

원격 API 서버를 사용하도록 코드를 수정했습니다.

### 1. API 엔드포인트 변경

**이전:**
- LLM: `http://localhost:11434/api/generate`
- 임베딩: 로컬 SentenceTransformer 모델

**변경 후:**
- LLM: `http://121.128.243.214:8000/api/generate`
- 임베딩: `http://121.128.243.214:8000/api/embed`

### 2. API 인증

모든 API 요청에 헤더 추가:
```python
headers = {
    "X-API-Key": "LDfvFBuAzG6P8DM7NFD4u2FGN7BeFSe8d47JqDGwu1I",
    "Content-Type": "application/json"
}
```

### 3. 모델 변경

- LLM 모델: `qwen2.5-coder:7b` → `qwen3:8b`
- 임베딩 모델: `all-MiniLM-L6-v2` (로컬) → `qwen3-embedding:8b` (API)

### 4. 환경 설정

`.env` 파일을 통한 설정 관리:
```
API_URL=121.128.243.214
YOUR_API_KEY=LDfvFBuAzG6P8DM7NFD4u2FGN7BeFSe8d47JqDGwu1I
```

### 5. 수정된 클래스

1. **RAGSystem**
   - `_get_embeddings()` 메서드 추가: API를 통한 임베딩 생성
   - 로컬 SentenceTransformer 제거
   - 임베딩 차원: 384 → 768

2. **RAGCodingWorker**
   - API URL 및 인증 헤더 추가
   - `num_predict` 파라미터 제거

3. **VibeCodingWorker**
   - API URL 및 인증 헤더 추가
   - `num_predict` 파라미터 제거

4. **OllamaWorker**
   - API URL 및 인증 헤더 추가
   - `num_predict` 파라미터 제거
   - 에러 메시지 업데이트

### 6. API 요청 형식

#### LLM 생성
```bash
curl -X POST "http://121.128.243.214:8000/api/generate" \
  -H "X-API-Key: LDfvFBuAzG6P8DM7NFD4u2FGN7BeFSe8d47JqDGwu1I" \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "질문 내용",
    "model": "qwen3:8b",
    "stream": false,
    "temperature": 0.7
  }'
```

#### 임베딩
```bash
curl -X POST "http://121.128.243.214:8000/api/embed" \
  -H "X-API-Key: LDfvFBuAzG6P8DM7NFD4u2FGN7BeFSe8d47JqDGwu1I" \
  -H "Content-Type: application/json" \
  -d '{
    "input": "텍스트 내용",
    "model": "qwen3-embedding:8b"
  }'
```

### 7. 설치 및 실행

```bash
# 의존성 설치
pip install -r requirements.txt

# 환경 설정 (선택사항 - .env 파일이 없으면 기본값 사용)
cp .env.sample .env
# .env 파일 편집 (필요시)

# 실행
python 02-w-vscode.py
```

### 8. 주의사항

- API 키는 보안을 위해 `.env` 파일에 저장하고 버전 관리에서 제외해야 합니다
- `.env.sample` 파일은 예시로 제공되며, 실제 사용시 `.env`로 복사하여 사용하세요
- 네트워크 연결 상태와 API 서버 가용성을 확인하세요
- 임베딩 배치 처리로 대용량 문서 처리 시 시간이 걸릴 수 있습니다
