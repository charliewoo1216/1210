from openai import OpenAI
import os
from dotenv import load_dotenv
from langchain_community.document_loaders import DirectoryLoader, TextLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from pathlib import Path

# .env 파일 로드
load_dotenv()

# OpenAI 클라이언트 초기화
client = OpenAI(
    api_key=os.getenv("OPENAI_API_KEY"),
    base_url=os.getenv("OPENAI_BASE_URL")
)

# 설정
RAG_DOC_PATH = "./rag-doc"
FAISS_STORAGE_PATH = "./faiss-storage"
EMBEDDING_MODEL = "text-embedding-ada-002"


def load_documents():
    """rag-doc 폴더에서 txt, md 파일 로드"""
    print("문서 로딩 중...")
    
    documents = []
    
    # txt 파일 로드
    txt_loader = DirectoryLoader(
        RAG_DOC_PATH,
        glob="**/*.txt",
        loader_cls=TextLoader,
        loader_kwargs={'encoding': 'utf-8'}
    )
    documents.extend(txt_loader.load())
    
    # md 파일 로드
    md_loader = DirectoryLoader(
        RAG_DOC_PATH,
        glob="**/*.md",
        loader_cls=TextLoader,
        loader_kwargs={'encoding': 'utf-8'}
    )
    documents.extend(md_loader.load())
    
    print(f"총 {len(documents)}개의 문서 로드 완료")
    return documents


def create_embeddings(documents):
    """문서를 청크로 분할하고 임베딩 생성"""
    print("문서 분할 중...")
    
    # 텍스트 분할
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200,
        length_function=len,
    )
    chunks = text_splitter.split_documents(documents)
    print(f"총 {len(chunks)}개의 청크 생성")
    
    print("임베딩 생성 중...")
    
    # OpenAI 임베딩 생성 (float 형식)
    embeddings = OpenAIEmbeddings(
        model=EMBEDDING_MODEL,
        openai_api_key=os.getenv("OPENAI_API_KEY"),
        openai_api_base=os.getenv("OPENAI_BASE_URL")
    )
    
    # FAISS 벡터 스토어 생성
    vectorstore = FAISS.from_documents(chunks, embeddings)
    
    print("임베딩 생성 완료")
    return vectorstore


def save_vectorstore(vectorstore):
    """벡터 DB를 파일로 저장"""
    print(f"벡터 DB 저장 중: {FAISS_STORAGE_PATH}")
    
    # 디렉토리 생성
    Path(FAISS_STORAGE_PATH).mkdir(parents=True, exist_ok=True)
    
    # FAISS 저장
    vectorstore.save_local(FAISS_STORAGE_PATH)
    print("벡터 DB 저장 완료")


def load_vectorstore():
    """저장된 벡터 DB 로드"""
    print(f"벡터 DB 로드 중: {FAISS_STORAGE_PATH}")
    
    embeddings = OpenAIEmbeddings(
        model=EMBEDDING_MODEL,
        openai_api_key=os.getenv("OPENAI_API_KEY"),
        openai_api_base=os.getenv("OPENAI_BASE_URL")
    )
    
    vectorstore = FAISS.load_local(
        FAISS_STORAGE_PATH,
        embeddings,
        allow_dangerous_deserialization=True
    )
    print("벡터 DB 로드 완료")
    return vectorstore


def search_similar_documents(vectorstore, query, k=3):
    """유사도 검색 수행"""
    print(f"\n유사도 검색 중: '{query}'")
    
    # 유사 문서 검색
    docs = vectorstore.similarity_search(query, k=k)
    
    print(f"{len(docs)}개의 유사 문서 발견\n")
    return docs


def generate_answer(query, context_docs):
    """검색된 문서를 기반으로 답변 생성"""
    # 컨텍스트 구성
    context = "\n\n".join([doc.page_content for doc in context_docs])
    
    # 프롬프트 생성
    messages = [
        {
            "role": "system",
            "content": "당신은 문서를 기반으로 정확한 답변을 제공하는 AI 어시스턴트입니다. 주어진 문서 내용을 바탕으로 답변하세요."
        },
        {
            "role": "user",
            "content": f"""다음 문서 내용을 참고하여 질문에 답변해주세요.

[참고 문서]
{context}

[질문]
{query}

[답변]"""
        }
    ]
    
    # GPT로 답변 생성
    response = client.chat.completions.create(
        model="gpt-4",
        messages=messages,
        temperature=0.7,
        max_tokens=1000
    )
    
    return response.choices[0].message.content


def initialize_rag():
    """RAG 시스템 초기화 (최초 1회 실행)"""
    print("=" * 50)
    print("RAG 시스템 초기화")
    print("=" * 50)
    
    # 문서 로드
    documents = load_documents()
    
    if not documents:
        print("경고: 로드된 문서가 없습니다!")
        return None
    
    # 임베딩 생성
    vectorstore = create_embeddings(documents)
    
    # 벡터 DB 저장
    save_vectorstore(vectorstore)
    
    return vectorstore


def main():
    """RAG 챗봇 메인 함수"""
    print("=" * 50)
    print("GPT RAG 챗봇")
    print("=" * 50)
    
    # 벡터 DB 확인
    if not Path(FAISS_STORAGE_PATH).exists() or not list(Path(FAISS_STORAGE_PATH).glob("*")):
        print("\n벡터 DB가 존재하지 않습니다. 초기화를 시작합니다...\n")
        vectorstore = initialize_rag()
        if vectorstore is None:
            print("초기화 실패. 프로그램을 종료합니다.")
            return
    else:
        # 기존 벡터 DB 로드
        vectorstore = load_vectorstore()
    
    print("\n" + "=" * 50)
    print("RAG 챗봇 준비 완료!")
    print("명령어:")
    print("  - 질문 입력: 문서 기반 답변 생성")
    print("  - 'reinit': RAG 시스템 재초기화")
    print("  - 'quit', 'exit', 'q': 종료")
    print("=" * 50 + "\n")
    
    while True:
        try:
            # 사용자 입력
            user_input = input("You: ").strip()
            
            if not user_input:
                continue
            
            # 종료 명령
            if user_input.lower() in ['quit', 'exit', 'q']:
                print("챗봇을 종료합니다.")
                break
            
            # 재초기화 명령
            if user_input.lower() == 'reinit':
                vectorstore = initialize_rag()
                if vectorstore is None:
                    print("초기화 실패!")
                continue
            
            # 유사도 검색
            similar_docs = search_similar_documents(vectorstore, user_input, k=3)
            
            if not similar_docs:
                print("\nGPT: 관련 문서를 찾을 수 없습니다.\n")
                continue
            
            # 검색된 문서 출력
            print("[검색된 문서]")
            for i, doc in enumerate(similar_docs, 1):
                source = doc.metadata.get('source', 'Unknown')
                print(f"{i}. {source}: {doc.page_content[:100]}...")
            
            # 답변 생성
            print("\n답변 생성 중...\n")
            answer = generate_answer(user_input, similar_docs)
            
            print(f"GPT: {answer}\n")
            
        except KeyboardInterrupt:
            print("\n\n챗봇을 종료합니다.")
            break
        except Exception as e:
            print(f"\n오류 발생: {e}\n")
            import traceback
            traceback.print_exc()


if __name__ == "__main__":
    main()
