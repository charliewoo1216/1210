from openai import OpenAI
import os
from dotenv import load_dotenv

# .env 파일 로드
load_dotenv()

# OpenAI 클라이언트 초기화
client = OpenAI(
    api_key=os.getenv("OPENAI_API_KEY"),
    base_url=os.getenv("OPENAI_BASE_URL")
)

def chat_with_gpt(messages):
    """GPT와 대화하는 함수"""
    response = client.chat.completions.create(
        model="gpt-4",
        messages=messages,
        temperature=0.7,
        max_tokens=2000
    )
    return response.choices[0].message.content

def main():
    """CLI 챗봇 메인 함수"""
    print("=== GPT CLI 챗봇 ===")
    print("종료하려면 'quit', 'exit', 'q' 입력")
    print("대화 기록 초기화: 'clear', 'reset'\n")
    
    # 대화 기록 저장
    messages = [
        {
            "role": "system",
            "content": "You are a helpful assistant. 한국어로 답변해주세요."
        }
    ]
    
    while True:
        try:
            # 사용자 입력 받기
            user_input = input("You: ").strip()
            
            if not user_input:
                continue
                
            # 종료 명령
            if user_input.lower() in ['quit', 'exit', 'q']:
                print("챗봇을 종료합니다.")
                break
            
            # 대화 기록 초기화
            if user_input.lower() in ['clear', 'reset']:
                messages = [
                    {
                        "role": "system",
                        "content": "You are a helpful assistant. 한국어로 답변해주세요."
                    }
                ]
                print("대화 기록이 초기화되었습니다.\n")
                continue
            
            # 사용자 메시지 추가
            messages.append({
                "role": "user",
                "content": user_input
            })
            
            # GPT 응답 받기
            print("\nGPT: ", end="", flush=True)
            response = chat_with_gpt(messages)
            print(response)
            print()
            
            # 응답을 대화 기록에 추가
            messages.append({
                "role": "assistant",
                "content": response
            })
            
        except KeyboardInterrupt:
            print("\n\n챗봇을 종료합니다.")
            break
        except Exception as e:
            print(f"\n오류 발생: {e}\n")

if __name__ == "__main__":
    main()

 