import streamlit as st

# 페이지 설정
st.set_page_config(
    page_title="Streamlit Demo",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded"
)

# 사이드바 메뉴
st.sidebar.title("📋 메뉴aa")

menu = st.sidebar.radio(
    "네비게이션",
    options=[
        "🏠 홈",
        "📊 데이터",
        "📈 차트",
        "⚙️ 설정",
        "ℹ️ 정보"
    ],
    label_visibility="collapsed"
)

# 메인 콘텐츠
st.title("Streamlit 기본 데모")

if menu == "🏠 홈":
    st.header("홈")
    st.write("Streamlit 데모 애플리케이션에 오신 것을 환영합니다!")
    st.info("좌측 사이드바의 메뉴를 선택하여 다양한 기능을 체험해보세요.")

elif menu == "📊 데이터":
    st.header("데이터")
    st.write("데이터 분석 페이지입니다.")
    
    # 샘플 데이터 표시
    import pandas as pd
    data = {
        "이름": ["Alice", "Bob", "Charlie"],
        "나이": [25, 30, 35],
        "도시": ["서울", "부산", "대구"]
    }
    df = pd.DataFrame(data)
    st.dataframe(df)

elif menu == "📈 차트":
    st.header("차트")
    st.write("차트 시각화 페이지입니다.")
    
    # 샘플 차트
    import pandas as pd
    import numpy as np
    
    chart_data = pd.DataFrame(
        np.random.randn(20, 3),
        columns=["A", "B", "C"]
    )
    st.line_chart(chart_data)

elif menu == "⚙️ 설정":
    st.header("설정")
    st.write("설정 페이지입니다.")
    
    name = st.text_input("이름을 입력하세요:")
    if name:
        st.write(f"안녕하세요, {name}님!")
    
    option = st.selectbox(
        "옵션을 선택하세요:",
        ["옵션 1", "옵션 2", "옵션 3"]
    )
    st.write(f"선택된 옵션: {option}")

elif menu == "ℹ️ 정보":
    st.header("정보")
    st.write("이 애플리케이션은 Streamlit의 기본 기능을 시연합니다.")
    st.markdown("""
    ### 주요 기능
    - 사이드바 메뉴 네비게이션
    - 다양한 페이지 구성
    - 데이터 표시 및 시각화
    - 사용자 입력 처리
    """)

# 사이드바 하단 정보
st.sidebar.divider()
st.sidebar.write("📌 사이드바 정보")
st.sidebar.write("현재 선택된 메뉴: " + menu)
