import streamlit as st
from openai import OpenAI
import json
import os

# 설정 파일 경로
SETTINGS_FILE = "settings.json"

# 기본 설정
DEFAULT_SETTINGS = {
    "api_key": "",
    "model": "gpt-4.1-nano",
    "temperature": 0.7,
    "system_prompt": "당신은 도움이 되는 AI 어시스턴트입니다."
}

# 설정 로드 함수
def load_settings():
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            return DEFAULT_SETTINGS.copy()
    return DEFAULT_SETTINGS.copy()

# 설정 저장 함수
def save_settings(settings):
    with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(settings, f, ensure_ascii=False, indent=2)

# 페이지 설정
st.set_page_config(
    page_title="Streamlit Demo",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded"
)

# 사이드바 메뉴
st.sidebar.title("📋 메뉴aa")

menu = st.sidebar.radio(
    "네비게이션",
    options=[
        "🏠 홈",        
        "🤖 챗봇",
        "⚙️ 설정",
        "ℹ️ 정보"
    ],
    label_visibility="collapsed"
)

# 메인 콘텐츠
st.title("Streamlit 기본 데모")

if menu == "🏠 홈":
    st.header("홈")
    st.write("Streamlit 데모 애플리케이션에 오신 것을 환영합니다!")
    st.info("좌측 사이드바의 메뉴를 선택하여 다양한 기능을 체험해보세요.")


elif menu == "🤖 챗봇":
    st.header("🤖 AI 챗봇")
    
    # 설정 로드
    settings = load_settings()
    api_key = settings.get("api_key", "")
    
    if not api_key:
        st.warning("⚠️ 설정 메뉴에서 OpenAI API 키를 입력해주세요.")
    else:
        try:
            # 클라이언트 초기화
            client = OpenAI(api_key=api_key)
            
            # 세션 상태에 메시지 저장
            if "messages" not in st.session_state:
                st.session_state.messages = [
                    {"role": "system", "content": settings.get("system_prompt", DEFAULT_SETTINGS["system_prompt"])}
                ]
            
            # 채팅 히스토리 표시
            for message in st.session_state.messages:
                if message["role"] != "system":
                    with st.chat_message(message["role"]):
                        st.markdown(message["content"])
            
            # 사용자 입력
            if prompt := st.chat_input("메시지를 입력하세요..."):
                st.session_state.messages.append({"role": "user", "content": prompt})
                
                with st.chat_message("user"):
                    st.markdown(prompt)
                
                # AI 응답 생성
                with st.chat_message("assistant"):
                    with st.spinner("생각 중..."):
                        try:
                            response = client.chat.completions.create(
                                model=settings.get("model", DEFAULT_SETTINGS["model"]),
                                messages=st.session_state.messages,
                                temperature=settings.get("temperature", DEFAULT_SETTINGS["temperature"])
                            )
                            assistant_message = response.choices[0].message.content
                            st.markdown(assistant_message)
                            
                            st.session_state.messages.append({
                                "role": "assistant",
                                "content": assistant_message
                            })
                        except Exception as e:
                            st.error(f"❌ 오류 발생: {str(e)}")
            
            # 대화 초기화 버튼
            if st.sidebar.button("대화 초기화"):
                st.session_state.messages = [
                    {"role": "system", "content": settings.get("system_prompt", DEFAULT_SETTINGS["system_prompt"])}
                ]
                st.rerun()
        except Exception as e:
            st.error(f"❌ API 연결 오류: {str(e)}")


elif menu == "⚙️ 설정":
    st.header("⚙️ 설정")
    
    # 현재 설정 로드
    settings = load_settings()
    
    st.subheader("🔐 OpenAI API 설정")
    
    col1, col2 = st.columns([3, 1])
    with col1:
        api_key = st.text_input(
            "OpenAI API Key",
            value=settings.get("api_key", ""),
            type="password",
            key="api_key_input"
        )
    with col2:
        if st.button("API 키 저장"):
            settings["api_key"] = api_key
            save_settings(settings)
            st.success("✅ API 키가 저장되었습니다.")
    
    st.divider()
    st.subheader("🤖 모델 설정")
    
    model = st.selectbox(
        "모델 선택",
        options=["gpt-4.1-nano", "gpt-4", "gpt-3.5-turbo"],
        index=0 if settings.get("model") == "gpt-4.1-nano" else 1,
        key="model_select"
    )
    
    temperature = st.slider(
        "Temperature (창의성 조정)",
        min_value=0.0,
        max_value=2.0,
        value=settings.get("temperature", 0.7),
        step=0.1,
        help="0에 가까울수록 일관성 있고, 높을수록 창의적인 응답"
    )
    
    st.divider()
    st.subheader("📝 시스템 프롬프트")
    
    system_prompt = st.text_area(
        "시스템 프롬프트",
        value=settings.get("system_prompt", DEFAULT_SETTINGS["system_prompt"]),
        height=100,
        help="AI의 역할과 행동 방식을 정의합니다"
    )
    
    # 설정 저장 버튼
    col1, col2, col3 = st.columns(3)
    with col1:
        if st.button("설정 저장", type="primary", use_container_width=True):
            settings["model"] = model
            settings["temperature"] = temperature
            settings["system_prompt"] = system_prompt
            save_settings(settings)
            st.success("✅ 모든 설정이 저장되었습니다.")
            st.rerun()
    
    with col2:
        if st.button("기본값 초기화", use_container_width=True):
            save_settings(DEFAULT_SETTINGS.copy())
            st.info("🔄 기본값으로 초기화되었습니다.")
            st.rerun()
    
    with col3:
        if st.button("설정 보기", use_container_width=True):
            st.json(settings)
    
    st.divider()
    st.subheader("📋 현재 설정 요약")
    
    summary_col1, summary_col2 = st.columns(2)
    with summary_col1:
        st.metric("모델", settings.get("model", "미설정"))
        st.metric("Temperature", f"{settings.get('temperature', 0.7):.1f}")
    with summary_col2:
        has_api_key = "✅ 설정됨" if settings.get("api_key") else "❌ 미설정"
        st.metric("API 키 상태", has_api_key)
        st.metric("프롬프트", "설정됨" if settings.get("system_prompt") else "기본값")


elif menu == "ℹ️ 정보":
    st.header("정보")
    st.write("이 애플리케이션은 Streamlit의 기본 기능을 시연합니다.")
    st.markdown("""
    ### 주요 기능
    - 사이드바 메뉴 네비게이션
    - 다양한 페이지 구성
    - 데이터 표시 및 시각화
    - 사용자 입력 처리
    """)

# 사이드바 하단 정보
st.sidebar.divider()
st.sidebar.write("📌 사이드바 정보")
st.sidebar.write("현재 선택된 메뉴: " + menu)
