import streamlit as st
from openai import OpenAI

# 페이지 설정
st.set_page_config(
    page_title="Streamlit Demo",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded"
)

# 사이드바 메뉴
st.sidebar.title("📋 메뉴aa")

menu = st.sidebar.radio(
    "네비게이션",
    options=[
        "🏠 홈",
        "📊 데이터",
        "📈 차트",
        "🤖 챗봇",
        "⚙️ 설정",
        "ℹ️ 정보"
    ],
    label_visibility="collapsed"
)

# 메인 콘텐츠
st.title("Streamlit 기본 데모")

if menu == "🏠 홈":
    st.header("홈")
    st.write("Streamlit 데모 애플리케이션에 오신 것을 환영합니다!")
    st.info("좌측 사이드바의 메뉴를 선택하여 다양한 기능을 체험해보세요.")

elif menu == "📊 데이터":
    st.header("데이터")
    st.write("데이터 분석 페이지입니다.")
    
    # 샘플 데이터 표시
    import pandas as pd
    data = {
        "이름": ["Alice", "Bob", "Charlie"],
        "나이": [25, 30, 35],
        "도시": ["서울", "부산", "대구"]
    }
    df = pd.DataFrame(data)
    st.dataframe(df)

elif menu == "📈 차트":
    st.header("차트")
    st.write("차트 시각화 페이지입니다.")
    
    # 샘플 차트
    import pandas as pd
    import numpy as np
    
    chart_data = pd.DataFrame(
        np.random.randn(20, 3),
        columns=["A", "B", "C"]
    )
    st.line_chart(chart_data)

elif menu == "🤖 챗봇":
    st.header("🤖 AI 챗봇")
    
    # API 키 입력
    api_key = st.sidebar.text_input("OpenAI API Key", type="password")
    
    if not api_key:
        st.warning("⚠️ 좌측 사이드바에서 OpenAI API 키를 입력해주세요.")
    else:
        # 클라이언트 초기화
        client = OpenAI(api_key=api_key)
        
        # 세션 상태에 메시지 저장
        if "messages" not in st.session_state:
            st.session_state.messages = []
        
        # 채팅 히스토리 표시
        for message in st.session_state.messages:
            with st.chat_message(message["role"]):
                st.markdown(message["content"])
        
        # 사용자 입력
        if prompt := st.chat_input("메시지를 입력하세요..."):
            st.session_state.messages.append({"role": "user", "content": prompt})
            
            with st.chat_message("user"):
                st.markdown(prompt)
            
            # AI 응답 생성
            with st.chat_message("assistant"):
                with st.spinner("생각 중..."):
                    try:
                        response = client.chat.completions.create(
                            model="gpt-4.1-nano",
                            messages=st.session_state.messages,
                            temperature=0.5
                        )
                        assistant_message = response.choices[0].message.content
                        st.markdown(assistant_message)
                        
                        st.session_state.messages.append({
                            "role": "assistant",
                            "content": assistant_message
                        })
                    except Exception as e:
                        st.error(f"❌ 오류 발생: {str(e)}")
        
        # 대화 초기화 버튼
        if st.sidebar.button("대화 초기화"):
            st.session_state.messages = []
            st.rerun()

elif menu == "⚙️ 설정":
    st.header("설정")
    st.write("설정 페이지입니다.")
    
    name = st.text_input("이름을 입력하세요:")
    if name:
        st.write(f"안녕하세요, {name}님!")
    
    option = st.selectbox(
        "옵션을 선택하세요:",
        ["옵션 1", "옵션 2", "옵션 3"]
    )
    st.write(f"선택된 옵션: {option}")

elif menu == "ℹ️ 정보":
    st.header("정보")
    st.write("이 애플리케이션은 Streamlit의 기본 기능을 시연합니다.")
    st.markdown("""
    ### 주요 기능
    - 사이드바 메뉴 네비게이션
    - 다양한 페이지 구성
    - 데이터 표시 및 시각화
    - 사용자 입력 처리
    """)

# 사이드바 하단 정보
st.sidebar.divider()
st.sidebar.write("📌 사이드바 정보")
st.sidebar.write("현재 선택된 메뉴: " + menu)
