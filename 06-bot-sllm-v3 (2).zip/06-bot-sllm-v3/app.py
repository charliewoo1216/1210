"""
로그 파일 분석 챗봇
- Streamlit UI
- Ollama API (Qwen3 모델)
- FAISS 벡터 DB
- RAG 기반 질의응답
"""

import streamlit as st
import json
import os
import hashlib
import re
from datetime import datetime
import requests
import faiss
import numpy as np
import pickle

# ============================================
# 1. 설정 및 상수
# API_URL = "http://121.128.243.214:8000"
# ============================================

CONFIG_FILE = "log_config.json"
VECTOR_STORE_PATH = "log_vector_store"
DEFAULT_CONFIG = {
    "ollama_api_url": "http://ㅁㅁ:8000",
    "ollama_api_key": "ㅁㅁ",
    "llm_model": "qwen3:8b",
    "embedding_model": "qwen3-embedding:8b",
    "rerank_model": "dengcao/Qwen3-Reranker-8B:Q8_0",
    "temperature": 0.7,
    "max_search_results": 5,
    "chunk_size": 5,
    "use_rerank": False
}

# ============================================
# 2. VectorDB 클래스
# ============================================

class LogVectorDB:
    """로그 분석용 벡터 DB"""
    
    def __init__(self, db_path=VECTOR_STORE_PATH, dim=4096):
        self.db_path = db_path
        self.dim = dim
        os.makedirs(db_path, exist_ok=True)
        
        self.index_file = os.path.join(db_path, "index.faiss")
        self.meta_file = os.path.join(db_path, "meta.pkl")
        
        if os.path.exists(self.index_file) and os.path.exists(self.meta_file):
            try:
                self.index = faiss.read_index(self.index_file)
                with open(self.meta_file, "rb") as f:
                    self.meta = pickle.load(f)
            except Exception as e:
                st.warning(f"VectorDB 로드 실패: {e}. 새로운 DB 생성")
                self.index = faiss.IndexFlatL2(self.dim)
                self.meta = []
        else:
            self.index = faiss.IndexFlatL2(self.dim)
            self.meta = []
    
    def add(self, embedding: np.ndarray, text: str):
        """임베딩 추가"""
        self.index.add(np.array([embedding]).astype("float32"))
        self.meta.append(text)
    
    def save(self):
        """DB 저장"""
        faiss.write_index(self.index, self.index_file)
        with open(self.meta_file, "wb") as f:
            pickle.dump(self.meta, f)
    
    def search(self, query_embedding, k=5):
        """검색"""
        if self.index.ntotal == 0:
            return []
        
        k = min(k, self.index.ntotal)
        D, I = self.index.search(np.array([query_embedding]).astype("float32"), k)
        return [(self.meta[i], float(D[0][idx])) for idx, i in enumerate(I[0]) if i < len(self.meta)]
    
    def clear(self):
        """DB 초기화"""
        self.index = faiss.IndexFlatL2(self.dim)
        self.meta = []
        self.save()
    
    def get_size(self):
        """저장된 벡터 개수"""
        return self.index.ntotal


# ============================================
# 3. 유틸리티 함수
# ============================================

def load_config():
    """설정 로드"""
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return DEFAULT_CONFIG.copy()

def save_config(cfg):
    """설정 저장"""
    try:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=4, ensure_ascii=False)
    except Exception as e:
        st.error(f"설정 저장 실패: {e}")

def get_file_hash(content):
    """파일 해시값"""
    return hashlib.md5(content).hexdigest()

def parse_log_lines(text: str) -> list:
    """로그 텍스트를 의미 있는 라인으로 파싱"""
    lines = text.strip().split("\n")
    return [line.strip() for line in lines if line.strip()]

def chunk_log_lines(lines: list, chunk_size: int = 5) -> list:
    """로그 라인을 그룹으로 묶기 (연관된 로그들을 함께 임베딩)"""
    chunks = []
    for i in range(0, len(lines), chunk_size):
        chunk = "\n".join(lines[i:i+chunk_size])
        if chunk.strip():
            chunks.append(chunk)
    return chunks

def embed_texts(api_url: str, api_key: str, texts: list, model: str = "qwen3-embedding:8b") -> list:
    """텍스트 임베딩 (Ollama API)"""
    if not texts or not api_key:
        raise ValueError("텍스트와 API 키 필요")
    
    texts = [t.strip() for t in texts if t.strip()]
    if not texts:
        raise ValueError("유효한 텍스트 없음")
    
    try:
        headers = {
            "X-API-Key": api_key,
            "Content-Type": "application/json"
        }
        
        embeddings = []
        for text in texts:
            payload = {
                "input": text,
                "model": model
            }
            
            response = requests.post(
                f"{api_url}/api/embed",
                headers=headers,
                json=payload,
                timeout=30
            )
            
            if response.status_code != 200:
                raise Exception(f"HTTP {response.status_code}: {response.text}")
            
            data = response.json()
            embedding = data.get("embeddings", [[]])[0]
            embeddings.append(embedding)
        
        return embeddings
    except Exception as e:
        raise Exception(f"임베딩 실패: {str(e)}")

def extract_log_info(text: str) -> dict:
    """로그에서 정보 추출"""
    info = {
        "timestamps": [],
        "device_ids": [],
        "log_levels": [],
        "alarms": [],
        "errors": []
    }
    
    # 타임스탬프 추출
    timestamps = re.findall(r'\[\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d+\]', text)
    info["timestamps"] = list(set(timestamps))
    
    # 디바이스 ID 추출
    devices = re.findall(r'\[([A-Z]+-\d+-[A-Z])\]', text)
    info["device_ids"] = list(set(devices))
    
    # 로그 레벨 추출
    levels = re.findall(r'\[(INFO|DEBUG|ALARM|ERROR|WARN|DATA|SENSOR|PLC|ANALYSIS|SECS-GEM|CONTROL|PERFORMANCE|MAINTENANCE|ENERGY|OPERATOR)\]', text)
    info["log_levels"] = list(set(levels))
    
    # 경보 추출
    alarms = re.findall(r'\[ALARM\](.*?)$', text, re.MULTILINE)
    info["alarms"] = alarms
    
    # 에러 추출
    errors = re.findall(r'(ERROR|FAIL|EXCEPTION)(.*?)$', text, re.MULTILINE)
    info["errors"] = errors
    
    return info

def rerank_results(api_url: str, api_key: str, query: str, passages: list, model: str) -> list:
    """리랭킹 (Ollama API)"""
    try:
        headers = {
            "X-API-Key": api_key,
            "Content-Type": "application/json"
        }
        
        payload = {
            "query": query,
            "passages": passages,
            "model": model
        }
        
        response = requests.post(
            f"{api_url}/api/rerank",
            headers=headers,
            json=payload,
            timeout=60
        )
        
        if response.status_code != 200:
            raise Exception(f"HTTP {response.status_code}: {response.text}")
        
        data = response.json()
        return data.get("results", [])
    except Exception as e:
        raise Exception(f"리랭킹 실패: {str(e)}")

def generate_response(api_url: str, api_key: str, prompt: str, model: str, temperature: float = 0.7) -> str:
    """응답 생성 (Ollama API)"""
    try:
        headers = {
            "X-API-Key": api_key,
            "Content-Type": "application/json"
        }
        
        payload = {
            "prompt": prompt,
            "model": model,
            "stream": False,
            "temperature": temperature
        }
        
        response = requests.post(
            f"{api_url}/api/generate",
            headers=headers,
            json=payload,
            timeout=120
        )
        
        if response.status_code != 200:
            raise Exception(f"HTTP {response.status_code}: {response.text}")
        
        data = response.json()
        return data.get("response", "")
    except Exception as e:
        raise Exception(f"응답 생성 실패: {str(e)}")

def check_server_health(api_url: str) -> dict:
    """서버 헬스체크"""
    try:
        response = requests.get(f"{api_url}/health", timeout=5)
        if response.status_code == 200:
            return response.json()
        return None
    except:
        return None

def initialize_session():
    """세션 초기화"""
    if "messages" not in st.session_state:
        st.session_state.messages = []
    if "log_file_hash" not in st.session_state:
        st.session_state.log_file_hash = None
    if "db" not in st.session_state:
        st.session_state.db = None
    if "log_info" not in st.session_state:
        st.session_state.log_info = None

# ============================================
# 4. Streamlit 페이지 설정
# ============================================

st.set_page_config(
    page_title="📊 로그 분석 챗봇",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.title("📊 로그 파일 분석 챗봇")
st.write("Ollama (Qwen3) + FAISS + RAG를 활용한 로그 분석")

initialize_session()
cfg = load_config()

# ============================================
# 5. 사이드바 - 메뉴
# ============================================

with st.sidebar:
    st.title("⚙️ 메뉴")
    menu = st.radio("선택", ["🤖 챗봇", "🔧 설정"], label_visibility="collapsed")

# ============================================
# 6. 설정 페이지
# ============================================

if menu == "🔧 설정":
    st.header("🔧 환경 설정")
    
    st.subheader("🔑 Ollama API 설정")
    col1, col2 = st.columns(2)
    with col1:
        api_url = st.text_input(
            "API URL",
            value=cfg.get("ollama_api_url", "http://server-ip:8000")
        )
    with col2:
        api_key = st.text_input(
            "API Key",
            value=cfg.get("ollama_api_key", ""),
            type="password"
        )
    
    # 서버 상태 확인
    if st.button("🔍 서버 상태 확인"):
        health = check_server_health(api_url)
        if health:
            st.success(f"✅ 서버 정상: {health['status']}")
            st.info(f"📡 Ollama 호스트: {health.get('ollama_host', 'N/A')}")
        else:
            st.error("❌ 서버 연결 실패")
    
    st.subheader("🤖 모델 설정")
    
    # LLM 및 임베딩 모델
    col1, col2 = st.columns(2)
    with col1:
        llm_model = st.selectbox(
            "LLM 모델",
            ["qwen3:8b", "qwen3:14b", "qwen3:32b"],
            index=0
        )
    with col2:
        embedding_model = st.selectbox(
            "임베딩 모델",
            ["qwen3-embedding:8b"],
            index=0
        )
    
    # Temperature
    temperature = st.slider("Temperature", 0.0, 2.0, cfg.get("temperature", 0.7), 0.1)
    
    # 리랭킹 설정
    st.divider()
    st.subheader("🔄 리랭킹 설정 (선택 사항)")
    st.info("💡 리랭킹을 활성화하면 검색 결과의 관련성을 재정렬하여 답변 정확도가 향상됩니다. (응답 시간 5-10초 추가)")
    
    use_rerank = st.checkbox(
        "✅ 리랭킹 사용",
        value=cfg.get("use_rerank", False),
        help="Qwen3-Reranker-8B를 사용하여 검색 결과를 재정렬합니다"
    )
    
    if use_rerank:
        col1, col2 = st.columns([3, 1])
        with col1:
            rerank_model = st.text_input(
                "리랭킹 모델",
                value=cfg.get("rerank_model", "dengcao/Qwen3-Reranker-8B:Q8_0"),
                help="사용 가능한 모델: Q3_K_M(4.1GB), Q4_K_M(5.0GB), Q5_K_M(5.8GB), Q8_0(8.7GB), F16(16GB)"
            )
        with col2:
            st.metric("모델 크기", "8.7GB")
            st.caption("Q8_0 버전")
    else:
        st.warning("⚠️ 리랭킹 비활성화: 빠른 응답이지만 정확도가 다소 낮을 수 있습니다")
        rerank_model = cfg.get("rerank_model", "dengcao/Qwen3-Reranker-8B:Q8_0")
    
    st.subheader("📄 검색 설정")
    col1, col2 = st.columns(2)
    with col1:
        chunk_size = st.number_input(
            "Chunk Size (로그 라인 수)",
            min_value=1,
            max_value=50,
            value=cfg.get("chunk_size", 5),
            step=1,
            help="연관된 로그 라인을 묶는 개수"
        )
    with col2:
        max_results = st.number_input(
            "Max Search Results",
            min_value=1,
            max_value=20,
            value=cfg.get("max_search_results", 5),
            step=1,
            help="검색 결과 반환 개수"
        )
    
    # 저장
    st.divider()
    col1, col2, col3 = st.columns(3)
    with col1:
        if st.button("💾 설정 저장", type="primary", use_container_width=True):
            cfg["ollama_api_url"] = api_url
            cfg["ollama_api_key"] = api_key
            cfg["llm_model"] = llm_model
            cfg["embedding_model"] = embedding_model
            cfg["temperature"] = temperature
            cfg["chunk_size"] = chunk_size
            cfg["max_search_results"] = max_results
            cfg["use_rerank"] = use_rerank
            cfg["rerank_model"] = rerank_model
            save_config(cfg)
            st.success("✅ 저장 완료!")
            st.info(f"🔄 리랭킹: {'활성화' if use_rerank else '비활성화'}")
    
    with col2:
        if st.button("🔄 새로고침", use_container_width=True):
            st.rerun()
    
    with col3:
        if st.button("📋 현재 설정 보기", use_container_width=True):
            with st.expander("⚙️ 현재 설정", expanded=True):
                st.json({
                    "ollama_api_url": api_url,
                    "llm_model": llm_model,
                    "embedding_model": embedding_model,
                    "temperature": temperature,
                    "use_rerank": use_rerank,
                    "rerank_model": rerank_model if use_rerank else "비활성화",
                    "chunk_size": chunk_size,
                    "max_search_results": max_results
                })
    
    st.divider()
    
    if st.session_state.db:
        st.subheader("📊 VectorDB 상태")
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("저장된 청크 수", st.session_state.db.get_size())
        with col2:
            st.metric("벡터 차원", st.session_state.db.dim)
        with col3:
            rerank_status = "✅ 활성화" if cfg.get("use_rerank", False) else "❌ 비활성화"
            st.metric("리랭킹 상태", rerank_status)
        
        if st.button("🗑️ DB 초기화", use_container_width=True):
            st.session_state.db.clear()
            st.success("✅ DB 초기화 완료!")
            st.rerun()
    
    st.stop()

# ============================================
# 7. 챗봇 페이지
# ============================================

if not cfg.get("ollama_api_key"):
    st.error("❌ 설정에서 API 키를 입력해주세요")
    st.stop()

# 서버 연결 확인
api_url = cfg.get("ollama_api_url")
health = check_server_health(api_url)
if not health:
    st.error(f"❌ Ollama 서버에 연결할 수 없습니다: {api_url}")
    st.info("💡 설정에서 서버 URL을 확인하거나, GPU 서버가 실행 중인지 확인하세요")
    st.stop()

# VectorDB 초기화
if st.session_state.db is None:
    st.session_state.db = LogVectorDB(dim=4096)

db = st.session_state.db

# 로그 파일 업로드
st.subheader("📤 로그 파일 업로드")

uploaded_file = st.file_uploader("로그 파일 선택 (txt)", type=["txt"], key="log_uploader")

if uploaded_file:
    file_content = uploaded_file.read()
    current_hash = get_file_hash(file_content)
    
    if current_hash != st.session_state.log_file_hash:
        if st.button("🔄 로그 임베딩 및 저장", type="primary"):
            try:
                text = file_content.decode("utf-8")
                
                with st.spinner("📄 로그 파싱 중..."):
                    lines = parse_log_lines(text)
                    chunks = chunk_log_lines(lines, chunk_size=cfg.get("chunk_size", 5))
                
                st.success(f"✅ {len(chunks)}개의 청크 생성")
                
                with st.spinner("🔗 임베딩 생성 중..."):
                    embeddings = embed_texts(
                        cfg.get("ollama_api_url"),
                        cfg.get("ollama_api_key"),
                        chunks,
                        model=cfg.get("embedding_model", "qwen3-embedding:8b")
                    )
                
                st.success(f"✅ {len(embeddings)}개 임베딩 완료")
                
                with st.spinner("💾 벡터 DB 저장 중..."):
                    db.clear()
                    for emb, chunk in zip(embeddings, chunks):
                        db.add(emb, chunk)
                    db.save()
                
                st.success("✅ 임베딩 완료!")
                st.session_state.log_file_hash = current_hash
                st.session_state.messages = []
                
                # 로그 정보 분석
                with st.spinner("📊 로그 정보 분석 중..."):
                    log_info = extract_log_info(text)
                    st.session_state.log_info = log_info
                
                # 로그 정보 표시
                if log_info:
                    with st.expander("📊 로그 정보 (클릭하여 확인)", expanded=False):
                        col1, col2 = st.columns(2)
                        with col1:
                            st.metric("총 라인 수", len(lines))
                            st.metric("타임스탬프", len(log_info["timestamps"]))
                            st.metric("디바이스", len(log_info["device_ids"]))
                        with col2:
                            st.metric("로그 레벨", len(log_info["log_levels"]))
                            st.metric("경보 수", len(log_info["alarms"]))
                            st.metric("에러 수", len(log_info["errors"]))
                
            except Exception as e:
                st.error(f"❌ 오류: {str(e)}")
    else:
        st.info(f"ℹ️ 이미 처리된 파일 ({db.get_size()} 청크 저장됨)")

st.divider()

# 채팅 인터페이스
col1, col2 = st.columns([3, 1])
with col1:
    st.subheader("💬 질문 및 답변")
with col2:
    if cfg.get("use_rerank", False):
        st.success("🔄 리랭킹 활성화")
    else:
        st.info("⚡ 빠른 모드")

if db.get_size() == 0:
    st.warning("⚠️ 먼저 로그 파일을 업로드하고 임베딩해주세요")
else:
    # 채팅 히스토리 표시
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
    
    # 사용자 입력
    if prompt := st.chat_input("로그에 대해 질문하세요..."):
        st.session_state.messages.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)
        
        # AI 응답
        with st.chat_message("assistant"):
            try:
                with st.spinner("🔍 로그 검색 중..."):
                    query_embeddings = embed_texts(
                        cfg.get("ollama_api_url"),
                        cfg.get("ollama_api_key"),
                        [prompt],
                        model=cfg.get("embedding_model", "qwen3-embedding:8b")
                    )
                    query_emb = query_embeddings[0]
                    results = db.search(query_emb, k=cfg.get("max_search_results", 5))
                
                if not results:
                    st.warning("⚠️ 관련 로그를 찾을 수 없습니다")
                else:
                    # 리랭킹 적용 (옵션)
                    rerank_used = False
                    if cfg.get("use_rerank", False):
                        with st.spinner("🔄 리랭킹 수행 중... (Qwen3-Reranker-8B)"):
                            try:
                                passages = [r[0] for r in results]
                                reranked = rerank_results(
                                    cfg.get("ollama_api_url"),
                                    cfg.get("ollama_api_key"),
                                    prompt,
                                    passages,
                                    cfg.get("rerank_model", "dengcao/Qwen3-Reranker-8B:Q8_0")
                                )
                                # 재정렬된 순서로 결과 재배치
                                results = [(passages[r["index"]], r["score"]) for r in reranked]
                                rerank_used = True
                                st.success("✅ 리랭킹 완료!")
                            except Exception as e:
                                st.warning(f"⚠️ 리랭킹 실패: {str(e)}. 원본 검색 결과 사용")
                                rerank_used = False
                    
                    # 검색 결과 표시
                    result_title = "🔎 검색된 로그" + (" (리랭킹 적용)" if rerank_used else " (벡터 검색)")
                    with st.expander(result_title + " - 클릭하여 확인", expanded=False):
                        for idx, (text, score) in enumerate(results, 1):
                            score_label = "관련성 점수" if rerank_used else "유사도 점수"
                            st.markdown(f"**결과 {idx}** ({score_label}: {score:.4f})")
                            st.code(text, language="text")
                    
                    # 응답 생성
                    context = "\n\n---\n\n".join([r[0] for r in results])
                    
                    system_prompt = "당신은 고급 로그 분석 전문가입니다. 제공된 로그를 분석하여 사용자의 질문에 명확하고 정확하게 답하세요. 로그에서 찾을 수 없는 정보는 '로그에 없음'이라고 명시해주세요."
                    
                    full_prompt = f"{system_prompt}\n\n로그 데이터:\n{context}\n\n질문: {prompt}\n\n답변:"
                    
                    with st.spinner("🤖 응답 생성 중..."):
                        assistant_response = generate_response(
                            cfg.get("ollama_api_url"),
                            cfg.get("ollama_api_key"),
                            full_prompt,
                            cfg.get("llm_model", "qwen3:8b"),
                            cfg.get("temperature", 0.7)
                        )
                        
                        st.markdown(assistant_response)
                        
                        st.session_state.messages.append({
                            "role": "assistant",
                            "content": assistant_response
                        })
            
            except Exception as e:
                st.error(f"❌ 오류: {str(e)}")

# 채팅 컨트롤
if st.session_state.messages:
    st.divider()
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("🗑️ 대화 초기화", use_container_width=True):
            st.session_state.messages = []
            st.rerun()
    
    with col2:
        if st.button("📥 대화 내역 보기", use_container_width=True):
            st.json(st.session_state.messages)
    
    with col3:
        if st.session_state.log_info:
            if st.button("📊 로그 요약", use_container_width=True):
                st.json(st.session_state.log_info)

# 푸터
st.divider()
st.caption("💡 팁: 로그에서 특정 이벤트, 경보, 성능 지표 등을 자유롭게 질문하세요!")
