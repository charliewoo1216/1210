"""
로그 파일 분석 챗봇 (LangChain 버전)
- Streamlit UI
- LangChain + Ollama API (Qwen3 모델)
- FAISS 벡터 스토어
- RAG 기반 질의응답

pip install langchain==0.3.13 langchain-community==0.3.13 langchain-core==0.3.28 langchain-text-splitters==0.3.3
"""

import streamlit as st
import json
import os
import hashlib
import re
from datetime import datetime
from typing import List, Dict, Any, Optional

# LangChain imports
from langchain_core.embeddings import Embeddings
from langchain_core.language_models.llms import LLM
from langchain_core.prompts import ChatPromptTemplate, PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_core.documents import Document
from langchain_community.vectorstores import FAISS
from langchain_community.document_loaders import TextLoader, UnstructuredMarkdownLoader, DirectoryLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain.chains import RetrievalQA

import requests
import numpy as np

# ============================================
# 1. 설정 및 상수
# ============================================

CONFIG_FILE = "log_config.json"
VECTOR_STORE_PATH = "log_vector_store"
RAG_KB_PATH = "./RAG-KB"
DEFAULT_CONFIG = {
    "ollama_api_url": "http://ㅁ:8000",
    "ollama_api_key": "ㅁ",
    "llm_model": "qwen3:8b",
    "embedding_model": "qwen3-embedding:8b",
    "rerank_model": "dengcao/Qwen3-Reranker-8B:Q8_0",
    "temperature": 0.7,
    "max_search_results": 5,
    "chunk_size": 500,
    "chunk_overlap": 50,
    "use_rerank": False
}

# ============================================
# 2. Custom Ollama Embeddings for LangChain
# ============================================

class OllamaEmbeddings(Embeddings):
    """Custom Ollama Embeddings for LangChain"""
    
    def __init__(self, api_url: str, api_key: str, model: str = "qwen3-embedding:8b"):
        self.api_url = api_url
        self.api_key = api_key
        self.model = model
    
    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """Embed multiple documents"""
        embeddings = []
        headers = {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json"
        }
        
        for text in texts:
            payload = {
                "input": text,
                "model": self.model
            }
            
            response = requests.post(
                f"{self.api_url}/api/embed",
                headers=headers,
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                data = response.json()
                embedding = data.get("embeddings", [[]])[0]
                embeddings.append(embedding)
            else:
                raise Exception(f"임베딩 실패: HTTP {response.status_code}")
        
        return embeddings
    
    def embed_query(self, text: str) -> List[float]:
        """Embed a single query"""
        return self.embed_documents([text])[0]

# ============================================
# 3. Custom Ollama LLM for LangChain
# ============================================

class OllamaLLM(LLM):
    """Custom Ollama LLM for LangChain"""
    
    api_url: str
    api_key: str
    model: str = "qwen3:8b"
    temperature: float = 0.7
    
    @property
    def _llm_type(self) -> str:
        return "ollama"
    
    def _call(self, prompt: str, stop: Optional[List[str]] = None) -> str:
        """Generate response from Ollama"""
        headers = {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json"
        }
        
        payload = {
            "prompt": prompt,
            "model": self.model,
            "stream": False,
            "temperature": self.temperature
        }
        
        response = requests.post(
            f"{self.api_url}/api/generate",
            headers=headers,
            json=payload,
            timeout=120
        )
        
        if response.status_code == 200:
            data = response.json()
            return data.get("response", "")
        else:
            raise Exception(f"LLM 호출 실패: HTTP {response.status_code}")

# ============================================
# 4. Reranker (optional)
# ============================================

class OllamaReranker:
    """Ollama Reranker for improving search results"""
    
    def __init__(self, api_url: str, api_key: str, model: str):
        self.api_url = api_url
        self.api_key = api_key
        self.model = model
    
    def rerank(self, query: str, documents: List[Document]) -> List[Document]:
        """Rerank documents based on relevance to query"""
        headers = {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json"
        }
        
        passages = [doc.page_content for doc in documents]
        
        payload = {
            "query": query,
            "passages": passages,
            "model": self.model
        }
        
        response = requests.post(
            f"{self.api_url}/api/rerank",
            headers=headers,
            json=payload,
            timeout=60
        )
        
        if response.status_code == 200:
            data = response.json()
            results = data.get("results", [])
            
            # Sort documents by reranked scores
            reranked_docs = []
            for result in results:
                idx = result["index"]
                if idx < len(documents):
                    doc = documents[idx]
                    doc.metadata["rerank_score"] = result["score"]
                    reranked_docs.append(doc)
            
            return reranked_docs
        else:
            raise Exception(f"리랭킹 실패: HTTP {response.status_code}")

# ============================================
# 5. 유틸리티 함수
# ============================================

def load_config():
    """설정 로드"""
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return DEFAULT_CONFIG.copy()

def save_config(cfg):
    """설정 저장"""
    try:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=4, ensure_ascii=False)
    except Exception as e:
        st.error(f"설정 저장 실패: {e}")

def get_file_hash(content):
    """파일 해시값"""
    return hashlib.md5(content).hexdigest()

def extract_log_info(text: str) -> dict:
    """로그에서 정보 추출"""
    info = {
        "timestamps": [],
        "device_ids": [],
        "log_levels": [],
        "alarms": [],
        "errors": []
    }
    
    # 타임스탬프 추출
    timestamps = re.findall(r'\[\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d+\]', text)
    info["timestamps"] = list(set(timestamps))
    
    # 디바이스 ID 추출
    devices = re.findall(r'\[([A-Z]+-\d+-[A-Z])\]', text)
    info["device_ids"] = list(set(devices))
    
    # 로그 레벨 추출
    levels = re.findall(r'\[(INFO|DEBUG|ALARM|ERROR|WARN|DATA|SENSOR|PLC|ANALYSIS|SECS-GEM|CONTROL|PERFORMANCE|MAINTENANCE|ENERGY|OPERATOR)\]', text)
    info["log_levels"] = list(set(levels))
    
    # 경보 추출
    alarms = re.findall(r'\[ALARM\](.*?)$', text, re.MULTILINE)
    info["alarms"] = alarms
    
    # 에러 추출
    errors = re.findall(r'(ERROR|FAIL|EXCEPTION)(.*?)$', text, re.MULTILINE)
    info["errors"] = errors
    
    return info

def check_server_health(api_url: str) -> dict:
    """서버 헬스체크"""
    try:
        response = requests.get(f"{api_url}/health", timeout=5)
        if response.status_code == 200:
            return response.json()
        return None
    except:
        return None

def load_knowledge_base_documents(kb_path: str = RAG_KB_PATH) -> List[Document]:
    """RAG-KB 폴더에서 txt, markdown 문서 로드 (LangChain)"""
    documents = []
    
    if not os.path.exists(kb_path):
        st.warning(f"⚠️ RAG-KB 폴더를 찾을 수 없습니다: {kb_path}")
        return documents
    
    try:
        # txt 파일 로드
        txt_files = []
        md_files = []
        
        for root, dirs, files in os.walk(kb_path):
            for file in files:
                file_path = os.path.join(root, file)
                if file.endswith('.txt'):
                    txt_files.append(file_path)
                elif file.endswith('.md') or file.endswith('.markdown'):
                    md_files.append(file_path)
        
        # TextLoader로 txt 파일 로드
        for txt_file in txt_files:
            try:
                loader = TextLoader(txt_file, encoding='utf-8')
                docs = loader.load()
                for doc in docs:
                    doc.metadata['source_type'] = 'knowledge_base'
                    doc.metadata['file_type'] = 'txt'
                documents.extend(docs)
            except Exception as e:
                st.warning(f"⚠️ {txt_file} 로드 실패: {e}")
        
        # UnstructuredMarkdownLoader로 markdown 파일 로드
        for md_file in md_files:
            try:
                loader = UnstructuredMarkdownLoader(md_file)
                docs = loader.load()
                for doc in docs:
                    doc.metadata['source_type'] = 'knowledge_base'
                    doc.metadata['file_type'] = 'markdown'
                documents.extend(docs)
            except Exception as e:
                # UnstructuredMarkdownLoader 실패 시 TextLoader로 재시도
                try:
                    loader = TextLoader(md_file, encoding='utf-8')
                    docs = loader.load()
                    for doc in docs:
                        doc.metadata['source_type'] = 'knowledge_base'
                        doc.metadata['file_type'] = 'markdown'
                    documents.extend(docs)
                except Exception as e2:
                    st.warning(f"⚠️ {md_file} 로드 실패: {e2}")
        
        if documents:
            st.info(f"✅ RAG-KB에서 {len(documents)}개 문서 로드 완료 (txt: {len(txt_files)}, md: {len(md_files)})")
        
    except Exception as e:
        st.error(f"❌ RAG-KB 로드 중 오류: {e}")
    
    return documents

def initialize_session():
    """세션 초기화"""
    if "messages" not in st.session_state:
        st.session_state.messages = []
    if "log_file_hash" not in st.session_state:
        st.session_state.log_file_hash = None
    if "vectorstore" not in st.session_state:
        st.session_state.vectorstore = None
    if "log_info" not in st.session_state:
        st.session_state.log_info = None
    if "qa_chain" not in st.session_state:
        st.session_state.qa_chain = None
    if "kb_loaded" not in st.session_state:
        st.session_state.kb_loaded = False

# ============================================
# 6. LangChain RAG Chain 생성
# ============================================

def create_rag_chain(cfg: dict, vectorstore: FAISS) -> Any:
    """LangChain RAG Chain 생성"""
    
    # LLM 초기화
    llm = OllamaLLM(
        api_url=cfg.get("ollama_api_url"),
        api_key=cfg.get("ollama_api_key"),
        model=cfg.get("llm_model", "qwen3:8b"),
        temperature=cfg.get("temperature", 0.7)
    )
    
    # Retriever 설정
    retriever = vectorstore.as_retriever(
        search_kwargs={"k": cfg.get("max_search_results", 5)}
    )
    
    # Prompt Template
    template = """당신은 고급 로그 분석 및 기술 문서 전문가입니다. 
제공된 컨텍스트(로그 데이터 및 지식 베이스 문서)를 분석하여 사용자의 질문에 명확하고 정확하게 답하세요.

지침:
1. 지식 베이스 문서의 정보를 우선적으로 활용하여 답변하세요.
2. 로그 데이터와 지식 베이스를 함께 고려하여 종합적인 답변을 제공하세요.
3. 컨텍스트에서 찾을 수 없는 정보는 '제공된 문서에 없음'이라고 명시해주세요.
4. 가능한 경우 출처(로그 또는 지식 베이스)를 명시해주세요.

관련 컨텍스트:
{context}

질문: {question}

답변:"""
    
    prompt = PromptTemplate(
        template=template,
        input_variables=["context", "question"]
    )
    
    # RAG Chain 구성
    def format_docs(docs):
        return "\n\n---\n\n".join([d.page_content for d in docs])
    
    rag_chain = (
        {"context": retriever | format_docs, "question": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )
    
    return rag_chain, retriever

# ============================================
# 7. Streamlit 페이지 설정
# ============================================

st.set_page_config(
    page_title="📊 로그 분석 챗봇 (LangChain)",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.title("📊 로그 파일 분석 챗봇 (LangChain)")
st.write("LangChain + Ollama (Qwen3) + FAISS를 활용한 로그 분석")

initialize_session()
cfg = load_config()

# ============================================
# 8. 사이드바 - 메뉴
# ============================================

with st.sidebar:
    st.title("⚙️ 메뉴")
    menu = st.radio("선택", ["🤖 챗봇", "🔧 설정"], label_visibility="collapsed")

# ============================================
# 9. 설정 페이지
# ============================================

if menu == "🔧 설정":
    st.header("🔧 환경 설정")
    
    st.subheader("🔑 Ollama API 설정")
    col1, col2 = st.columns(2)
    with col1:
        api_url = st.text_input(
            "API URL",
            value=cfg.get("ollama_api_url", "http://server-ip:8000")
        )
    with col2:
        api_key = st.text_input(
            "API Key",
            value=cfg.get("ollama_api_key", ""),
            type="password"
        )
    
    # 서버 상태 확인
    if st.button("🔍 서버 상태 확인"):
        health = check_server_health(api_url)
        if health:
            st.success(f"✅ 서버 정상: {health['status']}")
            st.info(f"📡 Ollama 호스트: {health.get('ollama_host', 'N/A')}")
        else:
            st.error("❌ 서버 연결 실패")
    
    st.subheader("🤖 모델 설정")
    
    # LLM 및 임베딩 모델
    col1, col2 = st.columns(2)
    with col1:
        llm_model = st.selectbox(
            "LLM 모델",
            ["qwen3:8b", "qwen3:14b", "qwen3:32b"],
            index=0
        )
    with col2:
        embedding_model = st.selectbox(
            "임베딩 모델",
            ["qwen3-embedding:8b"],
            index=0
        )
    
    # Temperature
    temperature = st.slider("Temperature", 0.0, 2.0, cfg.get("temperature", 0.7), 0.1)
    
    # 리랭킹 설정
    st.divider()
    st.subheader("🔄 리랭킹 설정 (선택 사항)")
    st.info("💡 리랭킹을 활성화하면 검색 결과의 관련성을 재정렬하여 답변 정확도가 향상됩니다. (응답 시간 5-10초 추가)")
    
    use_rerank = st.checkbox(
        "✅ 리랭킹 사용",
        value=cfg.get("use_rerank", False),
        help="Qwen3-Reranker-8B를 사용하여 검색 결과를 재정렬합니다"
    )
    
    if use_rerank:
        rerank_model = st.text_input(
            "리랭킹 모델",
            value=cfg.get("rerank_model", "dengcao/Qwen3-Reranker-8B:Q8_0"),
            help="사용 가능한 모델: Q3_K_M(4.1GB), Q4_K_M(5.0GB), Q5_K_M(5.8GB), Q8_0(8.7GB), F16(16GB)"
        )
    else:
        rerank_model = cfg.get("rerank_model", "dengcao/Qwen3-Reranker-8B:Q8_0")
    
    st.subheader("📄 텍스트 분할 설정 (LangChain)")
    col1, col2 = st.columns(2)
    with col1:
        chunk_size = st.number_input(
            "Chunk Size (문자 수)",
            min_value=100,
            max_value=2000,
            value=cfg.get("chunk_size", 500),
            step=100,
            help="각 청크의 최대 문자 수"
        )
    with col2:
        chunk_overlap = st.number_input(
            "Chunk Overlap",
            min_value=0,
            max_value=500,
            value=cfg.get("chunk_overlap", 50),
            step=10,
            help="청크 간 겹치는 문자 수"
        )
    
    max_results = st.number_input(
        "Max Search Results",
        min_value=1,
        max_value=20,
        value=cfg.get("max_search_results", 5),
        step=1,
        help="검색 결과 반환 개수"
    )
    
    # 저장
    st.divider()
    col1, col2, col3 = st.columns(3)
    with col1:
        if st.button("💾 설정 저장", type="primary", use_container_width=True):
            cfg["ollama_api_url"] = api_url
            cfg["ollama_api_key"] = api_key
            cfg["llm_model"] = llm_model
            cfg["embedding_model"] = embedding_model
            cfg["temperature"] = temperature
            cfg["chunk_size"] = chunk_size
            cfg["chunk_overlap"] = chunk_overlap
            cfg["max_search_results"] = max_results
            cfg["use_rerank"] = use_rerank
            cfg["rerank_model"] = rerank_model
            save_config(cfg)
            st.success("✅ 저장 완료!")
            st.info(f"🔄 리랭킹: {'활성화' if use_rerank else '비활성화'}")
    
    with col2:
        if st.button("🔄 새로고침", use_container_width=True):
            st.rerun()
    
    with col3:
        if st.button("📋 현재 설정 보기", use_container_width=True):
            with st.expander("⚙️ 현재 설정", expanded=True):
                st.json({
                    "ollama_api_url": api_url,
                    "llm_model": llm_model,
                    "embedding_model": embedding_model,
                    "temperature": temperature,
                    "use_rerank": use_rerank,
                    "rerank_model": rerank_model if use_rerank else "비활성화",
                    "chunk_size": chunk_size,
                    "chunk_overlap": chunk_overlap,
                    "max_search_results": max_results
                })
    
    st.divider()
    
    if st.session_state.vectorstore:
        st.subheader("📊 VectorStore 상태")
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            # FAISS vectorstore의 문서 개수 가져오기
            try:
                doc_count = len(st.session_state.vectorstore.docstore._dict)
                st.metric("저장된 문서 수", doc_count)
            except:
                st.metric("저장된 문서 수", "N/A")
        with col2:
            st.metric("프레임워크", "LangChain")
        with col3:
            kb_status = "✅ 로드됨" if st.session_state.get("kb_loaded", False) else "❌ 없음"
            st.metric("RAG-KB", kb_status)
        with col4:
            rerank_status = "✅ 활성화" if cfg.get("use_rerank", False) else "❌ 비활성화"
            st.metric("리랭킹", rerank_status)
        
        if st.button("🗑️ VectorStore 초기화", use_container_width=True):
            st.session_state.vectorstore = None
            st.session_state.qa_chain = None
            st.success("✅ VectorStore 초기화 완료!")
            st.rerun()
    
    st.stop()

# ============================================
# 10. 챗봇 페이지
# ============================================

if not cfg.get("ollama_api_key"):
    st.error("❌ 설정에서 API 키를 입력해주세요")
    st.stop()

# 서버 연결 확인
api_url = cfg.get("ollama_api_url")
health = check_server_health(api_url)
if not health:
    st.error(f"❌ Ollama 서버에 연결할 수 없습니다: {api_url}")
    st.info("💡 설정에서 서버 URL을 확인하거나, GPU 서버가 실행 중인지 확인하세요")
    st.stop()

# 로그 파일 업로드
st.subheader("📤 로그 파일 업로드")

uploaded_file = st.file_uploader("로그 파일 선택 (txt)", type=["txt"], key="log_uploader")

if uploaded_file:
    file_content = uploaded_file.read()
    current_hash = get_file_hash(file_content)
    
    if current_hash != st.session_state.log_file_hash:
        if st.button("🔄 로그 임베딩 및 저장 (LangChain)", type="primary"):
            try:
                text = file_content.decode("utf-8")
                
                # Embeddings 초기화
                with st.spinner("🔗 Embeddings 모델 초기화 중..."):
                    embeddings = OllamaEmbeddings(
                        api_url=cfg.get("ollama_api_url"),
                        api_key=cfg.get("ollama_api_key"),
                        model=cfg.get("embedding_model", "qwen3-embedding:8b")
                    )
                
                # 텍스트 분할 (LangChain)
                with st.spinner("📄 로그 분할 중 (LangChain TextSplitter)..."):
                    text_splitter = RecursiveCharacterTextSplitter(
                        chunk_size=cfg.get("chunk_size", 500),
                        chunk_overlap=cfg.get("chunk_overlap", 50),
                        length_function=len,
                        separators=["\n\n", "\n", " ", ""]
                    )
                    
                    # 로그 문서 생성
                    log_documents = text_splitter.create_documents([text])
                    for doc in log_documents:
                        doc.metadata['source_type'] = 'log'
                
                st.success(f"✅ {len(log_documents)}개의 로그 청크 생성")
                
                # RAG-KB 문서 로드 및 분할
                with st.spinner("📚 RAG-KB 지식 베이스 로드 중..."):
                    kb_documents = load_knowledge_base_documents()
                    
                    if kb_documents:
                        kb_chunks = text_splitter.split_documents(kb_documents)
                        st.success(f"✅ {len(kb_chunks)}개의 지식 베이스 청크 생성")
                    else:
                        kb_chunks = []
                        st.info("ℹ️ RAG-KB 폴더가 비어있거나 문서를 찾을 수 없습니다")
                
                # 로그와 지식 베이스 문서 통합
                documents = log_documents + kb_chunks
                st.info(f"📊 총 {len(documents)}개 문서 청크 (로그: {len(log_documents)}, KB: {len(kb_chunks)})")
                
                # FAISS VectorStore 생성
                with st.spinner("💾 FAISS VectorStore 생성 중..."):
                    vectorstore = FAISS.from_documents(documents, embeddings)
                    
                    # VectorStore 저장
                    os.makedirs(VECTOR_STORE_PATH, exist_ok=True)
                    vectorstore.save_local(VECTOR_STORE_PATH)
                
                st.success("✅ VectorStore 생성 완료!")
                
                # RAG Chain 생성
                with st.spinner("🤖 RAG Chain 생성 중..."):
                    qa_chain, retriever = create_rag_chain(cfg, vectorstore)
                
                st.success("✅ RAG Chain 준비 완료!")
                
                # 세션 상태 업데이트
                st.session_state.vectorstore = vectorstore
                st.session_state.qa_chain = qa_chain
                st.session_state.log_file_hash = current_hash
                st.session_state.messages = []
                st.session_state.kb_loaded = len(kb_chunks) > 0
                
                # 로그 정보 분석
                with st.spinner("📊 로그 정보 분석 중..."):
                    log_info = extract_log_info(text)
                    st.session_state.log_info = log_info
                
                # 로그 정보 표시
                if log_info:
                    with st.expander("📊 로그 정보 (클릭하여 확인)", expanded=False):
                        col1, col2 = st.columns(2)
                        with col1:
                            st.metric("총 문서 수", len(documents))
                            st.metric("타임스탬프", len(log_info["timestamps"]))
                            st.metric("디바이스", len(log_info["device_ids"]))
                        with col2:
                            st.metric("로그 레벨", len(log_info["log_levels"]))
                            st.metric("경보 수", len(log_info["alarms"]))
                            st.metric("에러 수", len(log_info["errors"]))
            
            except Exception as e:
                st.error(f"❌ 오류: {str(e)}")
    else:
        if st.session_state.vectorstore:
            try:
                doc_count = len(st.session_state.vectorstore.docstore._dict)
                st.info(f"ℹ️ 이미 처리된 파일 ({doc_count} 문서 저장됨)")
            except:
                st.info(f"ℹ️ 이미 처리된 파일")

st.divider()

# 채팅 인터페이스
col1, col2, col3 = st.columns([2, 1, 1])
with col1:
    st.subheader("💬 질문 및 답변 (LangChain RAG)")
with col2:
    if st.session_state.get("kb_loaded", False):
        st.success("📚 KB 활성화")
    else:
        st.info("📄 로그만")
with col3:
    if cfg.get("use_rerank", False):
        st.success("🔄 리랭킹")
    else:
        st.info("⚡ 빠른 모드")

if not st.session_state.vectorstore or not st.session_state.qa_chain:
    st.warning("⚠️ 먼저 로그 파일을 업로드하고 임베딩해주세요")
else:
    # 채팅 히스토리 표시
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
    
    # 사용자 입력
    if prompt := st.chat_input("로그에 대해 질문하세요..."):
        st.session_state.messages.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)
        
        # AI 응답
        with st.chat_message("assistant"):
            try:
                # Retriever로 관련 문서 검색
                with st.spinner("🔍 로그 검색 중... (LangChain Retriever)"):
                    retriever = st.session_state.vectorstore.as_retriever(
                        search_kwargs={"k": cfg.get("max_search_results", 5)}
                    )
                    retrieved_docs = retriever.get_relevant_documents(prompt)
                
                if not retrieved_docs:
                    st.warning("⚠️ 관련 로그를 찾을 수 없습니다")
                else:
                    # 리랭킹 적용 (옵션)
                    rerank_used = False
                    if cfg.get("use_rerank", False):
                        with st.spinner("🔄 리랭킹 수행 중... (Qwen3-Reranker-8B)"):
                            try:
                                reranker = OllamaReranker(
                                    api_url=cfg.get("ollama_api_url"),
                                    api_key=cfg.get("ollama_api_key"),
                                    model=cfg.get("rerank_model", "dengcao/Qwen3-Reranker-8B:Q8_0")
                                )
                                retrieved_docs = reranker.rerank(prompt, retrieved_docs)
                                rerank_used = True
                                st.success("✅ 리랭킹 완료!")
                            except Exception as e:
                                st.warning(f"⚠️ 리랭킹 실패: {str(e)}. 원본 검색 결과 사용")
                                rerank_used = False
                    
                    # 검색 결과 표시
                    result_title = "🔎 검색된 컨텍스트" + (" (리랭킹 적용)" if rerank_used else " (벡터 검색)")
                    with st.expander(result_title + " - 클릭하여 확인", expanded=False):
                        for idx, doc in enumerate(retrieved_docs, 1):
                            score = doc.metadata.get("rerank_score", "N/A") if rerank_used else "N/A"
                            score_label = "관련성 점수" if rerank_used else "유사도 기반"
                            source_type = doc.metadata.get("source_type", "unknown")
                            source_icon = "📄" if source_type == "log" else "📚"
                            source_label = "로그" if source_type == "log" else "지식베이스"
                            file_type = doc.metadata.get("file_type", "")
                            
                            st.markdown(f"**{source_icon} 문서 {idx}** - {source_label} ({score_label}: {score})")
                            if file_type:
                                st.caption(f"파일 유형: {file_type}")
                            st.code(doc.page_content, language="text")
                    
                    # RAG Chain으로 응답 생성
                    with st.spinner("🤖 응답 생성 중... (LangChain RAG)"):
                        assistant_response = st.session_state.qa_chain.invoke(prompt)
                        
                        st.markdown(assistant_response)
                        
                        st.session_state.messages.append({
                            "role": "assistant",
                            "content": assistant_response
                        })
            
            except Exception as e:
                st.error(f"❌ 오류: {str(e)}")

# 채팅 컨트롤
if st.session_state.messages:
    st.divider()
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("🗑️ 대화 초기화", use_container_width=True):
            st.session_state.messages = []
            st.rerun()
    
    with col2:
        if st.button("📥 대화 내역 보기", use_container_width=True):
            st.json(st.session_state.messages)
    
    with col3:
        if st.session_state.log_info:
            if st.button("📊 로그 요약", use_container_width=True):
                st.json(st.session_state.log_info)

# 푸터
st.divider()
st.caption("💡 팁: 로그에서 특정 이벤트, 경보, 성능 지표 등을 자유롭게 질문하세요!")
if st.session_state.get("kb_loaded", False):
    st.caption("📚 RAG-KB 폴더의 지식 베이스 문서를 함께 참고하여 답변합니다.")
else:
    st.caption("ℹ️ ./RAG-KB 폴더에 txt, markdown 파일을 추가하면 지식 베이스로 활용됩니다.")
st.caption("🔗 Powered by LangChain + Ollama + FAISS")
